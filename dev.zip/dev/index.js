const express = require('express');
const app = express();
require('dotenv').config();
const mongoose = require('./src/mongoose');
const config = require('./config');
const { router } = require('./src/routes');
const i18n = require('i18n');
const swaggerUi = require('swagger-ui-express');
const { swaggerJson } = require('./src/swagger-json');
const cors = require('cors');
const initializePassport = require('./src/passport');
const passport = require('passport');
const cookieSession = require('cookie-session');
const bodyParser = require('body-parser');

app.use(
    cookieSession({
        name: 'google-auth-session',
        keys: ['key1', 'key2'],
    })
);
app.use(passport.initialize());
app.use(passport.session());

app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));
app.use('/uploads', express.static(`${__dirname}/uploads`));

// Configure local
i18n.configure({
    objectNotation: true,
    updateFiles: false,
    syncFiles: false,
    locales: ['en'],
    defaultLocale: 'en',
    directory: `${__dirname}/src/locales`,
});
app.use(i18n.init);

// Cors
app.use(
    cors({
        origin: '*',
    })
);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

initializePassport();
app.use(router);

// Swagger Setup
app.use(
    '/api-docs',
    function (req, res, next) {
        const swaggerSpec = swaggerJson(req, res);
        req.swaggerDoc = swaggerSpec;
        next();
    },
    swaggerUi.serve,
    swaggerUi.setup()
);

const PORT = process.env.PORT || 3001;

app.set('port', PORT);

(async () => {
    try {
        await mongoose.connect(config.mongodb);
        console.log('connected to mongodb server');
    } catch (e) {
        console.log(e);
        return;
    }

    app.listen(PORT, () => {
        console.log(`Server is running at ${PORT}`);
    });
})();
