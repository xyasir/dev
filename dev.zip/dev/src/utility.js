const { admin } = require('./firebase-config');

const timeSlotsMap = {
    'Early Morning': ['07:00:00', '09:00:00'],
    Morning: ['09:00:00', '11:00:00'],
    'Late Morning': ['11:00:00', '12:00:00'],
    'Early Afternoon': ['12:00:00', '13:00:00'],
    Afternoon: ['13:00:00', '15:00:00'],
    'Later Afternoon': ['15:00:00', '17:00:00'],
    Twilight: ['17:00:00', 'later'],
};

async function getTimeSlot(key) {
    if (timeSlotsMap[key]) return timeSlotsMap[key];
    return 'Invalid Time Slot';
}
const notification_options = {
    priority: 'high',
    timeToLive: 60 * 60 * 24,
};
async function sendAndroid(androidDevice, title, msg) {
    const options = notification_options;
    const payload = {
        notification: {
            title: title,
            body: msg,
        },
        // NOTE: The 'data' object is inside payload, not inside notification
        data: {
            personSent: androidDevice,
        },
    };

    admin
        .messaging()
        .sendToDevice(androidDevice, payload, options)
        .then((response) => {
            console.log('Notification sent successfully', response);
        })
        .catch((error) => {
            console.log(error.message);
        });
}

module.exports = { getTimeSlot, sendAndroid };
