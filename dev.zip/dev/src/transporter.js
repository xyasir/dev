const nodemailer = require('nodemailer');
const config = require('../config');

let transporter = nodemailer.createTransport({
    service: config.mail.emailService,
    auth: {
        user: config.mail.from,
        pass: config.mail.password,
    },
});

async function sendEmail({ to, subject, text }) {
    transporter
        .sendMail({
            from: `Golf Course Developer ${config.mail.from}`,
            to,
            subject,
            text,
        })
        .then((info) => {
            console.log('Message sent: %s', info.messageId);
        })
        .catch((err) => {
            console.log('Error: %s', err);
        });
}

async function sendEmailVerification({ to, subject, token, host }) {
    transporter
        .sendMail({
            from: `Golf Course Developer ${config.mail.from}`,
            to,
            subject,
            html:
                '<body style="word-spacing:normal;"><div><table align="center" background="https://i.ibb.co/hVkqcX1/verify-Email.png" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:url("https://i.ibb.co/hVkqcX1/verify-Email.png") center top / contain no-repeat;background-position:center top;background-repeat:no-repeat;background-size:contain;width:100%;height:600px;"><tbody><tr><td><v:rect style="mso-width-percent:1000;" xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false"><v:fill origin="0, -0.5" position="0, -0.5" src="' +
                host +
                'uploads/verifyEmail.png" type="frame" size="1,1" /><v:textbox style="mso-fit-shape-to-text:true" inset="0,0,0,0"><table align="center" border="0" cellpadding="0" cellspacing="0" class="" style="width:600px;height:600px;" width="600" height="600px"><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><div style="margin:0px auto;max-width:600px;"><div style="line-height:0;font-size:0;"><table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:100%;"><tbody><tr><td style="direction:ltr;font-size:0px;padding:20px 0;text-align:center;"><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:middle;width:600px;" ><![endif]--><div class="mj-column-per-100 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:middle;width:100%;"><table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:middle;" width="100%"><tbody><tr><td align="center" style="font-size:0px;padding:10px 25px;padding-top:45px;padding-bottom:10px;word-break:break-word;"><div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:12px;line-height:1;text-align:center;color:#45474e;"><span style="font-size: 16px; line-height: 30px;font-weight:600">Woo-hoo! Thanks for registering.</span><br><span style="font-size: 12px; line-height: 20px;">Hope you’re ready for some more golf in your life!</span><br><br><br><br><br>Click the button below to verify your account.</div></td></tr><tr><td align="center" vertical-align="middle" style="font-size:0px;padding:10px 25px;padding-top:10px;padding-bottom:45px;word-break:break-word;"><table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:separate;line-height:100%;"><tr><td align="center" bgcolor="#0B7DE6" role="presentation" style="border:none;border-radius:24px;cursor:auto;mso-padding-alt:10px 25px;background:#0B7DE6;" valign="middle"><a href=" ' +
                token +
                ' " style="display:inline-block;background:#0B7DE6;color:#ffffff;font-family:Ubuntu, Helvetica, Arial, sans-serif, Helvetica, Arial, sans-serif;font-size:13px;font-weight:normal;line-height:120%;margin:0;text-decoration:none;text-transform:none;padding:10px 25px;mso-padding-alt:0px;border-radius:24px;" target="_blank">Verify Account</a></td></tr></table></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div></div><!--[if mso | IE]></td></tr></table></v:textbox></v:rect><![endif]--></td></tr></tbody></table></div></body>',
        })
        .then((info) => {
            console.log('Message sent: %s', info.messageId);
        })
        .catch((err) => {
            console.log('Error: %s', err);
        });
}
module.exports = { sendEmail, sendEmailVerification };
