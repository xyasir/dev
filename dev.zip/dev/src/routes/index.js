'use strict';

module.exports = {
    router: require('./router'),
};
