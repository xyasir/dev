'use strict';

const express = require('express');
const {
    userController,
    communityPostController,
    golfScheduleController,
    golfStyleController,
    postCommentController,
    golfCourseController,
    NotificationController,
    eventController,
    locationController,
    eventUserController,
    postEventController,
    commentPostEventController,
} = require('../controllers');
const router = express.Router();
const { validateToken, isAdmin } = require('../middleware/validateToken');
const multer = require('multer');
const passport = require('passport');
const path = require('path');

router.get('/', (req, res) => {
    return res.send('Golf Course APIs');
});


router.get(
    '/getCalendarGolfSchedule',
    validateToken,
    golfScheduleController.getCalendarSchedule
);

// Location API
router.post(
    '/addLocation/:userId',
    validateToken,
    locationController.addLocation
);

// claimCourse api
router.post(
    '/claimCourse/:userId',
    validateToken,
    golfCourseController.claimGolfCourse
);
router.put(
    '/claim/:id/verify',
    validateToken,
    golfCourseController.claimGolfCourseByAdmin
);
router.get(
    `/allClaimCourse`,
    validateToken,
    golfCourseController.getClaimGolfCourse
);
router.delete(
    `/deleteClaimCourse/:id`,
    validateToken,
    golfCourseController.deleteClaimCourse
);
// EventUser api
const storageEvent = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + path.extname(file.originalname));
    },
});
const uploadData = multer({
    storage: storageEvent,
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB file size limit
    },
  });
router.post(
    '/updateImage/:id',
    validateToken,
    uploadData.single('image'),
    eventUserController.profileImageEventUpload
);
router.post(
    '/addEventUser/:userId',
    validateToken,
    eventUserController.addEventUser
);
router.put(
    `/updateEventUser/:id`,
    validateToken,
    eventUserController.updateEventUser
);
router.post(
    '/event/:id/:action/:userId',
    validateToken,
    eventUserController.addEventUserAction
);
router.get(
    `/eventUsers/:id`,
    validateToken,
    eventUserController.getEventUserByIdData
);
router.get(
    `/allEventUsers/:location`,
    validateToken,
    eventUserController.getAllEventUser
);
router.delete(
    `/deleteEventUser/:id`,
    validateToken,
    eventUserController.deleteEventUser
);

// postEventUser api
router.post(
    '/addPostEvent/:eventUserId',
    validateToken,
    postEventController.addPostEventUser
);
router.get(
    '/postEvent/:eventUserId',
    validateToken,
    postEventController.getPostEventUserById
);
router.put(
    '/updatePostEvent/:postId',
    validateToken,
    postEventController.updatePostEventUser
);
router.delete(
    '/deletePostEvent/:postId',
    validateToken,
    postEventController.deletePostEventUser
);
router.post(
    '/postEvent/:id/like/:userId/:action',
    validateToken,
    postEventController.likePostEventUser
);

// commnetPostEvent api
router.post(
    '/addCommentPost/:postId',
    validateToken,
    commentPostEventController.addCommnetPostEventUser
);
router.get(
    '/commentPostEvent/:postId',
    validateToken,
    commentPostEventController.getCommentByPostId
);
router.put(
    '/updateCommentPostEvent/:commentId',
    validateToken,
    commentPostEventController.updateCommentPostEventUser
);
router.delete(
    '/deleteCommentPostEvent/:commentId',
    validateToken,
    commentPostEventController.deleteCommentPostEventUser
);
router.post(
    '/comment/:id/like/:userId',
    validateToken,
    commentPostEventController.likeCommnetPostEventUser
);

//General Search API
// eslint-disable-next-line prettier/prettier
router.get(
    '/searchGeneral',
    validateToken,
    // isAdmin,
    userController.searchGeneral
);

// User routes
router.post('/register', userController.createUser);
router.get(
    '/register/resendVerificationEmail',
    userController.resendVerificationEmail
);
router.get(
    '/register/verifyEmail/:token',
    userController.verifyRegistrationEmail
);

router.get('/deleteUser/verifyEmail/:token', userController.deleteUserEmail);
router.post('/password/reset', userController.getResetPasswordToken);
router.post('/password/set', userController.setNewPassword);
router.post('/login', userController.loginUser);
router.post('/admin/login', userController.loginAdmin);

router.get('/profile', validateToken, userController.getProfile);
router.post('/profile', validateToken, userController.updateProfile);
router.post('/changePassword', validateToken, userController.changePassword);

router.get('/generateQR', validateToken, userController.generateQR);

router.post('/addBuddies', validateToken, userController.addBuddies);
router.delete('/removeBuddies', validateToken, userController.removeBuddies);

router.post('/action', validateToken, userController.actionBuddyRequest);
router.post('/cancel-buddy-request', validateToken, userController.cancelBuddyRequest);
router.get('/buddy-requests', validateToken, userController.getBuddyRequests);
router.get('/buddy-requests-received', validateToken, userController.getBuddyRequestsReceived);
router.get('/mutual-friends/:user1Id/:user2Id', validateToken, userController.getMutualFriends);





router.get('/getBuddies', validateToken, userController.getBuddies);

router.post('/delete-user', validateToken, userController.deleteUser);

router.post('/addUserLocation', validateToken, userController.addUserLocation);
router.get('/getAllUsers', validateToken, userController.getAllUsers);

router.post('/changeEmail', validateToken, userController.changeEmail);

router.post(
    '/addDevice/:deviceId/:fcmToken',
    validateToken,
    userController.addDevice
);

router.post(
    '/enableTwoFactorAuthStep1',
    validateToken,
    userController.enableTwoFactorAuthStep1
);

router.post(
    '/verifyTwoFactorAuthStep2',
    validateToken,
    userController.enableTwoFactorAuthStep2
);

router.post('/validateTwoFactorAuth', userController.validateTwoFactorAuth);
router.post('/blockUser', validateToken, userController.blockUser);
router.get('/getBlockedUsers', validateToken, userController.getBlockUsers);

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    },
});
var upload = multer({ storage: storage });
router.post(
    '/profileImageUpload',
    validateToken,
    upload.single('image'),
    userController.profileImageUpload
);

router.get('/google', (req, res) => {
    res.send("<button><a href='/auth'>Login With Google</a></button>");
});

// Auth
router.get(
    '/auth',
    passport.authenticate('google', { scope: ['email', 'profile'] })
);

// Auth Callback
router.get(
    '/google/callback',
    passport.authenticate('google', {
        successRedirect: '/success',
        failureRedirect: '/failure',
    })
);

// Success
router.get('/success', userController.saveGoogleUser);
router.post('/saveGoogleUser', userController.createGoogleUser);

// failure
router.get('/failure', (req, res) => {
    return res.send('Error in sign up using google');
});
//Facebook login
router.post('/saveFacebookUser', userController.facebookLogin);

//Apple login
router.post('/callbacks/sign_in_with_apple', (req, res) => {
    const redirect = `intent://callback?${new URLSearchParams(
        req.body
    ).toString()}#Intent;package=${
        process.env.ANDROID_PACKAGE_IDENTIFIER
    };scheme=signinwithapple;end`;

    console.log(`Redirecting to ${redirect}`);

    res.redirect(307, redirect);
});

router.post('/sign_in_with_apple', userController.appleLogin);

router.post('/saveAppleUser', userController.appleLogin);
router.post('/userExperience', validateToken, userController.userExperience);
router.get('/profile/:id', validateToken, userController.getProfileById);

//Golf ScheduleSchema
router.post(
    '/addGolfSchedule',
    validateToken,
    golfScheduleController.addGolfSchedule
);

router.patch(
    '/updateGolfSchedule',
    validateToken,
    golfScheduleController.updateGolfSchedule
);

router.get(
    '/getUserGolfSchedules',
    validateToken,
    golfScheduleController.getGolfScheduleByUserId
);
router.get(
    '/getBuddiesGolfSchedule',
    validateToken,
    golfScheduleController.getBuddiesGolfSchedule
);
router.get(
    '/getCalendarGolfSchedule',
    validateToken,
    golfScheduleController.getCalendarSchedule
);
router.delete(
    '/deleteGolfSchedule/:scheduleId',
    validateToken,
    golfScheduleController.deleteGolfSchedule
);

router.post(
    '/inviteToGolfSchedule',
    validateToken,
    golfScheduleController.inviteToGolfSchedule
);

router.post(
    '/respondToGolfScheduleInvite',
    validateToken,
    golfScheduleController.respondToGolfScheduleInvite
);

router.post(
    '/requestToJoinGolfSchedule',
    validateToken,
    golfScheduleController.requestToJoinGolfSchedule
);

//Golf Style Schema
router.post('/addGolfStyle', validateToken, golfStyleController.addGolfStyle);

// Events
router.post('/createEvent', eventController.createEvent);
router.get('/getEvent', eventController.getEventData);
//
// router.post('/createUserEvent', eventController.createUserEvent);
router.post('/events/:eventId/user-events', eventController.createUserEvent);

router.get('/getUserEvent', eventController.getUserEventData);
router.get(`/event/:id`, eventController.getEventbyIdData);
router.get(`/eventUser/:id`, eventController.getUserEventByIdData);
router.put(`/updateEvent/:id`, eventController.updateEvent);

router.patch(
    '/updateGolfStyle',
    validateToken,
    golfStyleController.updateGolfStyle
);

router.get(
    '/getUserGolfStyle',
    validateToken,
    golfStyleController.getGolfStyleByUserId
);
router.get(
    '/getAllGolfStyles',
    validateToken,
    golfStyleController.getAllGolfStyles
);
router.delete(
    '/deleteGolfStyle/:styleId',
    validateToken,
    golfStyleController.deleteGolfStyle
);

router.get('/privacy', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

//Community Post Schema
router.post(
    '/addCommunityPost',
    validateToken,
    communityPostController.addCommunityPost
);

router.post(
    '/likeCommunityPost/:postId',
    validateToken,
    communityPostController.likeCommunityPost
);

router.delete(
    '/deleteCommunityPost/:postId',
    validateToken,
    communityPostController.deleteCommunityPost
);

router.get(
    '/getAllPostsByPlaceId',
    validateToken,
    communityPostController.getAllPostsByPlaceId
);

router.post(
    '/reportCommunityPost',
    validateToken,
    communityPostController.reportCommunityPost
);

//Post Comment Schema
router.post(
    '/addPostComment',
    validateToken,
    postCommentController.addPostComment
);

router.post(
    '/likePostComment/:commentId',
    validateToken,
    postCommentController.likePostComment
);

//Golf Courses
router.get(
    '/getAllGolfCourses/:lat/:lng/:radius',
    validateToken,
    golfCourseController.getAllGolfCourses
);

router.post('/addFavPlace', validateToken, golfCourseController.addFavPlace);

router.get(
    '/getFavPlaceUsersCount',
    validateToken,
    golfCourseController.getFavPlaceUsersCount
);

router.get(
    '/getFavPlaceBuddiesCount',
    validateToken,
    golfCourseController.getFavPlaceBuddiesCount
);

router.get(
    '/getAllFavPlaces',
    validateToken,
    golfCourseController.getAllFavPlaces
);

router.get(
    '/getPlaceDetails',
    validateToken,
    golfCourseController.getPlaceDetails
);
// router.put('/notifications/:notificationId'
router.put(
    '/updateNotification/:notificationId',
    validateToken,
    NotificationController.updateNotification
);
router.post(
    '/addNotification',
    validateToken,
    NotificationController.addNotification
);
router.get(
    '/getAllNotifications',
    validateToken,
    NotificationController.getAllNotifications
);

module.exports = router;
