'use strict';

const mongoose = require('mongoose');

const ClaimCourseSchema = new mongoose.Schema({
    state: {
        type: String,
    },
    zipCode: {
        type: String,
    },
    city: {
        type: String,
    },
    email: {
        type: String,
        required: [true, 'E-mail is required'],
    },
    firstName: {
        type: String,
        required: [true, 'First name is required'],
    },
    lastName: {
        type: String,
        required: [true, 'Last name is required'],
    },
    number: {
        type: String,
        required: [true, 'Phone number is required'],
    },
    course: {
        type: String,
        required: [true, 'Course name is required'],
    },
    courseAddress: {
        type: String,
        required: [true, 'Course Address is required'],
    },
    role: {
        type: String,
        required: [true, 'Role is required'],
    },
    user: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'eventUser',
        },
    ],
    events: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'eventUser',
        },
    ],
    courseId: {
        type: String,
    },
    verified: {
        type: Boolean,
        default: false,
    },
});

ClaimCourseSchema.set('timestamps', true);
toJSON: {
    virtuals: true;
}

const ClaimCourseSchemaModel = mongoose.model('ClaimCourse', ClaimCourseSchema);

module.exports = ClaimCourseSchemaModel;
