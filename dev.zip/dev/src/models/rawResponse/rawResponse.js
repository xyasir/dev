const mongoose = require('mongoose');

const RawResponseSchema = new mongoose.Schema({
    response: String,
    radius: Number,
    location: {
        latitude: String,
        longitude: String,
    },
    type: String,
    placeId: {
        type: String,
        default: null,
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
});

const RawResponseModel = mongoose.model('rawaresponse', RawResponseSchema);

module.exports = RawResponseModel;
