'use strict';

module.exports = {
    addInvitationSchema: require('./addInvitation'),
};
