'use strict';

const joi = require('joi');

const addInvitationSchema = joi
    .object({
        type: joi.string().required(),
        Status: joi.string().required(),
        sender: joi.string().required(),
        receiver: joi.string().required(),
        linkId: joi.string().required(),
    })
    .required();

module.exports = addInvitationSchema;
