'use strict';

const mongoose = require('mongoose');

const invitationSchema = new mongoose.Schema({
    type: String,
    status: String,
    sender: String,
    receiver: String,
    linkId: mongoose.Schema.Types.ObjectId,
});

invitationSchema.set('timestamps', true);

invitationSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

const InvitationModel = mongoose.model('Invitation', invitationSchema);

module.exports = InvitationModel;
