'use strict';

const mongoose = require('mongoose');

const GolfStyleSchema = new mongoose.Schema({
    type: Array,
    gameFlow: Array,
    skillLevel: String,
    experience: String,
    others: Array,
    isDeleted: Boolean,
    userId: String,
});

GolfStyleSchema.set('timestamps', true);

GolfStyleSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

const GolfStyleModel = mongoose.model('GolfStyle', GolfStyleSchema);

module.exports = GolfStyleModel;
