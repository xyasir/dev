'use strict';

const joi = require('joi');

const updateGolfStyleSchema = joi
    .object({
        golfStyleType: joi.array().optional(),
        golfStyleGameFlow: joi.array().optional(),
        golfStyleSkillLevel: joi.string().optional(),
        golfStyleExperience: joi.string().optional(),
        golfStyleOthers: joi.array().optional(),
    })
    .required();

module.exports = updateGolfStyleSchema;
