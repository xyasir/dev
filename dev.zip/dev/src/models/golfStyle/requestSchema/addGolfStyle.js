'use strict';

const joi = require('joi');

const addGolfStyleSchema = joi
    .object({
        golfStyleType: joi.array().required(),
        golfStyleGameFlow: joi.array().required(),
        golfStyleSkillLevel: joi.string().required(),
        golfStyleExperience: joi.string().required(),
        golfStyleOthers: joi.array().optional(),
    })
    .required();

module.exports = addGolfStyleSchema;
