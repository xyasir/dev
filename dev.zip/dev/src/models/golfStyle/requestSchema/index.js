'use strict';

module.exports = {
    addGolfStyleSchema: require('./addGolfStyle'),
    updateGolfStyleSchema: require('./updateGolfStyle'),
};
