'use strict';

module.exports = {
    addGolfScheduleSchema: require('./addGolfSchedule'),
    inviteToGolfScheduleSchema: require('./inviteToGolfSchedule'),
    respondToGolfScheduleInviteSchema: require('./respondToGolfScheduleInvite'),
    updateGolfScheduleSchema: require('./updateGolfSchedule'),
};
