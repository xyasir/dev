'use strict';

const joi = require('joi');

const addGolfScheduleSchema = joi
    .object({
        scheduleId: joi.string().required(),
        receiver: joi.string().required(),
    })
    .required();

module.exports = addGolfScheduleSchema;
