'use strict';

const joi = require('joi');

const addGolfScheduleSchema = joi
    .object({
        scheduleId: joi.string().required(),
        status: joi.string().valid('accepted', 'rejected').required(),
    })
    .required();

module.exports = addGolfScheduleSchema;
