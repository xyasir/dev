'use strict';

const joi = require('joi');

const updateGolfScheduleSchema = joi
    .object({
        scheduleId: joi.string().required(),
        title: joi.string().optional(),
        date: joi.string().optional(),
        courseLocation: joi.string().optional(), //1) local/willing to travel 2)
        time: joi.string().optional(),
        teeTime: joi.boolean().optional(),
        description: joi.string().optional(),
        remainingGolfers: joi.number().optional(),
        allowBuddiesToInvite: joi.boolean().optional(),
        comment: joi.string().optional(),
        golfStyleType: joi.array().optional(),
        golfStyleGameFlow: joi.array().optional(),
        golfStyleSkillLevel: joi.string().optional(),
        golfStyleExperience: joi.string().optional(),
        golfStyleOthers: joi.array().optional(),
        stayingToLocal: joi.boolean().optional(),
        willingToTravel: joi.boolean().optional(),
        availableToGolf: joi.boolean().optional(),
    })
    .required();

module.exports = updateGolfScheduleSchema;
