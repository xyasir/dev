'use strict';

const joi = require('joi');

const addGolfScheduleSchema = joi
    .object({
        title: joi.string().required(),
        date: joi.string().required(),
        courseLocation: joi.string().required(), //1) local/willing to travel 2)
        time: joi.string().required(),
        teeTime: joi.boolean().required(),
        description: joi.string().optional(),
        remainingGolfers: joi.number().optional().default(3),
        allowBuddiesToInvite: joi.boolean().optional().default(false),
        comment: joi.string().optional(),
        golfStyleType: joi.array().required(),
        golfStyleGameFlow: joi.array().required(),
        participants: joi.array().optional(),
        golfStyleSkillLevel: joi.string().required(),
        golfStyleExperience: joi.string().required(),
        golfStyleOthers: joi.array().optional(),
        availableToGolf: joi.boolean().required(),
        stayingToLocal: joi.boolean().optional(),
        willingToTravel: joi.boolean().optional(),
    })
    .required();

module.exports = addGolfScheduleSchema;
