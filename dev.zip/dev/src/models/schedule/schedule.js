'use strict';

const mongoose = require('mongoose');

const ScheduleSchema = new mongoose.Schema({
    userId: String,
    title: String,
    date: Date,
    participants: [{ userId: String }], //id, status=> added,requested,rejected
    courseLocation: String,
    startTime: String,
    endTime: String,
    teeTime: Boolean,
    description: String,
    remainingGolfers: Number,
    allowBuddiesToInvite: Boolean,
    comment: String,
    availableToGolf: Boolean,
    golfStyle: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'GolfStyle',
    },
    stayingToLocal: Boolean,
    willingToTravel: Boolean,
    isDeleted: Boolean,
    timeString: {
        required: false,
        type: String,
        default: null,
    },
});

ScheduleSchema.set('timestamps', true);

ScheduleSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

const ScheduleModel = mongoose.model('Schedule', ScheduleSchema);

module.exports = ScheduleModel;
