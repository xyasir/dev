'use strict';

module.exports = {
    UserModel: require('./user/user'),
    ScheduleModel: require('./schedule/schedule'),
    GolfStyleModel: require('./golfStyle/golfStyle'),
    InvitationModel: require('./invitation/invitation'),
    CommunityPostModel: require('./communityPost/communityPost'),
    PostCommentModel: require('./postComment/postComment'),
    FavPlaceModel: require('./favPlace/favPlace'),
    NotificationModel: require('./notification/notification'),
    LocationModel: require('./location/location'),
    ClaimCourseModel: require('./claimCourse/claimCourse')
};
