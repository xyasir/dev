'use strict';

const mongoose = require('mongoose');

const EventUserSchema = new mongoose.Schema({
    placeId:String,
    courseName:String,
    image: String,
    title: String,
    date: Date,
    startTime: String,
    location:String,
    interested: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    }],
    going: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    }],
    interestedCount: {
        type: Number,
        default: 0,
    },
    goingCount: {
        type: Number,
        default: 0,
    },
    eventFormat: {
        type: [String],
    },
    eventType: {
        type: [String],
    },
    openTo: {
        type: [String],
    },
    style:{
        type: Array,
        gameFlow: Array,
        skillLevel: String,
        experience: String,
        isDeleted: Boolean,
    },
    description: String,
    website: String,
    eventPost : [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Post',
    }],
    userId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    eventImage: 
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ImageEvent',
    },
    ClaimCourse: 
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ClaimCourse',
    },
  
});

EventUserSchema.set('timestamps', true);

const UserEventModel = mongoose.model('eventUser', EventUserSchema);

module.exports = UserEventModel;
