'use strict';

const joi = require('joi');
const { passwordValidator } = require('../../../validators');

const registerSchema = joi
    .object({
        password: passwordValidator.string().password().required(),
        email: joi.string().email().required(),
        firstName: joi.string().required(),
        lastName: joi.string().required(),
        phone: joi.string().optional(),
    })
    .unknown()
    .required();

module.exports = registerSchema;
