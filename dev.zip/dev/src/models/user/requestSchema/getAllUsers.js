'use strict';

const joi = require('joi');

const getAllUsersSchema = joi
    .object({
        location: joi.string().required(),
    })
    .required();

module.exports = getAllUsersSchema;
