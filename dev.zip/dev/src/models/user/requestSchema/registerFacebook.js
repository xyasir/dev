'use strict';

const joi = require('joi');

const registerFacebookSchema = joi
    .object({
        email: joi.string().email(),
        firstName: joi.string().required(),
        lastName: joi.string().required(),
        image: joi.string().optional(),
        facebookId: joi.string().when('email', {
            is: joi.exist(),
            then: joi.optional(),
            otherwise: joi.required(),
        }),
    })
    .required();

module.exports = registerFacebookSchema;
