const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({

  name: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    required: true,
  },
  text: {
    type: String,
    required: true,
  },
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
}],
userId: 
{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
},
  likesCount: {
    type: Number,
    default: 0,
  },
  eventUserId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'eventUser',
    },
  comments : [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Comment',
}],
}, {
  timestamps: true, // adds createdAt and updatedAt fields
});

const PostEventUserModel = mongoose.model('postEvent', postSchema);

module.exports = PostEventUserModel;
