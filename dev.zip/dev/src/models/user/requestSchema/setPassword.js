'use strict';

const joi = require('joi');
const { passwordValidator } = require('../../../validators');

const setPasswordSchema = joi
    .object({
        token: joi.string().required(),
        password: passwordValidator.string().password().required(),
    })
    .required();

module.exports = setPasswordSchema;
