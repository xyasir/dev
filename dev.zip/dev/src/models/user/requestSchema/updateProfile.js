'use strict';

const joi = require('joi');

const updateProfileSchema = joi
    .object({
        firstName: joi.string().optional(),
        lastName: joi.string().optional(),
        email: joi.string().email().optional(),
        dob: joi.string().optional(),
        experience: joi.string().optional(),
        handicap: joi.number().optional(),
        averageScore: joi.number().optional(),
        jobTitle: joi.string().optional(),
        company: joi.string().optional(),
        education: joi.string().optional(),
        story: joi.string().optional(),
        isOnboardingCompleted: joi.boolean().optional(),
        isScheduleChecked: joi.boolean().optional(),
    })
    .required();

module.exports = updateProfileSchema;
