const joi = require('joi');

const resetPasswordSchema = joi
    .object({
        email: joi.string().email().lowercase().trim().required(),
    })
    .required();

module.exports = resetPasswordSchema;
