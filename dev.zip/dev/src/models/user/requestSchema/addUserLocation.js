'use strict';

const joi = require('joi');

const addUserLocationSchema = joi
    .object({
        name: joi.string().required(),
        longitude: joi.string().required(),
        latitude: joi.string().required(),
        address: joi.string().required(),
    })
    .required();

module.exports = addUserLocationSchema;
