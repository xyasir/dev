const mongoose = require('mongoose');

const imageEventSchema = new mongoose.Schema({
  image: {
    type: String,
    required: true,
    placeId:String
  },
  userId:{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
},
eventUserId: {
  type: mongoose.Schema.Types.ObjectId,
  ref: 'eventUser',
},
}, {
  timestamps: true, // adds createdAt and updatedAt fields
});

const ImageEventModel = mongoose.model('ImageEvent', imageEventSchema);

module.exports = ImageEventModel;
