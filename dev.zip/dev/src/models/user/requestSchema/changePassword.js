'use strict';

const joi = require('joi');
const { passwordValidator } = require('../../../validators');

const changePasswordSchema = joi
    .object({
        oldPassword: passwordValidator.string().password().required(),
        newPassword: passwordValidator.string().password().required(),
    })
    .required();

module.exports = changePasswordSchema;
