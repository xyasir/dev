const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    required: true,
  },
  text: {
    type: String,
    required: true,
  },
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
}],
  likesCount: {
    type: Number,
    default: 0,
  },
  postId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'postEvent',
},
userId: 
{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
},
}, {
  timestamps: true, // adds createdAt and updatedAt fields
});

const CommentModel = mongoose.model('Comment', commentSchema);

module.exports = CommentModel;
