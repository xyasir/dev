'use strict';

const joi = require('joi');

const registerAppleSchema = joi
    .object({
        email: joi.string().email().optional(),
        firstName: joi.string().optional(),
        lastName: joi.string().optional(),
        image: joi.string().optional(),
        appleId: joi.string().when('email', {
            is: joi.exist(),
            then: joi.optional(),
            otherwise: joi.required(),
        }),
    })
    .required();

module.exports = registerAppleSchema;
