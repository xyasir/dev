'use strict';

const joi = require('joi');

const changeEmailSchema = joi
    .object({
        email: joi.string().email().required(),
    })
    .required();

module.exports = changeEmailSchema;
