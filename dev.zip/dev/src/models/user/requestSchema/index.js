'use strict';

module.exports = {
    registerUserSchema: require('./register'),
    resetPasswordSchema: require('./resetPassword'),
    setPasswordSchema: require('./setPassword'),
    updateProfileSchema: require('./updateProfile'),
    addUserLocationSchema: require('./addUserLocation'),
    getAllUsersSchema: require('./getAllUsers'),
    changeEmailSchema: require('./changeEmail'),
    changePasswordSchema: require('./changePassword'),
    registerFacebookSchema: require('./registerFacebook'),
    registerAppleSchema: require('./registerApple'),
};
