'use strict';

const joi = require('joi');

const blockUsersSchema = joi
    .object({
        userId: joi.string().required(),
    })
    .required();

module.exports = blockUsersSchema;
