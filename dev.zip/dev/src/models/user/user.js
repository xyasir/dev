'use strict';

const mongoose = require('mongoose');
const crypto = require('crypto');
const { v1: uuidv1 } = require('uuid');

const UserSchema = new mongoose.Schema({
    customLocations:[{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Location',
  }],
  claimedCourses : [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ClaimCourse',
  }],
  eventUser : [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'eventUser',
}],
buddyRequests: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    isAdmin: {
        type: Boolean,
        default: false,
    },
    buddyRequestsReceived: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    isAdmin: {
        type: Boolean,
        default: false,
    },
    passcode: {
        type: String,
        default: '',
    },
    firstName: {
        type: String,
        required: [true, 'First name is required for registration.'],
    },
    lastName: {
        type: String,
        required: [true, 'Last name is required for registration.'],
    },
    email: {
        type: String,
        unique: true,
        required: [true, 'Email is required for registration.'],
    },
    hash: String,
    salt: String,
    phone: String,
    image: String,
    dob: Date,
    city: String,
    buddies: [mongoose.Schema.Types.ObjectId],
    location: {
        name: String,
        longitude: String,
        latitude: String,
        address: String,
    },
    blockUsers: [{ UserId: String, date: Date }],
    isDeleted: Boolean,
    experience: String,
    handicap: Number,
    averageScore: Number,
    jobTitle: String,
    company: String,
    education: String,
    provider: String,
    deviceId: String,
    fcmToken: String,
    changePasswordToken: {
        token: {
            type: String,
            index: true,
        },
        expires: Date,
    },
    verifyEmailToken: {
        token: {
            type: String,
            index: true,
        },
        expires: Date,
    },
    deleteUserToken: {
        token: {
            type: String,
            index: true,
        },
        expires: Date,
    },
    isVerified: Boolean,
    adminVerified:Boolean,
    golfStyle: mongoose.Schema.Types.ObjectId,
    twoFactorAuth: Boolean,
    secret: String,
    story: String,
    isOnboardingCompleted: Boolean,
    isScheduleChecked: Boolean,
});

UserSchema.set('timestamps', true);

UserSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

/**
 * @param {string|object} A string or an object containing the { salt, hash }
 */

UserSchema.methods.setPassword = function (password) {
    let passwordHash;
    if (typeof password === 'string') {
        passwordHash = UserModel.generateNewPasswordHash(password);
    } else if (
        typeof password === 'object' &&
        typeof password.salt === 'string' &&
        typeof password.hash === 'string' &&
        password.salt.length > 0 &&
        password.hash.length > 0
    ) {
        passwordHash = password;
    } else {
        throw new Error(
            'The password parameter must be a string or an object {salt, hash}'
        );
    }
    this.salt = passwordHash.salt;
    this.hash = passwordHash.hash;
};

/**
 * @param {string} password
 * @return {object} The salt and hash for the password
 */
UserSchema.statics.generateNewPasswordHash = function (password) {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto
        .pbkdf2Sync(password, salt, 10000, 512, 'sha512')
        .toString('hex');
    return {
        salt,
        hash,
    };
};

/**
 * @param {string} password
 * @return {boolean}
 */

UserSchema.methods.validatePassword = function (password) {
    if (typeof this.salt === 'undefined') {
        return false;
    }
    const hash = crypto
        .pbkdf2Sync(password, this.salt, 10000, 512, 'sha512')
        .toString('hex');
    return this.hash === hash;
};

/**
 * @return {object}
 */
UserSchema.methods.getBasicProfile = function () {
    const profile = {
        _id: this._id,
        firstName: this.firstName,
        lastName: this.lastName,
        email: this.email,
        phone: this.phone,
        dob: this.dob,
        location: this.location,
        isDeleted: this.isDeleted,
        experience: this.experience,
        handicap: this.handicap,
        averageScore: this.averageScore,
        jobTitle: this.jobTitle,
        company: this.company,
        education: this.education,
        image: this.image,
        buddies: this.buddies,
        blockUsers: this.blockUsers,
        story: this.story,
    };
    return profile;
};

/**
 * @param {string} tokenExpiresField
 * @return {boolean}
 */

UserSchema.methods.tokenIsExpired = function (tokenExpiresField) {
    const expires = this.get(tokenExpiresField);

    if (!expires || !(expires instanceof Date)) {
        throw new Error(`Invalid token expires field ${tokenExpiresField}`);
    }

    return expires < new Date();
};

UserSchema.methods.registerTokenIsExpired = function (tokenExpiresField) {
    const expires = this.get(tokenExpiresField);

    if (!expires || !(expires instanceof Date)) {
        throw new Error(`Invalid token expires field ${tokenExpiresField}`);
    }

    return expires < new Date();
};

/**
 * Generate a change password token
 * @param {Date} expires
 */

UserSchema.methods.createNewChangePasswordToken = function (expires) {
    let tokenExpires;

    if (typeof expires !== 'undefined') {
        tokenExpires = expires;
    } else {
        tokenExpires = new Date();
        tokenExpires.setDate(tokenExpires.getDate() + 1);
    }
    this.changePasswordToken = {
        token: uuidv1(),
        expires: tokenExpires,
    };

    return this.changePasswordToken;
};

UserSchema.methods.createNewRegisterToken = function (expires) {
    let tokenExpires;

    if (typeof expires !== 'undefined') {
        tokenExpires = expires;
    } else {
        tokenExpires = new Date();
        tokenExpires.setDate(tokenExpires.getDate() + 1);
    }
    this.verifyEmailToken = {
        token: uuidv1(),
        expires: tokenExpires,
    };

    return this.verifyEmailToken;
};

UserSchema.methods.createNewDeleteToken = function (expires) {
    let tokenExpires;

    if (typeof expires !== 'undefined') {
        tokenExpires = expires;
    } else {
        tokenExpires = new Date();
        tokenExpires.setDate(tokenExpires.getDate() + 1);
    }
    this.deleteUserToken = {
        token: uuidv1(),
        expires: tokenExpires,
    };

    return this.deleteUserToken;
};

const UserModel = mongoose.model('User', UserSchema);

module.exports = UserModel;
