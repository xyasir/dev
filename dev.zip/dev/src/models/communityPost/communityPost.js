'use strict';

const mongoose = require('mongoose');

const communityPostSchema = new mongoose.Schema(
    {
        text: String,
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
        placeId: String,
        likes: Array,
        reportedBy: [{ userId: String, message: String }],
        isDeleted: Boolean,
    },
    { toJSON: { virtuals: true } }
);

communityPostSchema.virtual('user', {
    ref: 'User',
    localField: 'userId',
    foreignField: '_id',
    justOne: true,
});

communityPostSchema.set('timestamps', true);

communityPostSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

const CommunityPostModel = mongoose.model('CommunityPost', communityPostSchema);

module.exports = CommunityPostModel;
