'use strict';

const joi = require('joi');

const addCommunityPostSchema = joi
    .object({
        text: joi.string().required(),
        placeId: joi.string().required(),
    })
    .required();

module.exports = addCommunityPostSchema;
