'use strict';

module.exports = {
    addCommunityPostSchema: require('./addCommunityPost'),
};
