'use strict';

const mongoose = require('mongoose');

const NotificationSchema = new mongoose.Schema(
    {
        text: String,
        isRead: String,
        isDeleted: String,
        type: String,
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
        linkId: mongoose.Schema.Types.ObjectId,
    },
    { toJSON: { virtuals: true } }
);

NotificationSchema.set('timestamps', true);

NotificationSchema.virtual('user', {
    ref: 'User', // the collection/model name
    localField: 'userId',
    foreignField: '_id',
    justOne: true, // default is false
});

NotificationSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

const NotificationModel = mongoose.model('Notification', NotificationSchema);

module.exports = NotificationModel;
