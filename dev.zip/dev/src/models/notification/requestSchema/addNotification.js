'use strict';

const joi = require('joi');

const addNotificationSchema = joi
    .object({
        text: joi.string().required(),
        type: joi.string().required(),
        linkId: joi.string().required(),
    })
    .required();

module.exports = addNotificationSchema;
