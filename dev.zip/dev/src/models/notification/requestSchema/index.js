'use strict';

module.exports = {
    addNotificationSchema: require('./addNotification'),
};
