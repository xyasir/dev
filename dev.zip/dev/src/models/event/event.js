'use strict';

const mongoose = require('mongoose');

const EventSchema = new mongoose.Schema({
    course: String,
    address: {
        street: String,
        city: String,
        zipcode: String,
    },
    user: {
        firstName: 'String',
        lastName: 'String',
    },
    contactInfo: {
        email: 'String',
        phone: 'Number',
        City: 'String',
    },
    event: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'userEvent',
    }],
});

EventSchema.set('timestamps', true)
toJSON: { virtuals: true }

const EventModel = mongoose.model('Event', EventSchema);

module.exports = EventModel;
