'use strict';

const mongoose = require('mongoose');

const PostCommentSchema = new mongoose.Schema(
    {
        postId: String,
        text: String,
        likes: Array,
        userId: String,
        isDeleted: Boolean,
    },
    { toJSON: { virtuals: true } }
);

PostCommentSchema.virtual('user', {
    ref: 'User',
    localField: 'userId',
    foreignField: '_id',
    justOne: true,
});

PostCommentSchema.set('timestamps', true);

PostCommentSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

const PostCommentModel = mongoose.model('PostComment', PostCommentSchema);

module.exports = PostCommentModel;
