'use strict';

module.exports = {
    addPostCommentSchema: require('./addPostComment'),
};
