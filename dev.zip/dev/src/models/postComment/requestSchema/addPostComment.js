'use strict';

const joi = require('joi');

const addPostCommentSchema = joi
    .object({
        postId: joi.string().required(),
        text: joi.string().required(),
    })
    .required();

module.exports = addPostCommentSchema;
