'use strict';

const mongoose = require('mongoose');

const UserEventSchema = new mongoose.Schema({
    image: String,
    title: String,
    date: Date,
    startTime: String,
    eventFormat: {
        type: [String],
    },
    eventType: {
        type: [String],
    },
    openTo: {
        type: [String],
    },
    description: String,
    website: String,
    eventSchema: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Event',
    },
});

UserEventSchema.set('timestamps', true);

const UserEventModel = mongoose.model('userEvent', UserEventSchema);

module.exports = UserEventModel;
