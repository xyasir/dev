'use strict';

const mongoose = require('mongoose');

const FavPlaceSchema = new mongoose.Schema({
    placeId: String,
    userId: String,
    isDeleted: Boolean,
});

FavPlaceSchema.set('timestamps', true);

FavPlaceSchema.pre('save', function () {
    this.updateAt = new Date();
    return Promise.resolve();
});

const FavPlaceModel = mongoose.model('FavPlace', FavPlaceSchema);

module.exports = FavPlaceModel;
