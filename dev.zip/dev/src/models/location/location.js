const mongoose = require('mongoose');

const LocationSchema = new mongoose.Schema({
    name : {
      type: String,
      required: [true, 'Name is required.'],
    },
    address :  {
      type: String,
      required: [true, 'Address is required.'],
    },
    longitude :  {
      type: String,
      required: [true, 'Longitude is required.'],
    },
    latitude :  {
      type: String,
      required: [true, 'Latitude is required.'],
    },

})

const LocationModel = mongoose.model('Location', LocationSchema);

module.exports = LocationModel;
