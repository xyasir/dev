'use strict';

module.exports = {
    addCustomLocationSchema: require('./addLocations'),
};
