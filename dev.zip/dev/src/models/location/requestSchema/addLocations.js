'use strict';

const joi = require('joi');

const addCustomLocationSchema = joi
    .object({
        name: joi.string().required(),
        longitude: joi.string().required(),
        latitude: joi.string().required(),
        address: joi.string().required(),
    })
    .required();

module.exports = addCustomLocationSchema;
