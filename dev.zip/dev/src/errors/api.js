'use strict';

const i18n = require('i18n');

/**
 * Generic Api error
 */

class ApiError extends Error {
    constructor(message, status, ...args) {
        args.unshift(message);
        super(...args);
        Error.captureStackTrace(this, ApiError);
        this.message = i18n.__(message);
        this.status = status;
    }
}

module.exports = ApiError;
