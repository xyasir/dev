'use strict';

module.exports = {
    ApiError: require('./api'),
    RegisterError: require('./register'),
};
