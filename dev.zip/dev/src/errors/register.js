'use strict';

const ApiError = require('./api');
const i18n = require('i18n');

class RegisterError extends ApiError {
    constructor(message, status, ...args) {
        message = i18n.__(message);
        super(message, status, ...args);
        ApiError.captureStackTrace(this, RegisterError);
    }
}

module.exports = RegisterError;
