'use strict';

/**
 * Wrapper for mongoose
 */

const mongoose = require('mongoose');

module.exports = {
    connect: async (mongoConfig) => {
        let url = `mongodb://${mongoConfig.username}:${mongoConfig.password}@${mongoConfig.host}:${mongoConfig.port}/${mongoConfig.dbname}`;
        if (process.env.NODE_ENV === 'production') {
            url = process.env.MONGO_URI;
        }
        return mongoose.connect(url, {
            useNewUrlParser: true,
            sslCA: `${__dirname}/../cert/ca-certificate.crt`,
        });
    },
    disconnect: async () => mongoose.disconnect(),
    mongoose,
};
