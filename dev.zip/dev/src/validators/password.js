const Joi = require('joi');

module.exports = Joi.extend((joi) => ({
    base: joi.string(),
    type: 'string',
    messages: {
        'string.password':
            '{#label} must be at least 8 characters long and have at least one upper case letter, one digit and one symbol',
    },
    rules: {
        password: {
            validate(value, helpers) {
                if (!value || value.length < 8) {
                    return helpers.error('string.password', { value });
                }

                const uppercase = /[A-Z]/g;
                const digits = /[0-9]/g;
                const symbols = /[\W_]/g;

                const isValid =
                    uppercase.test(value) &&
                    digits.test(value) &&
                    symbols.test(value);

                if (!isValid) {
                    return helpers.error('string.password', { value });
                }

                return value;
            },
        },
    },
}));
