'use strict';

module.exports = {
    passwordValidator: require('./password'),
};
