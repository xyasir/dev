var admin = require('firebase-admin');

var serviceaAccount = require('./service-account.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceaAccount),
    databaseURL: 'https://a183c-d-rtdb.firebaseio.com/',
});

module.exports.admin = admin;
