const jwt = require('jsonwebtoken');

function validateToken(req, res, next) {
    //get token from request header
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
        return res.status(400).send('Authorization token is not provided');
    }
    const token = authHeader.split(' ')[1];

    //the request header contains the token "Bearer <token>", split the string and use the second value in the split array.
    if (token == null)
        return res.sendStatus(400).send('Authorization token is not provided');
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            return res
                .status(403)
                .send('Token is Invalid! Try Signing in again!');
        } else {
            req.user = user;
            next();
        }
    });
}
const isAdmin = (req, res, next) => {
    if (!req.user.user.isAdmin) {
        return res.status(403).json({ message: 'Forbidden Request' });
    }
    next();
};
module.exports = {
    validateToken,
    isAdmin

};
