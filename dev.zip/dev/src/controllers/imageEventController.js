const { EventUserService, imageEventService } = require('../services');
// addEventUserAction

const addImageEvent = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(200).json({
                message: 'success',
                data: 'Oops, event image is not uploaded.',
            });
        } else {
            var userData = await imageEventService.imageEvent(req, res);
            return res.status(200).json({
                message: 'success',
                data: userData,
            });
        }
    } catch (error) {
        console.log('errorsssss', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const UpdateImageEvent = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(200).json({
                message: 'success',
                data: 'Oops, event image is not uploaded.',
            });
        } else {
            var userData = await imageEventService.updateImageEvent(req, res);
            return res.status(200).json({
                message: 'success',
                data: userData,
            });
        }
    } catch (error) {
  return res.status(error.status).json({
            message: error.message,
        });
    }
};

module.exports = {
    addImageEvent,
    UpdateImageEvent,
};
