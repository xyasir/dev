'use strict';

const { UserService } = require('../services');
const jwt = require('jsonwebtoken');
const passport = require('passport');
const AppleAuth = require('apple-auth');
const { UserModel } = require('../models');


const create = async (req, res) => {
    try {
        await UserService.createUser(req.body, req);
        return res.status(201).json({
            message: 'A verification email is sent on your email.',
        });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const facebookLogin = async (req, res) => {
    try {
        let user = await UserService.facebookLogin(req.body, req);
        return res.status(201).json({
            message: 'success',
            data: user,
        });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const appleLogin = async (req, res) => {
    try {
        const auth = new AppleAuth(
            {
                // use the bundle ID as client ID for native apps, else use the service ID for web-auth flows
                // https://forums.developer.apple.com/thread/118135
                client_id:
                    req.query.useBundleId === 'true'
                        ? process.env.BUNDLE_ID
                        : process.env.SERVICE_ID,
                team_id: process.env.TEAM_ID,
                redirect_uri:
                    'https://linkedgolfapp.com/callbacks/sign_in_with_apple', // does not matter here, as this is already the callback that verifies the token after the redirection
                key_id: process.env.KEY_ID,
            },
            process.env.KEY_CONTENTS.replace(/\|/g, '\n'),
            'text'
        );

        const accessToken = await auth.accessToken(req.query.code);

        const idToken = jwt.decode(accessToken.id_token);

        const userID = idToken?.sub;

        // `userEmail` and `userName` will only be provided for the initial authorization with your app
        const userEmail = idToken?.email;

        let payload = {
            email: userEmail,
            firstName: req?.query?.firstName,
            lastName: req?.query?.lastName,
            appleId: userID,
        };
        let user = await UserService.appleLogin(payload, req);

        return res.status(201).json({
            message: 'success',
            data: user,
        });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const resendVerificationEmail = async (req, res) => {
    try {
        await UserService.resendVerificationEmail(req.query, req);
        return res.status(201).json({
            message:
                'A verification email is sent again.Please check your email to verify.',
        });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const verifyRegistrationEmail = async (req, res) => {
    try {
        await UserService.verifyRegistrationEmail(req.params);
        return res
            .status(200)
            .json({ message: 'Email Verification succeeded!' });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const deleteUserEmail = async (req, res) => {
    try {
        await UserService.deleteUserEmail(req.params);
        return res
            .status(200)
            .json({ message: 'Account deleted successfully!' });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const getResetPasswordToken = async (req, res) => {
    try {
        const token = await UserService.getResetPasswordToken(req.body);
        return res.status(200).json(token);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const setNewPassword = async (req, res) => {
    try {
        const user = await UserService.setNewPassword(req.body);
        return res.status(200).json(user);
    } catch (error) {
    return res.status(error.status).json({
            message: error.message,
        });
    }
};
const loginAdmin = async (req, res) => {
    let user = await UserModel.findOne({
        passcode: req.body.passcode,
    });
    if (user) {
        const userId = user._id; // Retrieve the userId from the user object

        const body = { _id: userId };
        const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
        let status = user.verifyEmailToken.token ? false : true;
        return res.status(200).json({
            data: {
                token,
                userId, // Include the userId in the response
            },
        });
    }
};

//
// const loginAdmin = async (req, res) => {
//     let user = await UserModel.findOne({
//         passcode: req.body.passcode,
//     });
//     if (user) {
//         const body = { _id: user._id };
//         const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
//         let status = user.verifyEmailToken.token ? false : true;
//         return res.status(200).json({
//             data: {
//                 token,
//             },
//         });
//     }
// };
//
const login = async (req, res, next) => {
    passport.authenticate('local', { session: false }, async (err, user) => {
        try {
            if (err || !user) {
                return res.status(404).json('Invalid Credentials.');
            }
            req.login(user, { session: false }, async (error) => {
                if (error)
                    return res
                        .status(400)
                        .json('An error occurred while try to login.');
                const body = { _id: user._id };

                if (user.isDeleted)
                    return res
                        .status(400)
                        .json(
                            'The User you are trying to logged in has been deleted.'
                        );
                if (user.twoFactorAuth)
                    return res
                        .status(200)
                        .json(
                            'Two factor authentication for this user is enabled. Please validate user to get the login token'
                        );
                const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
                let status = user.verifyEmailToken.token ? false : true;
                if (status) {
                    // Retrieve the userId from the user object
                    const userId = user._id;

                    return res.status(200).json({
                        data: {
                            token,
                            userId, // Include the userId in the response
                        },
                    });
                } else {
                    return res.status(400).json({
                        message:
                            'Your account is not verified. Please verify before logging in!',
                    });
                }
            });
        } catch (error) {
            return res.status(error.status).json({
                message: error.message,
            });
        }
    })(req, res, next);
};

// const login = async (req, res, next) => {
//     passport.authenticate('local', { session: false }, async (err, user) => {
//         try {
//             if (err || !user) {
//                 return res.status(404).json('Invalid Credentials.');
//             }
//             req.login(user, { session: false }, async (error) => {
//                 if (error)
//                     return res
//                         .status(400)
//                         .json('An error occurred while try to login.');
//                 const body = { _id: user._id };

//                 if (user.isDeleted)
//                     return res
//                         .status(400)
//                         .json(
//                             'The User you are trying to logged in has been deleted.'
//                         );
//                 if (user.twoFactorAuth)
//                     return res
//                         .status(200)
//                         .json(
//                             'Two factor authentication for this user is enabled. Please validate user to get the login token'
//                         );
//                 const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
//                 let status = user.verifyEmailToken.token ? false : true;
//                 if (status) {
//                     return res.status(200).json({
//                         data: {
//                             token,
//                         },
//                     });
//                 } else {
//                     return res.status(400).json({
//                         message:
//                             'You account is not verified. Please verify before logging in!',
//                     });
//                 }
//             });
//         } catch (error) {
//             return res.status(error.status).json({
//                 message: error.message,
//             });
//         }
//     })(req, res, next);
// };

const getProfile = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.getProfile(user);
        return res.status(200).json({ data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const updateProfile = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.updateProfile(user, req.body);
        return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const changePassword = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.changePassword(user, req.body);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const getMutualFriends = async (req, res) => {
    try {
        // const { user } = req.user;
        const profile = await UserService.getMutualFriends(req,res);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const cancelBuddyRequest = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.cancelBuddyRequest(user, req.body);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const getBuddyRequests = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.getBuddyRequests(user, req.body);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const getBuddyRequestsReceived = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.getBuddyRequestsReceived(user, req.body);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const removeBuddies = async (req, res) => {
    try {
        const { user } = req.user;
        console.log('user',user);
        const profile = await UserService.removeBuddies(user, req.body);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const addBuddies = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.addBuddies(user, req.body);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const actionBuddyRequest = async (req, res) => {
    try {

        const data = await UserService.actionBuddyRequest(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const getBuddies = async (req, res) => {
    try {
        const { user } = req.user;
        const buddies = await UserService.getBuddies(user, req.query);
        return res.status(200).json({ message: 'success', data: buddies });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const deleteUser = async (req, res) => {
    try {
        const { user } = req.user;
        const message = await UserService.deleteUser(user, req);
        res.status(200).json({ message, data: null });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const addUserLocation = async (req, res) => {
    try {
        const { user } = req.user;
        let userData = await UserService.addUserLocation(user, req.body);
        return res.status(200).json({ message: 'success', data: userData });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const getAllUsers = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.getUsers(req.query, user);
        return res.status(200).json({ data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const changeEmail = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.changeEmail(user, req.body);
        res.status(200).json({ data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const generateQR = async (req, res) => {
    try {
        const { user } = req.user;
        const qrCode = await UserService.generateQRCode(user);

        return res.status(200).json({ data: qrCode });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const blockUser = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.blockUser(user, req.query);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const getBlockUsers = async (req, res) => {
    try {
        const { user } = req.user;
        const blockUsers = await UserService.getBlockUsers(user);
        if (blockUsers)
            return res
                .status(200)
                .json({ message: 'success', data: blockUsers });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const profileImageUpload = async (req, res) => {
    try {
        const { user } = req.user;
        if (!req.file) {
            return res.status(200).json({
                message: 'success',
                data: 'Oops, profile image is not uploaded.',
            });
        } else {
            var userData = await UserService.saveImage(user, req);
            return res.status(200).json({
                message: 'success',
                data: userData,
            });
        }
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const saveGoogleUser = async (req, res) => {
    try {
        let user = {};
        if (req.user) user = await UserService.createGoogleUser(req.user, req);
        return res.status(201).json(user);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const createGoogleUser = async (req, res) => {
    try {
        let user = {
            name: {
                givenName: req.body.firstName,
                familyName: req.body.lastName,
            },
            email: req.body.email,
            image: req.body.image || null,
        };
        const profile = await UserService.createGoogleUser(user, req);
        if (profile)
            return res.status(200).json({ message: 'success', data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const userExperience = async (req, res) => {
    try {
        const { user } = req.user;
        await UserService.userExperience(user, req.body);
        return res
            .status(200)
            .json({ message: 'Your feedback has been submitted' });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const enableTwoFactorAuthStep1 = async (req, res) => {
    try {
        const { user } = req.user;
        let result = await UserService.enableTwoFactorAuthStep1(user);

        return res.status(200).json(result);
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const enableTwoFactorAuthStep2 = async (req, res) => {
    try {
        const { user } = req.user;
        const result = await UserService.enableTwoFactorAuthStep2(
            user,
            req.body
        );

        return res.status(200).json(result);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const validateTwoFactorAuth = async (req, res) => {
    try {
        const result = await UserService.validateTwoFactorAuth(req.body);
        if (result.validate) {
            const body = { _id: result.user._id };
            const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
            let status = result.user.verifyEmailToken.token ? false : true;
            if (status) {
                return res.status(200).json({ data: { token } });
            } else {
                return res.status(400).json({
                    message:
                        'You account is not verified. Please verify before logging in!',
                });
            }
        }
        return res
            .status(200)
            .json('Validation Token is incorrect or expired.');
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const addDevice = async (req, res) => {
    try {
        const { user } = req.user;
        const profile = await UserService.addDevice(user, req.params);
        res.status(200).json({ data: profile });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const searchGeneral = async (req, res) => {
    try {
        const { user } = req.user;
        const response = await UserService.searchGeneral(user, req.query);
        return res.status(200).json(response);
    } catch (error) {
        if (error.status) {
            return res.status(error.status).json({
                message: error.message,
            });
        }
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const getProfileById = async (req, res) => {
    try {
        const { id } = req.params;
        const response = await UserService.getProfileById(id);
        return res.status(200).json({ data: response });
    } catch (error) {
        console.log(error);
        if (error.status) {
            return res.status(error.status).json({
                message: error.message,
            });
        }
        return res.status(500).json({
            message: error.message,
        });
    }
};
module.exports = {
    createUser: create,
    verifyRegistrationEmail,
    getResetPasswordToken,
    setNewPassword,
    loginUser: login,
    loginAdmin,
    getProfile,
    updateProfile,
    changePassword,
    addBuddies,
    removeBuddies,
    getBuddies,
    deleteUser,
    addUserLocation,
    getAllUsers,
    changeEmail,
    enableTwoFactorAuthStep1,
    enableTwoFactorAuthStep2,
    validateTwoFactorAuth,
    generateQR,
    blockUser,
    getBlockUsers,
    profileImageUpload,
    saveGoogleUser,
    createGoogleUser,
    resendVerificationEmail,
    facebookLogin,
    userExperience,
    appleLogin,
    addDevice,
    deleteUserEmail,
    searchGeneral,
    getProfileById,
    actionBuddyRequest,
    cancelBuddyRequest,
    getBuddyRequests,
    getBuddyRequestsReceived,
    getMutualFriends
};
