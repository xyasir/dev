'use strict';

const { ApiError } = require('../errors');
const { NotificationsService } = require('../services');

const updateNotification = async (req, res) => {
    try {

        const data = await NotificationsService.updateNotificatioon(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const addNotification = async (req, res) => {
    try {
        const { user } = req.user;
        const post = await NotificationsService.addNotification(req.body, user);

        return res.status(201).json(post);
    } catch (error) {
        if (error.isJoi) {
            return new ApiError(error.details[0].message, 400);
        }
        return res.status(500).json({
            message: error.message,
        });
    }
};

const getAllNotifications = async (req, res) => {
    try {
        const { user } = req.user;
        const notifications = await NotificationsService.getAllNotifications(
            user
        );

        return res
            .status(200)
            .json({ message: 'success', data: notifications });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    addNotification,
    getAllNotifications,
    updateNotification
};
