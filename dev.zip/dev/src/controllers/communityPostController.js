'use strict';

const { ApiError } = require('../errors');
const { CommunityPostService } = require('../services');

const addCommunityPost = async (req, res) => {
    try {
        const { user } = req.user;
        const post = await CommunityPostService.addCommunityPost(
            req.body,
            user
        );

        return res.status(201).json(post);
    } catch (error) {
        if (error.isJoi) {
            return new ApiError(error.details[0].message, 400);
        }
        return res.status(500).json({
            message: error.message,
        });
    }
};

const deleteCommunityPost = async (req, res) => {
    try {
        const { user } = req.user;
        const post = await CommunityPostService.deleteCommunityPost(
            req.params,
            user
        );

        return res.status(200).json(post);
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const likeCommunityPost = async (req, res) => {
    try {
        const { user } = req.user;
        const post = await CommunityPostService.likeCommunityPost(
            req.params,
            user
        );

        return res.status(200).json(post);
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const getAllPostsByPlaceId = async (req, res) => {
    try {
        const { user } = req.user;
        const posts = await CommunityPostService.getAllPostsByPlaceId(
            req.query,
            user
        );

        return res.status(200).json({ message: 'success', data: posts });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const reportCommunityPost = async (req, res) => {
    try {
        const { user } = req.user;
        const post = await CommunityPostService.reportCommunityPost(
            req.body,
            user
        );

        return res.status(200).json(post);
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    addCommunityPost,
    deleteCommunityPost,
    likeCommunityPost,
    getAllPostsByPlaceId,
    reportCommunityPost,
};
