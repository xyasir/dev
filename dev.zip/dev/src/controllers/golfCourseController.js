'use strict';
const { GolfCourseService } = require('../services');

const getAllGolfCourses = async (req, res) => {
    try {
        const { user } = req.user;
        const { lat, lng, radius } = req.params;

        const params = {
            lat: parseFloat(lat),
            lng: parseFloat(lng),
            radius: parseInt(radius)
        };
        console.log('????',req.params.lat);
        console.log('<<<<',req.params.lng);

        const golfCourses = await GolfCourseService.getAllGolfCourses(
            user,
            params
        );

        return res.status(200).json({ message: 'success', data: golfCourses });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const addFavPlace = async (req, res) => {
    try {
        const { user } = req.user;
        const favPlace = await GolfCourseService.addFavPlace(user, req.body);

        return res.status(200).json({ message: 'success', data: favPlace });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const deleteClaimCourse = async (req, res) => {
    try {
        const schedule = await GolfCourseService.deleteClaimedCourse(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const claimGolfCourse = async (req, res) => {
    try {
        // Extract the request data
        const {
            state,
            zipCode,
            city,
            email,
            firstName,
            lastName,
            number,
            course,
            courseAddress,
            role,
            courseId
        } = req.body;

        // Perform validation
        if (!email) {
            return res.status(400).json({ error: 'Email is required.' });
        }

        if (!firstName) {
            return res.status(400).json({ error: 'First name is required.' });
        }

        if (!lastName) {
            return res.status(400).json({ error: 'Last name is required.' });
        }

        if (!number) {
            return res.status(400).json({ error: 'Number is required.' });
        }

        if (!course) {
            return res.status(400).json({ error: 'Course is required.' });
        }

        if (!courseAddress) {
            return res.status(400).json({ error: 'Course address is required.' });
        }

        if (!role) {
            return res.status(400).json({ error: 'Role is required.' });
        }

        const claimedCourse = await GolfCourseService.claimGolfCourse(req, res);

        return res.status(201).json({ message: 'Success', data: claimedCourse });
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};


// const claimGolfCourse = async (req, res) => {
//     try {
//         const claimedCourse = await GolfCourseService.claimGolfCourse(req, res);

//         return res.status(201).json({message:'Success',data:claimedCourse});
//     } catch (error) {
//         console.log('ERR: ', error);
//         return res.status(error.status).json({
//             message: error.message,
//         });
//     }
// };
const getClaimGolfCourse = async (req, res) => {
    try {
        const schedule = await GolfCourseService.getClaimGolfCourse(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
// claimGolfCourseByAdmin
const claimGolfCourseByAdmin = async (req, res) => {
        try {
            const schedule = await GolfCourseService.claimGolfCourseByAdmin(req, res);
    
            return res.status(201).json(schedule);
        } catch (error) {
            console.log('ERR: ', error);
        }
    };

const getFavPlaceUsersCount = async (req, res) => {
    try {
        const count = await GolfCourseService.getFavPlaceUsersCount(
            req.query.placeId
        );

        return res.status(200).json({ message: 'success', data: count });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const getFavPlaceBuddiesCount = async (req, res) => {
    try {
        const { user } = req.user;
        const count = await GolfCourseService.getFavPlaceBuddiesCount(
            req.query.placeId,
            user
        );

        return res.status(200).json({ message: 'success', data: count });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const getAllFavPlaces = async (req, res) => {
    try {
        const { user } = req.user;
        const favPlaces = await GolfCourseService.getAllFavPlaces(user);

        return res.status(200).json({ message: 'success', data: favPlaces });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

const getPlaceDetails = async (req, res) => {
    try {
        const { user } = req.user;
        const golfCourse = await GolfCourseService.getPlaceDetails(
            req.query,
            user
        );

        return res.status(200).json({ message: 'success', data: golfCourse });
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    getAllGolfCourses,
    addFavPlace,
    getFavPlaceUsersCount,
    getFavPlaceBuddiesCount,
    getAllFavPlaces,
    getPlaceDetails,
    claimGolfCourse,
    claimGolfCourseByAdmin,
    getClaimGolfCourse,
    deleteClaimCourse
};
