const {EventUserService, PostEventUserService} = require('../services')

const likePostEventUser = async (req, res) => {
    try {
        const data = await PostEventUserService.likePostEventUser(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const addPostEventUser = async (req, res) => {
    try {
        const data = await PostEventUserService.addPostEventUser(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const getPostEventUserById = async (req, res) => {
    
    try {
        const schedule = await PostEventUserService.getPostEventUserById(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const updatePostEventUser = async (req, res) => {
    try {
        const schedule = await PostEventUserService.updatePostEventUser(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const deletePostEventUser = async (req, res) => {
    try {
        const schedule = await PostEventUserService.deletePostEventUser(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};

module.exports = {
    addPostEventUser,
    getPostEventUserById,
    updatePostEventUser,
    deletePostEventUser,
    likePostEventUser
}