'use strict';

const { ApiError } = require('../errors');
const { PostCommentService } = require('../services');

const addPostComment = async (req, res) => {
    try {
        const { user } = req.user;
        const comment = await PostCommentService.addPostComment(req.body, user);

        return res.status(201).json(comment);
    } catch (error) {
        if (error.isJoi) {
            return new ApiError(error.details[0].message, 400);
        }
        return res.status(500).json({
            message: error.message,
        });
    }
};

const likePostComment = async (req, res) => {
    try {
        const { user } = req.user;
        const comment = await PostCommentService.likePostComment(
            req.params,
            user
        );

        return res.status(200).json(comment);
    } catch (error) {
        return res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    addPostComment,
    likePostComment,
};
