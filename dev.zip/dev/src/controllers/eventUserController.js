const {EventUserService} = require('../services')
// addEventUserAction
const addEventUserAction = async (req, res) => {
    try {
        const data = await EventUserService.addEventUserAction(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const profileImageEventUpload = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                message: 'error',
                data: 'Oops, profile image is not uploaded.',
            });
        } else {
            var userData = await EventUserService.saveImageEvent(req,res);
            return res.status(200).json({
                message: 'success',
                data: userData,
            });
        }
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const addEventUserImage = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(200).json({
                message: 'success',
                data: 'Oops, event image is not uploaded.',
            });
        } else {
            var userData = await EventUserService.addEventUserImage(req,res);
            return res.status(200).json({
                message: 'success',
                data: userData,
            });
        }
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
}
const addEventUser = async (req, res) => {
    try {
        const data = await EventUserService.addEventUser(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const getEventUserByIdData = async (req, res) => {
    try {
        const schedule = await EventUserService.getEventUserById(req.params.id);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const updateEventUser = async (req, res) => {
    try {
        const schedule = await EventUserService.updateEventUser(req, res);
        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const getAllEventUser = async (req, res) => {
    try {
        const schedule = await EventUserService.getAllEventUser(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
        // return res.status(error.status).json({
        //     message: error.message,
        // });
    }
};
const deleteEventUser = async (req, res) => {
    try {
        const schedule = await EventUserService.deleteEventUser(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};

module.exports = {
    addEventUserAction,
    profileImageEventUpload,
    addEventUser,
    addEventUserImage,
    getEventUserByIdData,
    updateEventUser,
    deleteEventUser,
    getAllEventUser
}