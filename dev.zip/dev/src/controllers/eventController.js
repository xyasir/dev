'use strict';
const { EventService } = require('../services');

const createEvent = async (req, res) => {
    try {
        const schedule = await EventService.addEvent(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
        // return res.status(error.status).json({
        //     message: error.message,
        // });
    }
};
const updateEvent = async (req, res) => {
    try {
        const schedule = await EventService.updateEvent(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};

const getEventData = async (req, res) => {
    try {
        const schedule = await EventService.getEvent(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
        // return res.status(error.status).json({
        //     message: error.message,
        // });
    }
};

const createUserEvent = async (req, res) => {
    try {
        const schedule = await EventService.addUserEvent(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
        // return res.status(error.status).json({
        //     message: error.message,
        // });
    }
};
const getUserEventData = async (req, res) => {
    try {
        const schedule = await EventService.getUserEvent(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
        // return res.status(error.status).json({
        //     message: error.message,
        // });
    }
};
const getEventbyIdData = async (req, res) => {
    try {
        const schedule = await EventService.getEventbyId(req.params.id);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const getUserEventByIdData = async (req, res) => {
    try {
        const schedule = await EventService.getUserEventById(req.params.id);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};

module.exports = {
    createEvent,
    getEventData,
    createUserEvent,
    getUserEventData,
    getUserEventByIdData,
    getEventbyIdData,
    updateEvent,
};
