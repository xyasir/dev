const {EventUserService, PostEventUserService, commentPostEventService} = require('../services')

const likeCommnetPostEventUser = async (req, res) => {
    try {
        const data = await commentPostEventService.likeCommnetPostEventUser(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const addCommnetPostEventUser = async (req, res) => {
    try {
        const data = await commentPostEventService.addCommnetPostEventUser(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const getCommentByPostId = async (req, res) => {
    try {
        const schedule = await commentPostEventService.getCommentByPostId(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const updateCommentPostEventUser = async (req, res) => {
    try {
        const schedule = await commentPostEventService.updateCommentPostEventUser(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};
const deleteCommentPostEventUser = async (req, res) => {
    try {
        const schedule = await commentPostEventService.deleteCommentPostEventUser(req, res);

        return res.status(201).json(schedule);
    } catch (error) {
        console.log('ERR: ', error);
    }
};

module.exports = {
    addCommnetPostEventUser,
    getCommentByPostId,
    updateCommentPostEventUser,
    deleteCommentPostEventUser,
    likeCommnetPostEventUser
}