'use strict';

const joi = require('joi');
const { GolfStyleService } = require('../services');
const { addGolfStyleSchema } = require('../models/golfStyle/requestSchema');

const addGolfStyle = async (req, res) => {
    try {
        const { user } = req.user;
        let validateRequest = joi.attempt(req.body, addGolfStyleSchema);

        const golfStyle = await GolfStyleService.addGolfStyle(
            validateRequest,
            user
        );
        return res.status(201).json(golfStyle);
    } catch (error) {
        if (error.isJoi) return res.status(400).json(error.details[0].message);
        if (error.status) return res.status(error.status).json(error.message);
        return res.status(500).json(error.message);
    }
};

const getGolfStyleByUserId = async (req, res) => {
    try {
        const { user } = req.user;
        const golfStyle = await GolfStyleService.getGolfStyleByUserId(user);

        if (golfStyle)
            return res
                .status(200)
                .json({ message: 'success', data: golfStyle });
    } catch (error) {
        if (error.status) return res.status(error.status).json(error.message);
        return res.status(500).json(error.message);
    }
};

const getAllGolfStyles = async (req, res) => {
    try {
        const { user } = req.user;
        const golfStyle = await GolfStyleService.getAllGolfStyles(user);

        if (golfStyle)
            return res
                .status(200)
                .json({ message: 'success', data: golfStyle });
    } catch (error) {
        if (error.status) return res.status(error.status).json(error.message);
        return res.status(500).json(error.message);
    }
};

const deleteGolfStyle = async (req, res) => {
    try {
        const { user } = req.user;
        const style = await GolfStyleService.deleteGolfStyle(req.params, user);
        return res.status(201).json(style);
    } catch (error) {
        if (error.status) return res.status(error.status).json(error.message);
        return res.status(500).json(error.message);
    }
};

const updateGolfStyle = async (req, res) => {
    try {
        const { user } = req.user;

        const golfStyle = await GolfStyleService.updateGolfStyle(
            req.body,
            user
        );
        return res.status(201).json(golfStyle);
    } catch (error) {
        if (error.isJoi) return res.status(400).json(error.details[0].message);
        if (error.status) return res.status(error.status).json(error.message);
        return res.status(500).json(error.message);
    }
};

module.exports = {
    addGolfStyle,
    getGolfStyleByUserId,
    getAllGolfStyles,
    deleteGolfStyle,
    updateGolfStyle,
};
