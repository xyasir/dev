const {LocationService} = require('../services')

const addLocation = async (req, res) => {
    try {
        const data = await LocationService.addLocation(req, res);

        return res.status(201).json(data);
    } catch (error) {
        console.log('ERR: ', error);
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

module.exports = {
    addLocation
}