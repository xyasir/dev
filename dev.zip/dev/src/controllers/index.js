'use strict';

module.exports = {
    userController: require('./userController'),
    golfScheduleController: require('./golfScheduleController'),
    golfStyleController: require('./golfStyleController'),
    communityPostController: require('./communityPostController'),
    postCommentController: require('./postCommentController'),
    golfCourseController: require('./golfCourseController'),
    NotificationController: require('./notificationController'),
    eventController: require('./eventController'),
    locationController: require('./locationController'),
    eventUserController: require('./eventUserController'),
    postEventController: require('./postEventUserController'),
    commentPostEventController: require('./commentPostEventController'),
    imageEventEventController: require('./imageEventController'),

};
