'use strict';
const { GolfScheduleService } = require('../services');

const addGolfSchedule = async (req, res) => {
    try {
        const { user } = req.user;

        const schedule = await GolfScheduleService.addSchedule(user, req.body);

        return res.status(201).json(schedule);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const updateGolfSchedule = async (req, res) => {
    try {
        const { user } = req.user;

        const schedule = await GolfScheduleService.updateGolfSchedule(
            req.body,
            user
        );

        return res.status(201).json(schedule);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const getGolfScheduleByUserId = async (req, res) => {
    try {
        const { user } = req.user;
        const golfSchedule = await GolfScheduleService.getGolfScheduleByUserId(
            user,
            req
        );
        return res.status(200).json({ message: 'success', data: golfSchedule });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const getBuddiesGolfSchedule = async (req, res) => {
    try {
        const { user } = req.user;
        const golfSchedules = await GolfScheduleService.getBuddiesGolfSchedule(
            user,
            req
        );

        return res
            .status(200)
            .json({ message: 'success', data: golfSchedules });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const deleteGolfSchedule = async (req, res) => {
    try {
        const schedule = await GolfScheduleService.deleteGolfSchedule(
            req.params
        );
        return res.status(201).json(schedule);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const inviteToGolfSchedule = async (req, res) => {
    try {
        const { user } = req.user;

        const schedule = await GolfScheduleService.inviteToGolfSchedule(
            user,
            req.body
        );

        return res.status(201).json(schedule);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const respondToGolfScheduleInvite = async (req, res) => {
    try {
        const { user } = req.user;

        const schedule = await GolfScheduleService.respondToGolfScheduleInvite(
            user,
            req.body
        );

        return res.status(201).json(schedule);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};

const requestToJoinGolfSchedule = async (req, res) => {
    try {
        const { user } = req.user;

        const schedule = await GolfScheduleService.requestToJoinGolfSchedule(
            user,
            req.query
        );

        return res.status(201).json(schedule);
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
const getCalendarSchedule = async (req, res) => {
    try {
        const { user } = req.user;

        const schedule = await GolfScheduleService.getCalendarSchedule(
            user,
            req
        );

        return res.status(201).json({ message: 'success', data: schedule });
    } catch (error) {
        return res.status(error.status).json({
            message: error.message,
        });
    }
};
module.exports = {
    addGolfSchedule,
    getGolfScheduleByUserId,
    getBuddiesGolfSchedule,
    deleteGolfSchedule,
    inviteToGolfSchedule,
    respondToGolfScheduleInvite,
    requestToJoinGolfSchedule,
    updateGolfSchedule,
    getCalendarSchedule,

};
