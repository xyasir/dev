const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const GoogleStrategy = require('passport-google-oauth2').Strategy;
const { UserModel } = require('./models');
//for valid routes

function initializePassport() {
    passport.use(
        new LocalStrategy(
            {
                usernameField: 'username',
                passwordField: 'password',
            },
            async function (username, password, cb) {
                let query = {
                    $or: [],
                };
                query.$or.push({
                    email: username,
                });
                return UserModel.findOne(query)
                    .then((user) => {
                        if (!user) {
                            return cb(null, false);
                        }
                        if (!user.validatePassword(password)) {
                            return cb(null, false);
                        }
                        return cb(null, user);
                    })
                    .catch((err) => cb(err));
            }
        )
    );

    passport.serializeUser((user, done) => {
        done(null, user);
    });
    passport.deserializeUser(function (user, done) {
        done(null, user);
    });

    passport.use(
        new GoogleStrategy(
            {
                clientID:
                    '112578584214-17fk68c3eutrjur803vq4o416sjnl.apps.googleusercontent.com',
                clientSecret: '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',
                callbackURL: process.env.GOOGLE_CALLBACK_URL,
                passReqToCallback: true,
            },
            function (request, accessToken, refreshToken, profile, done) {
                return done(null, profile);
            }
        )
    );
}

module.exports = initializePassport;
