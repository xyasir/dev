'use strict';

const url = require('url');
const path = require('path');
const swaggerJsDoc = require('swagger-jsdoc');

const serverConfig = require('../config').server;

const options = {
    definition: {
        swagger: '2.0',
        info: {
            description: 'This is API documentation for Golf Course Project',
            version: '1.0.0',
            title: 'Golf Course API',
            contact: {
                email: 'apiteam@golfcourse.com',
            },
        },
        basePath: '/',
        schemes: ['http'],
        host: 'localhost:3000',
    },
    apis: ['src/routes/*.js', 'src/swagger-definitions/**/*.yml'],
};

function swaggerJson(req) {
    if (process.env.SWAGGER_SCHEME) {
        options.definition.schemes = [process.env.SWAGGER_SCHEME];
    }
    if (process.env.SWAGGER_HOST) {
        options.definition.host = process.env.SWAGGER_HOST;
    } else {
        let port = serverConfig.port;
        if (process.env.PORT_FOR_SWAGGER) {
            port = process.env.PORT_FOR_SWAGGER;
        }
        options.definition.host = `${req.hostname}:${port}`;
    }

    if (process.env.SWAGGER_BASE_PATH) {
        options.definition.basePath = process.env.SWAGGER_BASE_PATH;
    } else {
        options.definition.basePath = path.dirname(url.parse(req.url).pathname);
    }
    const swaggerSpec = swaggerJsDoc(options);
    return swaggerSpec;
}

module.exports = {
    swaggerJson,
};
