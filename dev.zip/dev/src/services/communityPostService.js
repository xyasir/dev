'use strict';

const { CommunityPostModel, UserModel } = require('../models');
const { ApiError } = require('../errors');
const ObjectId = require('mongodb').ObjectId;
const {
    addCommunityPostSchema,
} = require('../models/communityPost/requestSchema');
const joi = require('joi');
const PostCommentService = require('../services/postCommentService');
const { sendAndroid } = require('../utility');
const GolfCourseService = require('../services/golfCourseService');

const addCommunityPost = async (body, user) => {
    try {
        let validateRequest = joi.attempt(body, addCommunityPostSchema);

        let userData = await UserModel.findOne({
            _id: new ObjectId(user._id),
        });

        let post = new CommunityPostModel({
            userId: new ObjectId(userData._id),
            text: validateRequest.text,
            placeId: validateRequest.placeId,
            likes: [],
            reportedBy: [],
            isDeleted: false,
        });

        await post.save();

        let userIds = await GolfCourseService.getAllUsersByPlaceId(
            validateRequest.placeId
        );
        for (let i = 0; i < userIds.length; i++) {
            let tempUser = await UserModel.findOne({
                _id: new ObjectId(userIds[i].userId),
            });

            if (tempUser.fcmToken) {
                await sendAndroid(
                    tempUser.fcmToken,
                    'Community Post Created',
                    userData.firstName +
                        ' ' +
                        userData.lastName +
                        ' created a community post on your favourite place.'
                );
            }
        }

        return post;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const deleteCommunityPost = async (request, user) => {
    try {
        const filter = {
            _id: new ObjectId(request.postId),
            userId: new ObjectId(user._id),
        };
        const update = { isDeleted: true };
        await CommunityPostModel.findOneAndUpdate(filter, update);

        return await CommunityPostModel.findOne(filter);
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const likeCommunityPost = async (request, user) => {
    try {
        if (!request.postId) throw new ApiError('errors.post.post_id', 400);

        const filter = { _id: new ObjectId(request.postId) };

        let post = await CommunityPostModel.findOne(filter);

        if (!post || post.isDeleted)
            throw new ApiError('errors.post.post_not_exist', 400);

        if (post.likes.includes(user._id.toString())) {
            const index = post.likes.indexOf(user._id.toString());
            if (index > -1) {
                post.likes.splice(index, 1); // 2nd parameter means remove one item only
            }
        } else post.likes.push(user._id.toString());

        await post.save();
        return post;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const getAllPostsByPlaceId = async (request, user) => {
    try {
        if (!request.placeId) throw new ApiError('errors.post.place_id', 400);

        const filter = { placeId: request.placeId, isDeleted: false };

        let finalPosts = [];
        let posts = await CommunityPostModel.find(filter, {
            isDeleted: 0,
        })
            .populate({
                path: 'user',
                select: 'firstName lastName email phone image experience dob buddies',
            })
            .lean();

        if (posts.length > 0)
            for (let i = 0; i < posts.length; i++) {
                var Obj = {
                    post: {},
                    comments: '',
                    placeDetail: '',
                };
                let comments = await PostCommentService.getAllCommentsByPostId(
                    posts[i]._id.toString()
                );
                let placeDetail =
                    await GolfCourseService.getPlaceDetailsGeneral(posts[i]);
                Obj.comments = comments;
                Obj['post'] = posts[i];
                Obj.placeDetail = placeDetail;
                Obj.likedByMe = posts[i].likes.includes(user._id.toString());
                finalPosts.push(Obj);
            }

        return finalPosts;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const reportCommunityPost = async (request, user) => {
    try {
        if (!request.postId) throw new ApiError('errors.post.post_id', 400);

        const filter = { _id: new ObjectId(request.postId) };

        let post = await CommunityPostModel.findOne(filter);

        if (!post || post.isDeleted)
            throw new ApiError('errors.post.post_not_exist', 400);

        if (post.userId.toString() === user._id.toString())
            throw new ApiError('errors.post.not_report_own', 400);

        if (post.reportedBy.find((x) => x.userId === user._id.toString())) {
            throw new ApiError('errors.post.reported-by-you', 404);
        } else {
            var reportedUser = {};
            reportedUser.userId = user._id.toString();
            reportedUser.message = request.message;
            post.reportedBy.push(reportedUser);
        }

        await post.save();
        return post;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

module.exports = {
    addCommunityPost,
    deleteCommunityPost,
    likeCommunityPost,
    getAllPostsByPlaceId,
    reportCommunityPost,
};
