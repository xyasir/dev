'use strict';

module.exports = {
    UserService: require('./userService'),
    GolfScheduleService: require('./golfScheduleService'),
    GolfStyleService: require('./golfStyleService'),
    CommunityPostService: require('./communityPostService'),
    PostCommentService: require('./postCommentService'),
    GolfCourseService: require('./golfCourseService'),
    NotificationsService: require('./notificationService'),
    EventService: require('./eventService'),
    LocationService: require('./locationsService'),
    EventUserService: require('./eventUserService'),
    PostEventUserService: require('./postEventUserService'),
    commentPostEventService: require('./commentPostEventService'),
    imageEventService: require('./imageEventService'),
};
