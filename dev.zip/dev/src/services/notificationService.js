'use strict';

const { NotificationModel } = require('../models');
const { ApiError } = require('../errors');
const ObjectId = require('mongodb').ObjectId;
const {
    addNotificationSchema,
} = require('../models/notification/requestSchema');
const joi = require('joi');
const { UserModel } = require('../models');
// 
// router.put('/notifications/:notificationId', async (req, res, next) => {
    const updateNotificatioon=async (req, res) => {
    try {
      const { notificationId } = req.params;
      const { isRead } = req.body;
  console.log('req.params',req.params);
  console.log('req.body',req.body);

      // Update the notification with the specified notificationId
      const notification = await NotificationModel.findByIdAndUpdate(
        notificationId,
        { isRead },
        { new: true }
      );
  
      if (!notification) {
        return res.status(404).json({ message: 'Notification not found' });
      }
  
      res.json({ notification });
    } catch (error) {
    }
  }
const addNotification = async (body, user) => {
    try {
        let validateRequest = joi.attempt(body, addNotificationSchema);

        let userData = await UserModel.findOne({
            _id: new ObjectId(user._id),
        });

        let notification = new NotificationModel({
            userId: userData._id,
            text: validateRequest.text,
            type: validateRequest.type,
            isRead: false,
            isDeleted: false,
            linkId: new ObjectId(validateRequest.linkId),
        });

        await notification.save();
        return notification;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const getAllNotifications = async (user) => {
    try {
        const filter = { linkId: user._id.toString(), isDeleted: false };

        let notifications = await NotificationModel.find(filter, {
            isDeleted: 0,
        }).populate({
            path: 'user',
            select: 'firstName lastName email image',
        });
        console.log('notifications',notifications.length);
        return notifications;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};






module.exports = {
    addNotification,
    getAllNotifications,
    updateNotificatioon
};
