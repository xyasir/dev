/* eslint-disable no-useless-escape */
'use strict';

const joi = require('joi');
const jwt = require('jsonwebtoken');
const { UserModel, NotificationModel } = require('../models');
const {
    changePasswordSchema,
    registerUserSchema,
    resetPasswordSchema,
    setPasswordSchema,
    updateProfileSchema,
    addUserLocationSchema,
    changeEmailSchema,
    registerFacebookSchema,
    registerAppleSchema,
} = require('../models/user/requestSchema');
const { RegisterError, ApiError } = require('../errors');
const { sendEmail, sendEmailVerification } = require('../transporter');
const qr = require('qrcode');
const speakeasy = require('speakeasy');
const axios = require('axios');
const querystring = require('querystring');
const { sendAndroid } = require('../utility');
const GolfScheduleService = require('../services/golfScheduleService');
const GolfStyleService = require('../services/golfStyleService');
const GolfCourseService = require('../services/golfCourseService');
const fs = require('fs');
const { v1: uuidv1 } = require('uuid');

// Download Image Helper Function
const downloadImageFromURL = async (url, filename) => {
    axios
        .get(url, { responseType: 'stream' })
        .then((response) => {
            // Saving file to working directory
            let pic = `./uploads/`;
            return response.data.pipe(fs.createWriteStream(pic + filename));
        })
        .catch((error) => {
            console.log(error);
        });
};

const create = async (body, req) => {
    try {
        let validateRequest = joi.attempt(body, registerUserSchema);
        let user = await UserModel.findOne({
            email: validateRequest.email,
            isDeleted: false,
        });

        if (user) {
            throw new RegisterError('errors.user.email_or_phone_exists', 400);
        }

        let image = `${process.env.HOST_PROTOCOL}://${req.host}/uploads/profile.png`;
        let host = `${process.env.HOST_PROTOCOL}://${req.host}/`;

        if (process.env.NODE_ENV === 'development') {
            image = `http://${req.host}:${process.env.PORT}/uploads/profile.png`;
            host = `http://${req.host}:${process.env.PORT}/`;
        }

        user = new UserModel({
            firstName: validateRequest.firstName,
            lastName: validateRequest.lastName,
            email: validateRequest.email,
            password: validateRequest.password,
            phone: validateRequest.phone,
            dob: null,
            buddies: [],
            blockUsers: [],
            location: {},
            isDeleted: false,
            experience: '',
            handicap: 0,
            averageScore: 0,
            provider: 'Local',
            jobTitle: '',
            company: '',
            education: '',
            image,
            isVerified: false,
            story: '',
            isOnboardingCompleted: false,
            isScheduleChecked: false,
        });

        // Create a new token with a default expire time
        let needToGenerateVerifyToken = true;
        if (
            user.verifyEmailToken &&
            user.verifyEmailToken.token &&
            !user.tokenIsExpired('verifyEmailToken.expires')
        ) {
            needToGenerateVerifyToken = false;
        }

        // if token exist and not expire then no need to generate token again
        let token;
        if (needToGenerateVerifyToken) {
            user.verifyEmailToken = {};
            token = user.createNewRegisterToken();
        } else {
            token = user.verifyEmailToken;
        }

        user.setPassword(validateRequest.password);
        let currentUser = await UserModel.findOne({
            email: validateRequest.email,
            isDeleted: true,
        });
        if (currentUser) {
            await UserModel.findByIdAndUpdate(currentUser._id, {
                firstName: validateRequest.firstName,
                lastName: validateRequest.lastName,
                email: validateRequest.email,
                password: validateRequest.password,
                phone: validateRequest.phone,
                dob: null,
                buddies: [],
                blockUsers: [],
                location: {},
                isDeleted: false,
                experience: '',
                handicap: 0,
                averageScore: 0,
                provider: 'Local',
                jobTitle: '',
                company: '',
                education: '',
                image,
                isVerified: false,
                story: '',
                isOnboardingCompleted: false,
                isScheduleChecked: false,
            });
        } else {
            await user.save();
        }

        await sendEmailVerification({
            to: user.email,
            subject: 'Email Verification',
            token: `${host}register/verifyEmail/${token.token}`,
            host,
        });

        return await user.getBasicProfile();
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const resendVerificationEmail = async (query, req) => {
    try {
        let gmailUser = await UserModel.findOne({
            $and: [
                { email: query.email },
                {
                    $or: [{ provider: 'Google' }, { provider: 'Facebook' }],
                },
                { isDeleted: false },
            ],
        }).exec();
        if (gmailUser)
            throw new RegisterError(
                'errors.user.gmail_or_facebook_accounts_already_verified',
                400
            );

        let user = await UserModel.findOne({
            email: query.email,
            provider: 'Local',
            isDeleted: false,
        });

        if (!user)
            throw new RegisterError('errors.user.email_does_not_exists', 400);

        if (user.isVerified)
            throw new RegisterError('errors.user.account_verified', 400);

        let host = `${process.env.HOST_PROTOCOL}://${req.host}/`;

        if (process.env.NODE_ENV === 'development') {
            host = `http://${req.host}:${process.env.PORT}/`;
        }
        // Create a new token with a default expire time
        let needToGenerateVerifyToken = true;
        if (
            user.verifyEmailToken &&
            user.verifyEmailToken.token &&
            !user.tokenIsExpired('verifyEmailToken.expires')
        ) {
            needToGenerateVerifyToken = false;
        }

        // if token exist and not expire then no need to generate token again
        let token;
        if (needToGenerateVerifyToken) {
            user.verifyEmailToken = {};
            token = user.createNewRegisterToken();
        } else {
            token = user.verifyEmailToken;
        }

        await user.save();

        await sendEmailVerification({
            to: query.email,
            subject: 'Resend Verification Email',
            token: `${host}register/verifyEmail/${token.token}`,
            host,
        });

        return await user.getBasicProfile();
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const verifyRegistrationEmail = async (request) => {
    try {
        const user = await UserModel.findOne({
            'verifyEmailToken.token': request.token,
            isDeleted: false,
        }).exec();

        if (!user) {
            throw new ApiError(
                'errors.user.account_verified_or_not_exists',
                404
            );
        }

        if (user.registerTokenIsExpired('verifyEmailToken.expires')) {
            throw new ApiError('errors.user.register_token_expired', 404);
        }

        user.verifyEmailToken = {};
        (user.isVerified = true), await user.save();
        return await user.getBasicProfile();
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const deleteUserEmail = async (request) => {
    try {
        const user = await UserModel.findOne({
            'deleteUserToken.token': request.token,
            isDeleted: false,
        }).exec();

        if (!user) {
            throw new ApiError(
                'errors.user.account_verified_or_not_exists',
                404
            );
        }

        if (user.registerTokenIsExpired('deleteUserToken.expires')) {
            throw new ApiError('errors.user.deleteUser_token_expired', 404);
        }

        user.deleteUserToken = {};
        (user.isDeleted = true), await user.save();

        return await user.getBasicProfile();
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const createGoogleUser = async (user, req) => {
    try {
        let gmailUser = await UserModel.findOne({
            email: user.email,
        }).exec();
        if (gmailUser && !gmailUser.isDeleted) {
            const body = { _id: gmailUser._id };
            const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
            return token;
        }
        let body = '';
        if (gmailUser && gmailUser.isDeleted) {
            await UserModel.findByIdAndUpdate(gmailUser._id, {
                firstName: user.name.givenName,
                lastName: user.name.familyName,
                email: user.email,
                phone: '',
                dob: '',
                buddies: [],
                blockUsers: [],
                location: {},
                isDeleted: false,
                experience: '',
                handicap: 0,
                averageScore: 0,
                provider: 'Google',
                isVerified: true,
                story: '',
                isOnboardingCompleted: false,
                isScheduleChecked: false,
            });
            body = { _id: gmailUser._id };
        } else {
            let password = Math.random().toString(36).substring(2, 11);

            let pic = '';
            if (user.image) pic = user.image;
            else {
                pic = `${process.env.HOST_PROTOCOL}://${req.host}/uploads/profile.png`;
                if (process.env.NODE_ENV === 'development')
                    pic = `http://${req.host}:${process.env.PORT}/uploads/profile.png`;
            }

            let newUser = new UserModel({
                firstName: user.name.givenName,
                lastName: user.name.familyName,
                email: user.email,
                password: password,
                image: pic,
                phone: '',
                dob: '',
                buddies: [],
                blockUsers: [],
                location: {},
                isDeleted: false,
                experience: '',
                handicap: 0,
                averageScore: 0,
                provider: 'Google',
                isVerified: true,
                story: '',
                isOnboardingCompleted: false,
                isScheduleChecked: false,
            });

            newUser.setPassword(password);
            await newUser.save();
            body = { _id: newUser._id };
        }

        const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
        return token;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const googleSignupFlow = async (code) => {
    try {
        await axios.post(
            'https://oauth2.googleapis.com/token',
            querystring.stringify({
                code,
                client_id:
                    '112578584214-17fk68c3eutrju0l5r803vq4o416sjnl.apps.googleusercontent.com',
                client_secret: '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',
                redirect_uri: process.env.GOOGLE_CALLBACK_URL,
                grant_type: 'authorization_code',
            }),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );
    } catch (error) {
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const facebookLogin = async (user, req) => {
    try {
        let validateRequest = joi.attempt(user, registerFacebookSchema);
        let identifier = '';
        if (user.email) identifier = validateRequest.email;
        else identifier = validateRequest.facebookId;

        let facebookUser = await UserModel.findOne({
            $and: [
                {
                    email: identifier,
                },
            ],
        }).exec();
        if (facebookUser && !facebookUser.isDeleted) {
            const body = { _id: facebookUser._id };
            const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
            return token;
        }
        let body = '';
        if (facebookUser && facebookUser.isDeleted) {
            await UserModel.findByIdAndUpdate(facebookUser._id, {
                firstName: validateRequest.firstName,
                lastName: validateRequest.lastName,
                email: identifier,
                phone: '',
                dob: null,
                buddies: [],
                blockUsers: [],
                location: {},
                isDeleted: false,
                experience: '',
                handicap: 0,
                averageScore: 0,
                provider: 'Facebook',
                isVerified: true,
                story: '',
                isOnboardingCompleted: false,
                isScheduleChecked: false,
            });
            body = { _id: facebookUser._id };
        } else {
            let password = Math.random().toString(36).substring(2, 11);
            let imageId = uuidv1();
            let pic = '';

            if (validateRequest.image) {
                await downloadImageFromURL(
                    validateRequest.image,
                    imageId + '.png'
                );
                pic = `${process.env.HOST_PROTOCOL}://${req.host}/uploads/${imageId}.png`;
                if (process.env.NODE_ENV === 'development')
                    pic = `http://${req.host}:${process.env.PORT}/uploads/${imageId}.png`;
            } else {
                pic = `${process.env.HOST_PROTOCOL}:${req.host}/uploads/profile.png`;
                if (process.env.NODE_ENV === 'development')
                    pic = `http://${req.host}:${process.env.PORT}/uploads/profile.png`;
            }

            let newUser = new UserModel({
                firstName: validateRequest.firstName,
                lastName: validateRequest.lastName,
                email: identifier,
                password: password,
                image: pic,
                phone: '',
                dob: null,
                buddies: [],
                blockUsers: [],
                location: {},
                isDeleted: false,
                experience: '',
                handicap: 0,
                averageScore: 0,
                provider: 'Facebook',
                isVerified: true,
                story: '',
                isOnboardingCompleted: false,
                isScheduleChecked: false,
            });

            newUser.setPassword(password);
            await newUser.save();
            body = { _id: newUser._id };
        }

        const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
        return token;
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        throw new ApiError(error.message, 400);
    }
};

const appleLogin = async (user, req) => {
    try {
        let validateRequest = joi.attempt(user, registerAppleSchema);
        let identifier = '';
        if (user.email) identifier = validateRequest.email;
        else if (user.appleId) identifier = validateRequest.appleId;
        let appleUser = await UserModel.findOne({
            $and: [
                {
                    email: identifier,
                },
            ],
        }).exec();
        if (appleUser && !appleUser.isDeleted) {
            const body = { _id: appleUser._id };
            const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
            return token;
        }
        let body = '';
        if (
            appleUser &&
            appleUser.isDeleted &&
            validateRequest?.firstName &&
            validateRequest?.lastName
        ) {
            await UserModel.findByIdAndUpdate(appleUser._id, {
                isDeleted: false,
            });
            body = { _id: appleUser._id };
        } else if (
            appleUser &&
            appleUser.isDeleted &&
            !validateRequest?.firstName &&
            !validateRequest?.lastName
        ) {
            throw new ApiError('errors.user.unlink_apple_id', 404);
        } else {
            let password = Math.random().toString(36).substring(2, 11);

            let pic = '';
            if (validateRequest.image) pic = validateRequest.image;
            else {
                pic = `${process.env.HOST_PROTOCOL}://${req.host}/uploads/profile.png`;
                if (process.env.NODE_ENV === 'development')
                    pic = `http://${req.host}:${process.env.PORT}/uploads/profile.png`;
            }

            let newUser = new UserModel({
                firstName: validateRequest?.firstName,
                lastName: validateRequest?.lastName,
                email: identifier,
                password: password,
                image: pic,
                phone: '',
                dob: null,
                buddies: [],
                blockUsers: [],
                location: {},
                isDeleted: false,
                experience: '',
                handicap: 0,
                averageScore: 0,
                provider: 'Apple',
                isVerified: true,
                story: '',
                isOnboardingCompleted: false,
                isScheduleChecked: false,
            });

            newUser.setPassword(password);
            await newUser.save();
            body = { _id: newUser._id };
        }

        const token = jwt.sign({ user: body }, process.env.JWT_SECRET);
        return token;
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        throw new ApiError(error.message, 500);
    }
};

const getResetPasswordToken = async (request) => {
    try {
        let validateRequest = joi.attempt(request, resetPasswordSchema);
        let user = await UserModel.findOne({
            email: validateRequest.email,
            isDeleted: false,
        });
        if (!user) {
            throw new ApiError('errors.user.not_found', 404);
        }

        // Create a new token with a default expire time
        let needToGeneratePasswordToken = true;
        if (
            user.changePasswordToken &&
            user.changePasswordToken.token &&
            !user.tokenIsExpired('changePasswordToken.expires')
        ) {
            needToGeneratePasswordToken = false;
        }

        // if token exist and not expire then no need to generate token again
        let token;
        if (needToGeneratePasswordToken) {
            user.changePasswordToken = {};
            token = user.createNewChangePasswordToken();
        } else {
            token = user.changePasswordToken;
        }

        await user.save();

        try {
            await sendEmail({
                to: user.email,
                subject: 'Reset Password',
                text: `Password reset token: ${token.token}`,
            });
            return {
                data: {
                    message: 'Password reset token is sent your email',
                },
            };
        } catch (error) {
            throw new ApiError(error.message, 500);
        }
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const setNewPassword = async (request) => {
    try {
        const validRequest = joi.attempt(request, setPasswordSchema);

        const user = await UserModel.findOne({
            'changePasswordToken.token': validRequest.token,
            isDeleted: false,
        }).exec();

        if (!user) {
            throw new ApiError('errors.user.token_expired', 404);
        }

        if (user.tokenIsExpired('changePasswordToken.expires')) {
            throw new ApiError('errors.user.token_expired', 404);
        }

        user.changePasswordToken = {};
        user.setPassword(validRequest.password);
        await user.save();
        const data = await user.getBasicProfile();
        return {
            data,
        };
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const getProfile = async (user) => {
    try {
        const profile = await UserModel.findOne(
            { _id: user._id, isDeleted: false },
            { salt: 0, hash: 0, isDeleted: 0, changePasswordToken: 0 }
        )
            .populate('customLocations')
            .populate('claimedCourses');

        if (!profile) {
            throw new ApiError('errors.user.not_found', 404);
        }

        let buddiesId = profile.buddies;

        // Fetch buddies
        const buddies = await UserModel.aggregate([
            {
                $addFields: {
                    fullName: {
                        $concat: ['$firstName', ' ', '$lastName'],
                    },
                },
            },
            {
                $match: {
                    _id: { $in: buddiesId },
                },
            },
            {
                $project: {
                    salt: 0,
                    hash: 0,
                    isDeleted: 0,
                    changePasswordToken: 0,
                    createdAt: 0,
                    updatedAt: 0,
                    __v: 0,
                },
            },
        ]);

        for (let i = 0; i < buddies.length; i++) {
            if (buddies[i]._id.toString() !== user._id.toString()) {
                let userData = await UserModel.findOne({
                    _id: buddies[i]._id,
                });
                let mutualFriends = 0;
                for (let j = 0; j < userData.buddies.length; j++) {
                    if (buddiesId.includes(userData.buddies[j].toString()))
                        mutualFriends++;
                }
                buddies[i].mutualFriends = mutualFriends;
            }
        }

        // Fetch buddy requests received by the user
        const receivedRequests = await UserModel.find({
            buddyRequests: user._id,
        });

        // Add received buddy requests and buddies to the user's profile
        profile.receivedRequests = receivedRequests;
        profile.buddies = buddies;

        return profile;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};
// const getProfile = async (user) => {
//     try {
//         const profile = await UserModel.findOne(
//             { _id: user._id, isDeleted: false },
//             { salt: 0, hash: 0, isDeleted: 0, changePasswordToken: 0 }
//         )
//             .populate('customLocations')
//             .populate('claimedCourses');
//         if (!profile) {
//             throw new ApiError('error.user.not_found', 404);
//     }

//         return profile;
//     } catch (error) {
//         if (error.isJoi) throw new ApiError(error.details[0].message, 400);

//         if (error.status) throw new ApiError(error.message, error.status);

//         throw new ApiError(error.message, 500);
//     }
// };

const updateProfile = async (user, body) => {
    try {
        let validateRequest = joi.attempt(body, updateProfileSchema);
        const filter = { _id: user._id, isDeleted: false };

        var date1 = new Date(validateRequest.dob);
        var today = new Date();

        if (date1 > today) throw new ApiError('errors.user.dob_invalid', 404);

        const update = {
            firstName: validateRequest.firstName,
            lastName: validateRequest.lastName,
            dob: validateRequest.dob,
            experience: validateRequest.experience,
            handicap: validateRequest.handicap,
            averageScore: validateRequest.averageScore,
            jobTitle: validateRequest.jobTitle,
            company: validateRequest.company,
            education: validateRequest.education,
            story: validateRequest.story,
            isOnboardingCompleted: validateRequest.isOnboardingCompleted,
            isScheduleChecked: validateRequest.isScheduleChecked,
        };
        await UserModel.findOneAndUpdate(filter, update);
        return await UserModel.findOne(
            { _id: user._id, isDeleted: false },
            { salt: 0, hash: 0, isDeleted: 0, changePasswordToken: 0 }
        );
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const getUsers = async (query, user) => {
    try {
        let users = [];
        let userDetail = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        var blockerIds = userDetail.blockUsers.map(function (item) {
            return item['UserId'];
        });

        const myBuddiesIds = userDetail.buddies.map((buddy) =>
            buddy._id.toString()
        );

        if (query.location) {
            users = await UserModel.find(
                {
                    $and: [
                        { isDeleted: false },
                        {
                            $or: [
                                {
                                    'location.name': {
                                        $regex: query.location,
                                        $options: 'i',
                                    },
                                },
                                {
                                    'location.latitude': {
                                        $regex: query.location,
                                        $options: 'i',
                                    },
                                },
                                {
                                    'location.longitude': {
                                        $regex: query.location,
                                        $options: 'i',
                                    },
                                },
                                {
                                    'location.address': {
                                        $regex: query.location,
                                        $options: 'i',
                                    },
                                },
                            ],
                        },
                        { _id: { $nin: blockerIds } },
                    ],
                },
                { salt: 0, hash: 0, isDeleted: 0, changePasswordToken: 0 }
            ).lean();

            for (let i = 0; i < users.length; i++) {
                let mutualFriends = 0;
                if (users[i]._id.toString() !== user._id.toString()) {
                    for (let j = 0; j < users[i].buddies.length; j++) {
                        const buddies = users[i].buddies;
                        if (
                            buddies[j].toString() !== userDetail._id.toString()
                        ) {
                            if (myBuddiesIds.includes(buddies[j].toString()))
                                mutualFriends++;
                        }
                    }
                }
                users[i].mutualFriends = mutualFriends;
            }
            return users;
        }
        users = await UserModel.find(
            { isDeleted: false, _id: { $nin: blockerIds } },
            { salt: 0, hash: 0, changePasswordToken: 0 }
        )
            .populate('claimedCourses')
            .lean();

        for (let i = 0; i < users.length; i++) {
            let mutualFriends = 0;
            if (users[i]._id.toString() !== user._id.toString()) {
                for (let j = 0; j < users[i].buddies.length; j++) {
                    const buddies = users[i].buddies;
                    if (buddies[j] !== userDetail._id) {
                        if (myBuddiesIds.includes(buddies[j].toString()))
                            mutualFriends++;
                    }
                }
            }
            users[i].mutualFriends = mutualFriends;
        }

        return users;
    } catch (error) {
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const changeEmail = async (user, body) => {
    try {
        let validateRequest = joi.attempt(body, changeEmailSchema);
        const filter = { _id: user._id, isDeleted: false };
        const update = { email: validateRequest.email };
        await UserModel.findOneAndUpdate(filter, update);
        return await UserModel.findOne({ _id: user._id, isDeleted: false });
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const addUserLocation = async (user, body) => {
    try {
        let validateRequest = joi.attempt(body, addUserLocationSchema);
        const filter = { _id: user._id, isDeleted: false };

        const regexExp =
            /^((\-?|\+?)?\d+(\.\d+)?),\s*((\-?|\+?)?\d+(\.\d+)?)$/gi;
        if (
            !regexExp.test(
                validateRequest.longitude + ',' + validateRequest.latitude
            )
        )
            throw new ApiError('errors.user.invalid_location', 404);

        await UserModel.updateOne(filter, {
            $set: {
                location: validateRequest,
            },
        });

        return await UserModel.findOne(filter, {
            salt: 0,
            hash: 0,
            isDeleted: 0,
            changePasswordToken: 0,
            createdAt: 0,
            updatedAt: 0,
            __v: 0,
        });
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        throw new ApiError(error.message, 404);
    }
};
const deleteUser = async (user, req) => {
  try {
    const filter = { _id: user._id, isDeleted: false };
    let detailUser = await UserModel.findOne(filter, {
      salt: 0,
      hash: 0,
      changePasswordToken: 0,
    });

    if (!detailUser) throw new ApiError('errors.user.user_not_exist', 404);

    if (detailUser.provider === 'Facebook') {
      detailUser.isDeleted = true;
      await detailUser.save();
      return 'User has been deleted successfully';
    } else {
      // Create a new token with a default expire time
      let needToGenerateVerifyToken = true;
      if (
        detailUser.deleteUserToken &&
        detailUser.deleteUserToken.token &&
        !detailUser.tokenIsExpired('deleteUserToken.expires')
      ) {
        needToGenerateVerifyToken = false;
      }
      let token;
      if (needToGenerateVerifyToken) {
        detailUser.deleteUserToken = {};
        token = detailUser.createNewDeleteToken();
      } else {
        token = detailUser.deleteUserToken;
      }

      let host = `${process.env.HOST_PROTOCOL}://${req.host}/`;

      if (process.env.NODE_ENV === 'development') {
        host = `http://${req.host}:${process.env.PORT}/`;
      }

      await sendEmail({
        to: detailUser.email,
        subject: 'Delete Account Verification',
        text: `To delete your account, please open the link provided: ${host}deleteUser/verifyEmail/${token.token}`,
      });

      await detailUser.save();

      // Delete the user from the database
      await UserModel.deleteOne(filter);

      return 'An account deletion email has been sent to your email. Please verify to delete';
    }
  } catch (error) {
    if (error.isJoi) throw new ApiError(error.details[0].message, 400);

    if (error.status) throw new ApiError(error.message, error.status);

    throw new ApiError(error.message, 500);
  }
};



const changePassword = async (user, body) => {
    try {
        let validateRequest = joi.attempt(body, changePasswordSchema);

        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);
        const validate = await profile.validatePassword(
            validateRequest.oldPassword
        );

        if (!validate) throw new ApiError('errors.user.password_mismatch', 404);

        profile.setPassword(validateRequest.newPassword);
        await profile.save();

        return await profile.getBasicProfile();
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};
const actionBuddyRequest = async (req, res) => {
    try {
        const { userId, action } = req.body;
        const { _id } = req.user.user;
        if (!userId) throw new ApiError('errors.user-id-required', 404);

        const currentUser = await UserModel.findOne({
            _id,
            isDeleted: false,
        });
        if (!currentUser) {
            throw new ApiError('errors.user.not_found', 404);
        }

        const buddyProfile = await UserModel.findOne({
            _id: userId,
        });

        if (!buddyProfile)
            throw new ApiError('errors.user.buddy_not_found', 404);

        let buddyRequestIndex = -1;
        let buddyRequestReceivedIndex = -1;

        // Check if the current user sent a buddy request to the buddy profile
        buddyRequestIndex = currentUser.buddyRequests.findIndex(
            (id) => id.toString() === buddyProfile._id.toString()
        );

        // Check if the current user received a buddy request from the buddy profile
        buddyRequestReceivedIndex = currentUser.buddyRequestsReceived.findIndex(
            (id) => id.toString() === buddyProfile._id.toString()
        );

        if (buddyRequestIndex === -1 && buddyRequestReceivedIndex === -1) {
            throw new ApiError('errors.user.buddy_request_not_found', 404);
        }

        if (action === 'approve') {
            if (buddyRequestIndex !== -1) {
                // Remove buddy request from current user's sent requests
                currentUser.buddyRequests.splice(buddyRequestIndex, 1);

                // Add buddies to both profiles
                currentUser.buddies.push(buddyProfile._id);
                buddyProfile.buddies.push(currentUser._id);

                await currentUser.save();
                await buddyProfile.save();

                res.status(200).json({
                    message: 'Buddy request approved successfully',
                });
            } else {
                // Remove buddy request from current user's received requests
                currentUser.buddyRequestsReceived.splice(
                    buddyRequestReceivedIndex,
                    1
                );

                // Add buddies to both profiles
                currentUser.buddies.push(buddyProfile._id);
                buddyProfile.buddies.push(currentUser._id);

                await currentUser.save();
                await buddyProfile.save();

                res.status(200).json({
                    message: 'Buddy request approved successfully',
                });
            }
        } else if (action === 'decline') {
            if (buddyRequestIndex !== -1) {
                // Remove buddy request from current user's sent requests
                currentUser.buddyRequests.splice(buddyRequestIndex, 1);

                await currentUser.save();

                res.status(200).json({
                    message: 'Buddy request declined successfully',
                });
            } else {
                // Remove buddy request from current user's received requests
                currentUser.buddyRequestsReceived.splice(
                    buddyRequestReceivedIndex,
                    1
                );

                await currentUser.save();

                res.status(200).json({
                    message: 'Buddy request declined successfully',
                });
            }
        } else {
            throw new ApiError('Invalid action', 400);
        }
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

// const actionBuddyRequest = async (req, res) => {
//     try {
//         const { userId, action } = req.body;
//         const { _id } = req.user.user;
//         console.log('req.user', _id);
//         if (!userId) throw new ApiError('errors.user-id-required', 404);

//         const currentUser = await UserModel.findOne({
//             _id,
//             isDeleted: false,
//         });
//         if (!currentUser) {
//             throw new ApiError('errors.user.not_found', 404);
//         }

//         const buddyProfile = await UserModel.findOne({
//             _id: userId,
//         });

//         if (!buddyProfile)
//             throw new ApiError('errors.user.buddy_not_found', 404);

//         if (!currentUser.buddyRequests.includes(buddyProfile._id))
//             throw new ApiError('errors.user.buddy_request_not_found', 404);

//         if (action === 'approve') {
//             // Remove buddy request
//             currentUser.buddyRequests = currentUser.buddyRequests.filter(
//                 (id) => id.toString() !== buddyProfile._id.toString()
//             );

//             // Add buddies to both profiles
//             currentUser.buddies.push(buddyProfile._id);
//             buddyProfile.buddies.push(currentUser._id);

//             await currentUser.save();
//             await buddyProfile.save();

//             res.status(200).json({
//                 message: 'Buddy request approved successfully',
//             });
//         } else if (action === 'decline') {
//             // Remove buddy request
//             currentUser.buddyRequests = currentUser.buddyRequests.filter(
//                 (id) => id.toString() !== buddyProfile._id.toString()
//             );
//             await currentUser.save();

//             res.status(200).json({
//                 message: 'Buddy request declined successfully',
//             });
//         } else {
//             throw new ApiError('Invalid action', 400);
//         }
//     } catch (error) {
//         if (error.isJoi) throw new ApiError(error.details[0].message, 400);
//         if (error.status) throw new ApiError(error.message, error.status);

//         throw new ApiError(error.message, 500);
//     }
// };
const getMutualFriends = async (req, res) => {
    try {
        const user1Id = req.params.user1Id;
        const user2Id = req.params.user2Id;
        const user1 = await UserModel.findById(user1Id).populate(
            'buddies',
            'firstName lastName'
        );
        const user2 = await UserModel.findById(user2Id).populate(
            'buddies',
            'firstName lastName'
        );

        if (!user1 || !user2) throw new ApiError('errors.user.not_found', 404);

        const mutualFriends = user1.buddies.filter((buddy) =>
            user2.buddies.includes(buddy._id)
        );
        const mutualFriendsCount = mutualFriends.length;
        return mutualFriendsCount;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const cancelBuddyRequest = async (user, body) => {
    try {
        if (!body.userId)
            throw new ApiError('errors.cancel-user-id-required', 404);

        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        if (!body.userId.match(/^[0-9a-fA-F]{24}$/))
            throw new ApiError('errors.user.user-id-Incorrect', 404);

        let buddyProfile = await UserModel.findOne({
            _id: body.userId,
        });

        if (!buddyProfile)
            throw new ApiError('errors.user.buddy_not_found', 404);

        // Check if buddy request exists
        const requestIndex = profile.buddyRequests.indexOf(buddyProfile._id);
        if (requestIndex === -1)
            throw new ApiError('errors.user.buddy_request_not_found', 404);

        profile.buddyRequests.splice(requestIndex, 1);

        await profile.save();

        return profile.getBasicProfile();
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};
const getBuddyRequests = async (user) => {
    try {
        const profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        }).populate('buddyRequests', 'firstName lastName email image'); // Add fields you want to populate for buddy requests

        if (!profile) throw new ApiError('errors.user.not_found', 404);

        return profile.buddyRequests;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};
const getBuddyRequestsReceived = async (user) => {
    try {
        const profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        }).populate('buddyRequestsReceived', 'firstName lastName email image'); // Add fields you want to populate for buddy requests

        if (!profile) throw new ApiError('errors.user.not_found', 404);

        return profile.buddyRequestsReceived;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};
const removeBuddies = async (user, body) => {
    try {
      if (!body.userId) {
        throw new ApiError('errors.remove-user-id-required', 404);
      }
  
      const profile = await UserModel.findOne({
        _id: user._id,
        isDeleted: false,
      });
  
      if (!profile) {
        throw new ApiError('errors.user.not_found', 404);
      }
  
      if (!body.userId.match(/^[0-9a-fA-F]{24}$/)) {
        throw new ApiError('errors.user.user-id-Incorrect', 404);
      }
  
      const buddyProfile = await UserModel.findOne({
        _id: body.userId,
        isDeleted: false,
      });
  
      if (!buddyProfile) {
        throw new ApiError('errors.user.buddy_not_found', 404);
      }
  
      if (!profile.buddies.includes(buddyProfile._id)) {
        throw new ApiError('errors.user.buddy_not_added', 404);
      }
  
      const buddyIndex = profile.buddies.indexOf(buddyProfile._id);
      profile.buddies.splice(buddyIndex, 1);
  
      const userIndex = buddyProfile.buddies.indexOf(profile._id);
      buddyProfile.buddies.splice(userIndex, 1);
  
      await profile.save();
      await buddyProfile.save();
  
      return profile.getBasicProfile();
    } catch (error) {
      if (error.isJoi) {
        throw new ApiError(error.details[0].message, 400);
      }
      if (error.status) {
        throw new ApiError(error.message, error.status);
      }
  
      throw new ApiError(error.message, 500);
    }
  };
  const mongoose = require('mongoose');

// Define the Notification Schema
const NotificationSchema = new mongoose.Schema(
  {
    text: String,
    isRead: String,
    isDeleted: String,
    type: String,
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    linkId: mongoose.Schema.Types.ObjectId,
  },
  { toJSON: { virtuals: true } }
);

// Define the Notification Model

const addBuddies = async (user, body) => {
  try {
    if (!body.userId) {
      throw new ApiError('errors.add-user-id-required', 404);
    }

    const profile = await UserModel.findOne({
      _id: user._id,
      isDeleted: false,
    });
    console.log('profile????', profile);
    if (!profile) {
      throw new ApiError('errors.user.not_found', 404);
    }

    if (profile._id.toString() === body.userId) {
      throw new ApiError('errors.user.not-buddies-yourself', 404);
    }

    if (!body.userId.match(/^[0-9a-fA-F]{24}$/)) {
      throw new ApiError('errors.user.user-id-Incorrect', 404);
    }

    const buddyProfile = await UserModel.findOne({
      _id: body.userId,
      isDeleted: false,
    });
    console.log('buddyProfile>>>>>>>', buddyProfile.fcmToken);
    if (!buddyProfile) {
      throw new ApiError('errors.user.buddy_not_found', 404);
    }

    if (profile.buddies.includes(buddyProfile._id)) {
      throw new ApiError('errors.user.buddy_already_added', 404);
    }

    if (profile.blockUsers.find((x) => x.UserId === body.userId)) {
      throw new ApiError('errors.user.blocked-by-you', 404);
    }

    // Check if buddy request already exists
    if (profile.buddyRequests.includes(buddyProfile._id)) {
      throw new ApiError('errors.user.buddy_request_already_sent', 404);
    }

    profile.buddyRequests.push(buddyProfile._id);
    buddyProfile.buddyRequestsReceived.push(profile._id);

    await profile.save();
    await buddyProfile.save();

    if (buddyProfile.fcmToken) {
      // Assuming you have a function called 'sendAndroid' to send notifications
      await sendAndroid(
        buddyProfile.fcmToken,
        'Add Buddy',
        `The user ${profile.firstName} ${profile.lastName} added you as a buddy.`
      );
    }

    // Create a new notification for the action "Add Buddy"
    const newNotification = new NotificationModel({
      text: `The user ${profile.firstName} ${profile.lastName} added you as a buddy.`,
      isRead: false,
      isDeleted: false,
      type: 'Add Buddy',
    //   userId: buddyProfile._id, // The user who will receive the notification (the buddy)
    //   linkId: profile._id, // The user who initiated the action (the one who added the buddy)
     
      userId: buddyProfile._id, // The user who will receive the notification (the buddy)
      linkId: profile._id, // The user who initiated the action (the one who added the buddy)
    });

    // Save the new notification to the database
    await newNotification.save();

    return profile.getBasicProfile();
  } catch (error) {
    if (error.isJoi) {
      throw new ApiError(error.details[0].message, 400);
    }
    if (error.status) {
      throw new ApiError(error.message, error.status);
    }

    throw new ApiError(error.message, 500);
  }
};

//   >>>new one 
// const addBuddies = async (user, body) => {
//     try {
//       if (!body.userId) {
//         throw new ApiError('errors.add-user-id-required', 404);
//       }
  
//       const profile = await UserModel.findOne({
//         _id: user._id,
//         isDeleted: false,
//       });
//       console.log('profile????',profile);
//       if (!profile) {
//         throw new ApiError('errors.user.not_found', 404);
//       }
  
//       if (profile._id.toString() === body.userId) {
//         throw new ApiError('errors.user.not-buddies-yourself', 404);
//       }
  
//       if (!body.userId.match(/^[0-9a-fA-F]{24}$/)) {
//         throw new ApiError('errors.user.user-id-Incorrect', 404);
//       }
  
//       const buddyProfile = await UserModel.findOne({
//         _id: body.userId,
//         isDeleted: false,
//       });
//       console.log('buddyProfile>>>>>>>',buddyProfile.fcmToken);
//       if (!buddyProfile) {
//         throw new ApiError('errors.user.buddy_not_found', 404);
//       }
    
//       if (profile.buddies.includes(buddyProfile._id)) {
//         throw new ApiError('errors.user.buddy_already_added', 404);
//       }
  
//       if (profile.blockUsers.find((x) => x.UserId === body.userId)) {
//         throw new ApiError('errors.user.blocked-by-you', 404);
//       }
  
//       // Check if buddy request already exists
//       if (profile.buddyRequests.includes(buddyProfile._id)) {
//         throw new ApiError('errors.user.buddy_request_already_sent', 404);
//       }
  
//       profile.buddyRequests.push(buddyProfile._id);
//       buddyProfile.buddyRequestsReceived.push(profile._id);
  
//       await profile.save();
//       await buddyProfile.save();
  
//       if (buddyProfile.fcmToken) {
//         await sendAndroid(
//             buddyProfile.fcmToken,
//           'Add Buddy',
//           `The user ${profile.firstName} ${profile.lastName} added you as a buddy.`
//         );
//       }
  
//       return profile.getBasicProfile();
//     } catch (error) {
//       if (error.isJoi) {
//         throw new ApiError(error.details[0].message, 400);
//       }
//       if (error.status) {
//         throw new ApiError(error.message, error.status);
//       }
  
//       throw new ApiError(error.message, 500);
//     }
//   };
//   >>

// const addBuddies = async (user, body) => {
//     try {
//         console.log('>>>>>');
//         if (!body.userId)
//             throw new ApiError('errors.add-user-id-required', 404);

//         let profile = await UserModel.findOne({
//             _id: user._id,
//             isDeleted: false,
//         });
//         if (!profile) throw new ApiError('errors.user.not_found', 404);

//         if (profile._id.toString() === body.userId)
//             throw new ApiError('errors.user.not-buddies-yourself', 404);

//         if (!body.userId.match(/^[0-9a-fA-F]{24}$/))
//             throw new ApiError('errors.user.user-id-Incorrect', 404);

//         let buddyProfile = await UserModel.findOne({
//             _id: body.userId,
//             isDeleted: false,
//         });
//             console.log('buddyProfile.fcmToken',buddyProfile.fcmToken);

//         if (!buddyProfile)
//             throw new ApiError('errors.user.buddy_not_found', 404);

//         if (profile.buddies.includes(buddyProfile._id))
//             throw new ApiError('errors.user.buddy_already_added', 404);

//         if (profile.blockUsers.find((x) => x.UserId === body.userId))
//             throw new ApiError('errors.user.blocked-by-you', 404);

//         // Check if buddy request already exists
//         if (profile.buddyRequests.includes(buddyProfile._id))
//             throw new ApiError('errors.user.buddy_request_already_sent', 404);

//         profile.buddyRequests.push(buddyProfile._id);
//         buddyProfile.buddyRequestsReceived.push(profile._id);

//         await profile.save();
//         await buddyProfile.save();

//         if (buddyProfile.fcmToken) {
//             console.log('buddyProfile.fcmToken>>>>>',buddyProfile.fcmToken);
//             await sendAndroid(
//                 buddyProfile.fcmToken,
//                 'Add Buddy',
//                 'The user ' +
//                     profile.firstName +
//                     ' ' +
//                     profile.lastName +
//                     ' added you as buddy'
//             );
//         }

//         return profile.getBasicProfile();
//     } catch (error) {
//         if (error.isJoi) throw new ApiError(error.details[0].message, 400);
//         if (error.status) throw new ApiError(error.message, error.status);

//         throw new ApiError(error.message, 500);
//     }
// };
const getBuddies = async (user, request) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        let buddiesId = [];
        buddiesId = profile.buddies;

        var search = '';
        if (request.query) search = request.query;

        const buddies = await UserModel.aggregate([
            {
                $addFields: {
                    fullName: {
                        $concat: ['$firstName', ' ', '$lastName'],
                    },
                },
            },
            {
                $match: {
                    $and: [
                        { _id: { $in: buddiesId } },
                        {
                            $or: [
                                {
                                    firstName: {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    lastName: {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    fullName: {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.name': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.longitude': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.latitude': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.address': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                            ],
                        },
                        { isDeleted: false },
                    ],
                },
            },
            {
                $project: {
                    salt: 0,
                    hash: 0,
                    isDeleted: 0,
                    changePasswordToken: 0,
                    createdAt: 0,
                    updatedAt: 0,
                    __v: 0,
                },
            },
        ]);

        for (let i = 0; i < buddies.length; i++) {
            if (buddies[i]._id.toString() !== user._id.toString()) {
                let userData = await UserModel.findOne({
                    _id: buddies[i]._id,
                    isDeleted: false,
                });
                let mutualFriends = 0;
                for (let j = 0; j < userData.buddies.length; j++) {
                    if (buddiesId.includes(userData.buddies[j].toString()))
                        mutualFriends++;
                }
                buddies[i].mutualFriends = mutualFriends;
            }
        }
        return buddies;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        else if (error.status) throw new ApiError(error.message, error.status);
        else throw new ApiError(error.message, 500);
    }
};

const generateQRCode = async (user) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        let data = {
            _id: profile._id,
            firstName: profile.firstName,
            lastName: profile.lastName,
            email: profile.email,
            dob: profile.dob,
            phone: profile.phone,
            image: profile.image,
            location: profile.location,
        };

        return qr.toDataURL(JSON.stringify(data));
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        else if (error.status) throw new ApiError(error.message, error.status);
        else throw new ApiError(error.message, 500);
    }
};

const blockUser = async (user, query) => {
    try {
        if (!query.query) throw new ApiError('errors.user-id-required', 404);

        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        if (profile._id.toString() === query.query)
            throw new ApiError('errors.user.not-block-yourself', 404);

        let blockerProfile = await UserModel.findOne({
            _id: query.query,
            isDeleted: false,
        });

        if (!blockerProfile)
            throw new ApiError('errors.user.block_user_not_found', 404);

        if (profile.blockUsers.find((x) => x.UserId === query.query))
            throw new ApiError('errors.user.block_user_already_blocked', 404);

        if (profile.buddies.includes(blockerProfile._id)) {
            const index = profile.buddies.indexOf(
                blockerProfile._id.toString()
            );
            if (index > -1) {
                profile.buddies.splice(index, 1); // 2nd parameter means remove one item only
            }
        }

        var blockUser = {};
        blockUser.UserId = query.query;
        blockUser.date = new Date().toLocaleString();

        profile.blockUsers.push(blockUser);

        await profile.save();

        if (blockerProfile.fcmToken) {
            await sendAndroid(
                blockerProfile.fcmToken,
                'Block User',
                'The user ' +
                    profile.firstName +
                    ' ' +
                    profile.lastName +
                    ' blocked your profile.'
            );
        }

        return profile;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        else if (error.status) throw new ApiError(error.message, error.status);
        else throw new ApiError(error.message, 500);
    }
};

const getBlockUsers = async (user) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        let blockersId = [];
        for (let i = 0; i < profile.blockUsers.length; i++) {
            blockersId.push(profile.blockUsers[i].UserId.toString());
        }

        return await UserModel.find(
            { _id: { $in: blockersId }, isDeleted: false },
            { salt: 0, hash: 0, isDeleted: 0, changePasswordToken: 0 }
        );
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const saveImage = async (user, req) => {
    try {
        let extension = req.file.filename.split('.')[1];

        if (!(extension == 'jpg' || extension == 'jpeg' || extension == 'png'))
            throw new ApiError('errors.user.invalid-image-type', 404);
        const filter = { _id: user._id, isDeleted: false };

        const update = {
            image: `${process.env.HOST_PROTOCOL}://${req.host}/${req.file.path}`,
        };

        if (process.env.NODE_ENV === 'development') {
            update.image = `http://${req.host}:${process.env.PORT}/${req.file.path}`;
        }
        await UserModel.findOneAndUpdate(filter, update);
        return await UserModel.findOne(
            { _id: user._id, isDeleted: false },
            { salt: 0, hash: 0, isDeleted: 0, changePasswordToken: 0 }
        );
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const userExperience = async (user, body) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);
        if (!body.type)
            throw new ApiError('errors.user.experience_type_does_not_exists');
        if (!body.text)
            throw new ApiError('errors.user.experience_text_is_required');

        return await sendEmail({
            to: 'linkedgolf22@gmail.com',
            subject: 'User Experience: ' + body.type,
            text: `User Name: ${profile.firstName} ${profile.lastName} \r\nType: ${body.type} \r\nDescription: ${body.text}`,
        });
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const enableTwoFactorAuthStep1 = async (user) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);
        const secret = speakeasy.generateSecret({
            length: 20,
            name: 'golfCourse',
            issuer: 'golfCourse',
            algorithm: 'sha256',
        });

        let response = {};
        response.secret = secret;
        response.url = await qr.toDataURL(secret.otpauth_url);

        if (response) return response;
        else throw new ApiError('errors.user.qr_code_generate_failed', 404);
    } catch (error) {
        throw new ApiError(error.message, error.status);
    }
};

const enableTwoFactorAuthStep2 = async (user, body) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        const secret = body.secret.base32;
        const token = body.token;
        const verified = speakeasy.totp.verify({
            secret,
            encoding: 'base32',
            token,
        });

        if (verified) {
            profile.twoFactorAuth = true;
            profile.secret = secret;

            await profile.save();
            return { validated: true };
        } else {
            return { validated: false };
        }
    } catch (error) {
        throw new ApiError(error.message, 500);
    }
};

const validateTwoFactorAuth = async (body) => {
    try {
        let user = await UserModel.findOne({
            email: body.email,
            isDeleted: false,
        });
        if (!user) throw new ApiError('errors.user.not_found', 404);

        const token = body.token;
        const validated = speakeasy.totp.verify({
            secret: user.secret,
            encoding: 'base32',
            token,
        });
        let response = {};
        response.validate = validated;
        response.user = user;
        return response;
    } catch (error) {
        throw new ApiError(error.message, 500);
    }
};

const addDevice = async (user, body) => {
    try {
        if (!body.deviceId || !body.fcmToken)
            throw new ApiError('errors.user.device_id_required', 404);

        const filter = { _id: user._id, isDeleted: false };
        const update = { deviceId: body.deviceId, fcmToken: body.fcmToken };
        await UserModel.findOneAndUpdate(filter, update);
        return await UserModel.findOne(
            { _id: user._id, isDeleted: false },
            { salt: 0, hash: 0, isDeleted: 0, changePasswordToken: 0 }
        );
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const searchGeneral = async (user, params) => {
    try {
        let searchData = { users: '', schedules: '', styles: '' };

        let userDetail = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        var blockerIds = userDetail.blockUsers.map(function (item) {
            return item['UserId'];
        });

        if (params.type === 'everything') {
            let users = await searchUsers(params.search, 'all', blockerIds);
            let schedules = await GolfScheduleService.searchSchedules(
                user,
                params.search,
                blockerIds
            );
            let styles = await GolfStyleService.searchStyles(
                user,
                params.search,
                blockerIds
            );
            searchData.styles = styles;
            searchData.schedules = schedules;
            searchData.users = users;
        } else if (params.type === 'users') {
            let users = await searchUsers(params.search, 'all', blockerIds);
            searchData.users = users;
        } else if (params.type === 'schedules') {
            let schedules = await GolfScheduleService.searchSchedules(
                user,
                params.search,
                blockerIds
            );
            searchData.schedules = schedules;
        } else if (params.type === 'styles') {
            let styles = await GolfStyleService.searchStyles(
                user,
                params.search,
                blockerIds
            );
            searchData.styles = styles;
        } else if (params.type === 'handicap') {
            let users = await searchUsers(
                params.search,
                params.type,
                blockerIds
            );
            searchData.users = users;
        } else if (params.type === 'age') {
            if (isNaN(params.search))
                throw new ApiError('errors.user.not_a_number', 404);

            let users = await searchUsers(params.search, 'age', blockerIds);
            searchData.users = users;
        } else {
            throw new ApiError('errors.user.invalid_search_type', 404);
        }
        return searchData;
    } catch (error) {
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const searchUsers = async (search, type, blockerIds) => {
    try {
        let query = {
            $or: [],
        };
        if (type === 'all') {
            query.$or.push({
                firstName: { $regex: new RegExp(search, 'i') },
            });
            query.$or.push({
                lastName: { $regex: new RegExp(search, 'i') },
            });
            query.$or.push({
                fullName: { $regex: new RegExp(search, 'i') },
            });
        } else if (type === 'handicap') {
            query.$or.push({
                handicap: parseInt(search),
            });
        } else if (type === 'age') {
            query.$or.push({
                age: parseInt(search),
            });
        }

        return await UserModel.aggregate([
            {
                $addFields: {
                    fullName: {
                        $concat: ['$firstName', ' ', '$lastName'],
                    },
                    age: {
                        $floor: {
                            $divide: [
                                {
                                    $subtract: [new Date(), '$dob'],
                                },
                                365 * 24 * 60 * 60 * 1000,
                            ],
                        },
                    },
                },
            },
            {
                $match: {
                    $and: [
                        {
                            isDeleted: false,
                        },
                        query,
                        {
                            _id: {
                                $nin: blockerIds,
                            },
                        },
                    ],
                },
            },
            {
                $project: {
                    firstName: 1,
                    lastName: 1,
                    dob: 1,
                    image: 1,
                    email: 1,
                    age: 1,
                    handicap: 1,
                },
            },
        ]);
    } catch (error) {
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const getProfileById = async (userId) => {
    const profile = await UserModel.findOne(
        { _id: userId, isDeleted: false },
        { salt: 0, hash: 0, isDeleted: 0 }
    ).lean();

    profile.qr_code = await generateQRCode({ _id: userId });
    const buddies = await UserModel.find(
        { _id: { $in: profile.buddies }, isDeleted: false },
        { salt: 0, hash: 0, isDeleted: 0 }
    ).lean();

    const myBuddiesIds = profile.buddies.map((buddy) => buddy._id.toString());

    for (let i = 0; i < buddies.length; i++) {
        let mutualFriends = 0;
        if (buddies[i]._id.toString() !== profile._id.toString()) {
            for (let j = 0; j < buddies[i].buddies.length; j++) {
                const budds = buddies[i].buddies;
                if (budds[j] !== profile._id) {
                    if (myBuddiesIds.includes(budds[j].toString()))
                        mutualFriends++;
                }
            }
        }
        buddies[i].mutualFriends = mutualFriends;
    }

    const buddiesSchedules = await GolfScheduleService.getBuddiesGolfSchedule(
        {
            _id: userId,
        },
        {
            query: {},
        }
    );

    const golfSchedules = await GolfScheduleService.getUserGolfSchedule(
        profile._id
    );

    const favPlaces = await GolfCourseService.getAllFavPlaces({
        _id: userId,
    });

    profile.golfSchedules = golfSchedules;
    profile.favPlaces = favPlaces;
    profile.buddiesSchedules = buddiesSchedules;

    if (profile.golfStyle) {
        profile.golfStyle = await GolfStyleService.getGolfStyleById(
            profile.golfStyle
        );
    }
    profile.buddies = buddies;

    return profile;
};

module.exports = {
    createUser: create,
    verifyRegistrationEmail,
    getResetPasswordToken,
    setNewPassword,
    getProfile,
    updateProfile,
    getUsers,
    changeEmail,
    changePassword,
    addBuddies,
    removeBuddies,
    getBuddies,
    addUserLocation,
    deleteUser,
    generateQRCode,
    enableTwoFactorAuthStep1,
    enableTwoFactorAuthStep2,
    validateTwoFactorAuth,
    blockUser,
    getBlockUsers,
    saveImage,
    createGoogleUser,
    googleSignupFlow,
    resendVerificationEmail,
    facebookLogin,
    userExperience,
    appleLogin,
    addDevice,
    deleteUserEmail,
    searchGeneral,
    searchUsers,
    getProfileById,
    actionBuddyRequest,
    cancelBuddyRequest,
    getBuddyRequests,
    getBuddyRequestsReceived,
    getMutualFriends,
};
