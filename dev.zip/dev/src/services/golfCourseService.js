'use strict';

const axios = require('axios');
const { ApiError } = require('../errors');
const { UserModel, FavPlaceModel, ClaimCourseModel } = require('../models');
const ClaimCourseSchemaModel = require('../models/claimCourse/claimCourse');
const RawResponseModel = require('../models/rawResponse/rawResponse');
const UserEventModel = require('../models/user/requestSchema/eventUser');
const ObjectId = require('mongodb').ObjectId;






  

const getAllGolfCourses = async (user, params) => {
    try {
        let userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        //
        let location = null;
        if (params.lat && params.lng) {
            // If a custom location is provided in params, use it
            location ={latitude:params.lat,longitude:params.lng};
        } else if (
            userData?.location?.latitude &&
            userData?.location?.longitude
        ) {
            // If user location exists, use it
            location = userData.location;
        } else {
            throw new ApiError('errors.course.add_location', 404);
        }
        // if (!userData?.location?.latitude && !userData?.location?.longitude) {
        //     throw new ApiError('errors.course.add_location', 404);
        // }
        const radius = params.radius || 5000;
        const rawResponse = await RawResponseModel.findOne({
            'location.latitude': location.latitude,
            'location.longitude': location.longitude,
            radius: radius,
        });

        let response = null;

        if (!rawResponse) {
            let search =
                location.latitude + ',' + location.longitude;
            const { data } = await axios.get(
                'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=' +
                    search +
                    '&radius=' +
                    radius +
                    '&keyword=golf+course&key=AIzaSyDKGe1w4sPrrqYCl_9HazD3ux8hlHdfRxk'
            );
            let rawResponse = new RawResponseModel({
                response: JSON.stringify(data),
                location: {
                    latitude: location.latitude,
                    longitude: location.longitude,
                },
                type: 'nearbysearch',
                placeId: null,
                radius: radius,
            });
            await rawResponse.save();
            response = data;
        } else {
            response = JSON.parse(rawResponse.response);
        }

        let favPlaces = await getFavPlaces(user);
        let placeIds = favPlaces.map(function (item) {
            return item['placeId'];
        });

        let records = response.results;
        for (var i = 0; i < records.length; i++) {
            let id = records[i].place_id;
            let users = await getFavPlaceUsersCount(id);
            let buddies = await getFavPlaceBuddiesCount(id, user);
            let usersDetail = await getFavPlaceUsers(id, user);
            records[i].users = users;
            records[i].buddies = buddies;
            records[i].isFavorite = false;
            records[i].usersDetail = usersDetail;
            if (placeIds.includes(id)) records[i].isFavorite = true;
        }

        return records;
    } catch (error) {
        console.log(error);
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const addFavPlace = async (user, req) => {
    try {
        if (!req.placeId)
            throw new ApiError('errors.course.place_id_required', 400);

        let prevPlace = await FavPlaceModel.findOne({
            placeId: req.placeId,
            userId: user._id.toString(),
        });

        if (prevPlace) {
            if (!prevPlace.isDeleted) prevPlace.isDeleted = true;
            else prevPlace.isDeleted = false;
            prevPlace.save();
            return prevPlace;
        }

        let favPlace = new FavPlaceModel({
            placeId: req.placeId,
            userId: user._id.toString(),
            isDeleted: false,
        });

        await favPlace.save();
        return favPlace;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getFavPlaceUsersCount = async (placeId) => {
    try {
        if (!placeId)
            throw new ApiError('errors.course.place_id_required', 400);

        let favePlace = await FavPlaceModel.find({
            placeId: placeId,
            isDeleted: false,
        });

        let count = 0;

        for (let i = 0; i < favePlace.length; i++) {
            const user = await UserModel.findOne({
                _id: favePlace[i].userId,
                isDeleted: false,
            });
            if (user) {
                count++;
            }
        }

        return count;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};
const getFavPlaceUsers = async (placeId, user) => {
    try {
        if (!placeId)
            throw new ApiError('errors.course.place_id_required', 400);

        let finalUsers = [];
        let userIds = await FavPlaceModel.find(
            {
                placeId: placeId,
                isDeleted: false,
            },
            {
                userId: 1,
            }
        );

        var usersArray = userIds.map(function (user) {
            return user['userId'];
        });

        for (let i = 0; i < usersArray.length; i++) {
            if (usersArray[i] !== user._id.toString()) {
                let userData = await UserModel.findOne(
                    {
                        _id: new ObjectId(usersArray[i]),
                        isDeleted: false,
                    },
                    {
                        firstName: 1,
                        lastName: 1,
                        dob: 1,
                        image: 1,
                        email: 1,
                    }
                );
                if (userData) {
                    finalUsers.push(userData);
                }
            }
        }
        return finalUsers;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getFavPlaceBuddiesCount = async (placeId, user) => {
    try {
        if (!placeId)
            throw new ApiError('errors.course.place_id_required', 400);

        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        let buddiesId = [];
        buddiesId = profile.buddies;
        let count = await FavPlaceModel.find({
            placeId: placeId,
            userId: {
                $in: buddiesId,
            },
            isDeleted: false,
        }).count();

        return count;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getAllFavPlaces = async (user) => {
    try {
        let placeIds = await FavPlaceModel.find(
            {
                userId: user._id.toString(),
                isDeleted: false,
            },
            { userId: 0, _id: 0, createdAt: 0, updatedAt: 0, __v: 0 }
        );
        let favPlaces = [];
        for (let i = 0; i < placeIds.length; i++) {
            const rawResponse = await RawResponseModel.findOne({
                placeId: placeIds[i].placeId,
            });

            let response = null;
            if (!rawResponse) {
                const { data } = await axios.get(
                    'https://maps.googleapis.com/maps/api/place/details/json?place_id=' +
                        placeIds[i].placeId +
                        '&key=AIzaSyDKGe1w4sPrrqYCl_9HazD3ux8hlHdfRxk'
                );

                let rawResponse = new RawResponseModel({
                    response: JSON.stringify(data),
                    location: {
                        latitude: data.result
                            ? data.result.geometry.location.lat
                            : null,
                        longitude: data.result
                            ? data.result.geometry.location.lng
                            : null,
                    },
                    type: 'placedetail',
                    placeId: placeIds[i].placeId,
                });
                await rawResponse.save();
                response = data;
            } else {
                response = JSON.parse(rawResponse.response);
            }
            let id = placeIds[i].placeId;
            let users = await getFavPlaceUsersCount(id);
            let usersDetail = await getFavPlaceUsers(id, user);
            let buddies = await getFavPlaceBuddiesCount(id, user);
            let obj = {};
            obj.detail = response;
            obj.users = users;
            obj.buddies = buddies;
            obj.usersDetail = usersDetail;
            favPlaces.push(obj);
        }

        return favPlaces;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getFavPlaces = async (user) => {
    try {
        return await FavPlaceModel.find(
            {
                userId: user._id.toString(),
                isDeleted: false,
            },
            { userId: 0, _id: 0, createdAt: 0, updatedAt: 0, __v: 0 }
        );
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getPlaceDetails = async (req, user) => {
    try {
        let placeDetail = await getPlaceDetailsGeneral(req);
        let finalPlaceDetail = {};
        finalPlaceDetail.placeDetail = placeDetail;

        let events = await UserEventModel.find({
            placeId: req.placeId,
            isDeleted: false,
        });
        finalPlaceDetail.events = events;
        let userIds = await FavPlaceModel.find(
            {
                placeId: req.placeId,
                isDeleted: false,
            },
            {
                placeId: 0,
                _id: 0,
                createdAt: 0,
                updatedAt: 0,
                __v: 0,
                isDeleted: 0,
            }
        );

        let userDetail = await UserModel.findOne(
            {
                _id: user._id,
                isDeleted: false,
            },
            {
                blockUsers: 0,
                experience: 0,
                handicap: 0,
                averageScore: 0,
                _id: 0,
                createdAt: 0,
                updatedAt: 0,
                jobTitle: 0,
                company: 0,
                education: 0,
                provider: 0,
                twoFactorAuth: 0,
                deviceId: 0,
                isVerified: 0,
                salt: 0,
                hash: 0,
                secret: 0,
                golfStyle: 0,
                __v: 0,
                isDeleted: 0,
                changePasswordToken: 0,
            }
        );

        var buddiesArray = userDetail?.buddies.map((x) => x.toString());
        var usersArray = userIds.map(function (user) {
            return user['userId'];
        });
        let finalUsers = [];

        for (let i = 0; i < usersArray.length; i++) {
            if (usersArray[i] !== user._id.toString()) {
                let Obj = {};
                let userData = await UserModel.findOne(
                    {
                        _id: new ObjectId(usersArray[i]),
                        isDeleted: false,
                    },
                    {
                        firstName: 1,
                        lastName: 1,
                        dob: 1,
                        image: 1,
                        email: 1,
                        buddies: 1,
                    }
                );
                let mutualFriends = 0;
                if (userData) {
                    Obj.isBuddy = false;
                    if (buddiesArray?.includes(usersArray[i]))
                        Obj.isBuddy = true;
                    Obj.user = userData;
                    for (let j = 0; j < userData.buddies.length; j++) {
                        if (
                            buddiesArray.includes(
                                userData.buddies[j].toString()
                            )
                        )
                            mutualFriends++;
                    }
                    Obj.mutualFriends = mutualFriends;
                }

                if (Object.keys(Obj).length) {
                    finalUsers.push(Obj);
                }
            }
        }
        finalPlaceDetail.users = finalUsers;

        let place = await FavPlaceModel.findOne(
            {
                userId: user._id.toString(),
                placeId: req.placeId,
                isDeleted: false,
            },
            { userId: 0, _id: 0, createdAt: 0, updatedAt: 0, __v: 0 }
        );
        finalPlaceDetail.isFavourite = false;
        if (place) finalPlaceDetail.isFavourite = true;

        return {
            placeDetail: finalPlaceDetail.placeDetail,
            events: finalPlaceDetail.events,
            users: finalPlaceDetail.users,
            isFavourite: finalPlaceDetail.isFavourite,
        };
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getPlaceDetailsGeneral = async (req) => {
    try {
        if (!req.placeId)
            throw new ApiError('errors.course.place_id_required', 400);

        const rawResponse = await RawResponseModel.findOne({
            placeId: req.placeId,
        });

        let response = null;
        if (!rawResponse) {
            const { data } = await axios.get(
                'https://maps.googleapis.com/maps/api/place/details/json?place_id=' +
                    req.placeId +
                    '&key=AIzaSyDKGe1w4sPrrqYCl_9HazD3ux8hlHdfRxk'
            );

            let rawResponse = new RawResponseModel({
                response: JSON.stringify(data),
                location: {
                    latitude: data.result
                        ? data.result.geometry.location.lat
                        : null,
                    longitude: data.result
                        ? data.result.geometry.location.lng
                        : null,
                },
                type: 'placedetail',
                placeId: req.placeId,
            });
            await rawResponse.save();
            response = data;
        } else {
            response = JSON.parse(rawResponse.response);
        }

        return response;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};
const getClaimGolfCourse = async (req, res) => {
    try {
        const Userevents = await ClaimCourseModel.find({}).populate('events');
        res.send(Userevents);
    } catch (error) {
        res.status(500).send(error);
    }
};
const deleteClaimedCourse = async (req, res) => {
    try {
        const { id } = req.params;
        const deletedUserEvent = await ClaimCourseModel.findByIdAndDelete(id, {
            new: true,
        });
        if (!deletedUserEvent) {
            return res.status(404).json({ error: 'Claim Golf Course not found' });
        }
        // if deletion is successful, return a success message
        res.json({ message: 'Claim Golf Course deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
};
  
const nodemailer = require('nodemailer');
const { param } = require('../routes/router');
const claimGolfCourse = async (req, res) => {
    try {
        const { userId } = req.params;
        const user = await UserModel.findById(userId);
        if (!user) {
            return res.status(400).json({ message: 'user not found' });
        }
        
        const claimedCourse = new ClaimCourseModel({
            state:req.body.state,
            zipCode:req.body.zipCode,
            city:req.body.city,
            email: req.body.email,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            course: req.body.course,
            courseAddress: req.body.courseAddress,
            role: req.body.role,
            number: req.body.number,
            courseId: req.body.courseId,
        });
        await claimedCourse.save();
        await UserModel.updateOne(
            { _id: userId },
            {
                $push: {
                    claimedCourses: [claimedCourse._id],
                },
            }
        );

        const transporter = nodemailer.createTransport({
            service: 'Gmail',
            auth: {
                user: 'techtiztechtiz@gmail.com',
                pass: 'xbmikpfxvswwfhtk',
            },
        });

        const recipients = [
            'matthewquatrani@gmail.com',
            'linkedgolf22@gmail.com',
            'techtiz22@gmail.com'
        ];

        const mailPromises = recipients.map((recipient) => {
            const mailOptions = {
                from: 'golfcoursedeveloper@gmail.com',
                to: recipient,
                subject: 'New Golf Course Claim',
                html: `
            <h3>New Golf Course Claim Details:</h3>
            <p><strong>Email:</strong> ${req.body.email}</p>
            <p><strong>First Name:</strong> ${req.body.firstName}</p>
            <p><strong>Last Name:</strong> ${req.body.lastName}</p>
            <p><strong>Course:</strong> ${req.body.course}</p>
            <p><strong>Course Address:</strong> ${req.body.courseAddress}</p>
            <p><strong>Role:</strong> ${req.body.role}</p>
            <p><strong>Number:</strong> ${req.body.number}</p>
            <p><strong>Course ID:</strong> ${req.body.courseId}</p>
          `,
            };

            return transporter.sendMail(mailOptions);
        });

// const getAllUsersByPlaceId = async (placeId) => {
//     if (!placeId) throw new ApiError('errors.course.place_id_required', 400);

//     let userIds = await FavPlaceModel.find(
//         {
//             placId: placeId,
//             isDeleted: false,
//         },
//         {
//             placeId: 0,
//             _id: 0,
//             createdAt: 0,
//             updatedAt: 0,
//             __v: 0,
//         }
//     );

//     return userIds;
// };

        await Promise.all(mailPromises);
        return claimedCourse;
        //   res.status(200).json(claimedCourse);
    } catch (error) {
        console.log('error', error);
        //   res.status(500).json({ message: 'An error occurred' });
    }
};
const claimGolfCourseByAdmin = async (req, res) => {
    try {
        const { id } = req.params;
        console.log('id', id);
        const claimedCourse = await ClaimCourseModel.findById(id);
        if (!claimedCourse) {
            return res
                .status(404)
                .json({ message: 'Claimed course not found' });
        }
        const updatedCourse = await ClaimCourseModel.findByIdAndUpdate(
            id,
            { verified: !claimedCourse.verified },
            { new: true }
        );
        return res.json(updatedCourse);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Internal Server Error' });
    }
    //  try {
    //         const claimCourse = await ClaimCourseModel.findById(req.params.id);
    //         if (!claimCourse) {
    //             return res.status(404).json({ message: 'Claim course not found' });
    //         }
    //         claimCourse.verified = !claimCourse.verified;
    //         const updatedCourse = await claimCourse.save();
    //         res.json(updatedCourse);
    //     } catch (error) {
    //         console.error(error);
    //         res.status(500).json({ message: 'Internal Server Error' });
    //     }
};
module.exports = {
    getAllGolfCourses,
    addFavPlace,
    getFavPlaceUsersCount,
    getFavPlaceBuddiesCount,
    getAllFavPlaces,
    getPlaceDetails,
    // getAllUsersByPlaceId,
    getPlaceDetailsGeneral,
    getFavPlaceUsers,
    claimGolfCourse,
    claimGolfCourseByAdmin,
    getClaimGolfCourse,
    deleteClaimedCourse
};
