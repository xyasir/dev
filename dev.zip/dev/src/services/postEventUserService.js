const eventUserModel = require('../models/user/requestSchema/eventUser');
const PostEventUserModel = require('../models/user/requestSchema/postEventUser');

const likePostEventUser = async (req, res) => {
  try {
    const postId = req.params.id;
    const userId = req.params.userId;
    const action = req.params.action;

    let updateObj = {};

    if (action === 'like') {
      updateObj = {
        $addToSet: { likes: userId },
        $inc: { likesCount: 1 }
      };
    } else if (action === 'dislike') {
      updateObj = {
        $addToSet: { dislikes: userId },
        $inc: { dislikesCount: 1, likesCount: -1 },
        $pull: { likes: userId } // Remove user from the likes array
      };
    } else {
      throw new Error('Invalid action');
    }

    await PostEventUserModel.updateOne({ _id: postId }, updateObj);
    const updatedPost = await PostEventUserModel.findById(postId);
    res.send({ message: `${action.charAt(0).toUpperCase() + action.slice(1)} added`, data: { likesCount: updatedPost.likesCount, dislikesCount: updatedPost.dislikesCount } });
  } catch (err) {
    res.status(400).send(err.message);
  }
};





// const likePostEventUser = async (req, res) => {
//   try {
//     const postId = req.params.id;
//     const userId = req.params.userId;
//     await PostEventUserModel.updateOne({ _id: postId }, { $addToSet: { likes: userId }, $inc: { likesCount: 1 } });
//     const updatedPost = await PostEventUserModel.findById(postId);
//     res.send({ message: 'Like added', data:{likesCount: updatedPost.likesCount} });
//   } catch (err) {
//     res.status(400).send(err.message);
//   }
// }
const addPostEventUser = async (req, res) => {
    try {
        const { eventUserId } = req.params;
        // const { userId } = req.params;

        console.log('eventUserId',eventUserId);
        const user = await eventUserModel.findById(eventUserId);
        if (!user) {
            return res.status(404).json({ error: 'eventUserId not found' });
        }
        const eventUser = new PostEventUserModel({
            //    image :`${process.env.HOST_PROTOCOL}://${req.hostname}/${req.body.image}`,
            image: req.body.image,
            name: req.body.name,
            text: req.body.text,
            likes: [],
            likesCount: 0,
            eventUserId:eventUserId,
            userId:req.body.userId
            
            
        });
        const savedEventUser = await eventUser.save();
        await eventUserModel.updateOne(
            { _id:eventUserId},
            {
                $push: {
                    eventPost: [savedEventUser._id],
                },
            }
        );
        res.status(201).json({ message: 'success', data: savedEventUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const getPostEventUserById = async (req,res) => {
  try {
    const { eventUserId } = req.params;
    const posts = await PostEventUserModel.find({ eventUserId }).populate('userId');
    res.status(200).json({ data: posts });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

const updatePostEventUser = async (req, res) => {
  try {
    const { postId } = req.params;
    const post = await PostEventUserModel.findById(postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }
    const updatedPost = await PostEventUserModel.findByIdAndUpdate(
      postId,
      {
        image: req.body.image,
        name: req.body.name,
        text: req.body.text,
        eventUserId: req.body.eventUserId,
      },
      { new: true }
    );
    res.status(200).json({ message: 'success', data: updatedPost });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const deletePostEventUser = async (req, res) => {
    try {
      const { postId } = req.params;
      const deletedPost = await PostEventUserModel.findByIdAndDelete(postId);
  
      if (!deletedPost) {
        return res.status(404).json({ message: 'Post not found' });
      }
  
      res.status(200).json({ message: 'Post deleted successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Server error' });
    }
  };

module.exports = {
    addPostEventUser,
    getPostEventUserById,
    updatePostEventUser,
    deletePostEventUser,
    likePostEventUser
};
