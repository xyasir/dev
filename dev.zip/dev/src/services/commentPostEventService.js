const CommentModel = require('../models/user/requestSchema/commentPost');
const eventUserModel = require('../models/user/requestSchema/eventUser');
const PostEventUserModel = require('../models/user/requestSchema/postEventUser');

// router.post('/comment/:id/like/:userId', async (req, res) => {
  const likeCommnetPostEventUser = async (req, res) => {
  try {
    const commentId = req.params.id;
    const userId = req.params.userId;
    await CommentModel.updateOne({ _id: commentId }, { $addToSet: { likes: userId }, $inc: { likesCount: 1 } });
    const updatedComment = await CommentModel.findById(commentId);
    res.send({ message: 'Like added', data:{likesCount: updatedComment.likesCount} });
  } catch (err) {
    res.status(400).send(err.message);
  }
}

const addCommnetPostEventUser = async (req, res) => {
    try {
        const { postId } = req.params;
        const user = await PostEventUserModel.findById(postId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        const eventUser = new CommentModel({
            //    image :`${process.env.HOST_PROTOCOL}://${req.hostname}/${req.body.image}`,
            image: req.body.image,
            name: req.body.name,
            text: req.body.text,
            likes: [],
            likesCount: 0,
            postId:postId,
            userId:req.body.userId
        });
        const savedEventUser = await eventUser.save();
        await PostEventUserModel.updateOne(
            { _id:postId},
            {
                $push: {
                  comments: [savedEventUser._id],
                },
            }
        );
        res.status(201).json({ message: 'success', data: savedEventUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const getCommentByPostId = async (req,res) => {
        try {
          const { postId } = req.params;
      console.log('postId',postId);
          // Find the Post by ID
          const comments = await CommentModel.find({postId}).populate('userId');
      
          if (!comments) {
            return res.status(404).json({ message: 'Comment not found' });
          }
      res.send(comments)
        } catch (err) {
          console.error(err);
          res.status(500).json({ message: 'Server error' });
        }
    };
const updateCommentPostEventUser = async (req, res) => {
  try {
    const { commentId } = req.params;
    const comment = await CommentModel.findById(commentId);
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    const updatedComment = await CommentModel.findByIdAndUpdate(
      commentId,
      {
        name: req.body.name,
        image: req.body.image,
        text: req.body.text,
      },
      { new: true }
    );
    res.status(200).json({ message: 'success', data: updatedComment });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const deleteCommentPostEventUser = async (req, res) => {
    try {
      const { commentId } = req.params;
      const deletedCommentPost = await CommentModel.findByIdAndDelete(commentId);
  
      if (!deletedCommentPost) {
        return res.status(404).json({ message: 'Comment not found' });
      }
  
      res.status(200).json({ message: 'Comment deleted successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Server error' });
    }
  };

module.exports = {
    addCommnetPostEventUser,
    getCommentByPostId,
    updateCommentPostEventUser,
    deleteCommentPostEventUser,
    likeCommnetPostEventUser
};
