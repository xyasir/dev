/* eslint-disable prettier/prettier */

'use strict';

const EventModel = require('../models/event/event');
const UserEventModel = require('../models/userEvent/userEvent');

const getEvent = async (req, res) => {
    try {
        const events = await EventModel.find().populate('event');
        console.log({ events });
        res.send(events);
    } catch (error) {
        console.log({ error });

        res.status(500).send(error);
    }
};

const addEvent = async (req, res) => {
    try {
        const newEvent = new EventModel({
            course: req.body.course,
            address: req.body.address,
            user: req.body.user,
            contactInfo: req.body.contactInfo,
        });
        const savedEvent = await newEvent.save();
        res.status(201).json(savedEvent);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
const updateEvent = async (req, res) => {
    try {
        const { id } = req.params;
        const userEvent = await UserEventModel.findByIdAndUpdate(id, req.body, { new: true });

        if (!userEvent) {
          return res.status(404).json({ error: 'User event not found' });
        }
        res.json(userEvent);
      } catch (err) {
        console.log('ERROR: ', err);
        res.status(500).json({ error: err.message });
      }
};

//
const addUserEvent = async (req, res) => {
    try{
    const { eventId } = req.params;
    const event = await EventModel.findById(eventId);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }
    const userEventData = new UserEventModel({
        image: req.body.image,
        title: req.body.title,
        date: req.body.date,
        startTime: req.body.startTime,
        eventFormat: req.body.eventFormat,
        eventType: req.body.eventType,
        openTo: req.body.openTo,
        description: req.body.description,
        website: req.body.website,
        eventSchema: eventId,
      });
   
    const savedEvent= await userEventData.save();
    await EventModel.updateOne({_id:eventId},
        {
            $push:{
                event:[
                    savedEvent._id
                ]
            }
        } 
        )
  
    
    res.status(201).json(savedEvent);
} catch (err) {
    console.log('ERROR: ', err);
    res.status(500).json({ error: err.message })
}
};
//
const getUserEvent = async (req, res) => {
    try {
        const Userevents = await UserEventModel.find({});
        res.send(Userevents);
    } catch (error) {
        res.status(500).send(error);
    }
};
const getUserEventById = async (Id) => {
    try {
        const Userevents = await UserEventModel.find({ _id: Id });
        return Userevents;
        
    } catch (error) {
        console.log('err');
    }
};
const getEventbyId = async (Id) => {
    try {
        const Userevents = await EventModel.find({ _id: Id }).populate('event');
        return Userevents;
    } catch (error) {
        console.log('err');
    }
};

module.exports = {
    addEvent,
    getEvent,
    getUserEvent,
    addUserEvent,
    getUserEventById,
    getEventbyId,
    updateEvent,
};
