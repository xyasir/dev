/* eslint-disable prettier/prettier */
'use strict';

const { GolfStyleModel, UserModel } = require('../models');
const { ApiError } = require('../errors');
const ObjectId = require('mongodb').ObjectId;
const { updateGolfStyleSchema } = require('../models/golfStyle/requestSchema');
const joi = require('joi');

const addGolfStyle = async (validateRequest, user) => {
    try {
        let userDB = await UserModel.findOne({ _id: user._id, isDeleted: false, }).exec();
        if (userDB.golfStyle)
            throw new ApiError('errors.style.golf_style_exists', 400);

        let golfStyle = await addGolfStyleGeneral(validateRequest, user);
        userDB.golfStyle = golfStyle._id;
        userDB.save();

        return golfStyle;
    } catch (error) {
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const addGolfStyleGeneral = async (validateRequest, user) => {
    try {
        let others = [],
            type = [],
            gameFlow = [];
        if (validateRequest.golfStyleType) type = validateRequest.golfStyleType;

        if (validateRequest.golfStyleGameFlow)
            gameFlow = validateRequest.golfStyleGameFlow;

        if (validateRequest.golfStyleOthers)
            others = validateRequest.golfStyleOthers;
        let golfStyle = new GolfStyleModel({
            type: type,
            gameFlow: gameFlow,
            skillLevel: validateRequest.golfStyleSkillLevel,
            experience: validateRequest.golfStyleExperience,
            others: others,
            isDeleted: false,
            userId: user._id.toString(),
        });

        golfStyle.save();
        return golfStyle;
    } catch (error) {
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getGolfStyleByUserId = async (user) => {
    try {
        let profile = await UserModel.findOne({ _id: user._id, isDeleted: false, });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        if (!profile.golfStyle)
            throw new ApiError('errors.style.golf_style_not_exists', 400);

        return await GolfStyleModel.findOne(
            {
                _id: profile.golfStyle,
                isDeleted: false,
            },
            { userId: 0, createdAt: 0, isDeleted: 0, updatedAt: 0, __v: 0 }
        );
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const getAllGolfStyles = async (user) => {
    try {
        let profile = await UserModel.findOne({ _id: user._id, isDeleted: false, });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        return await GolfStyleModel.find({ isDeleted: false });
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const deleteGolfStyle = async (request, user) => {
    try {
        const filter = { _id: new ObjectId(request.styleId) };
        const update = { isDeleted: true };
        await GolfStyleModel.findOneAndUpdate(filter, update);

        let userDB = await UserModel.findOne({ _id: user._id, isDeleted: false, }).exec();
        userDB.golfStyle = null;
        userDB.save();
        return await GolfStyleModel.findOne(filter);
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const updateGolfStyle = async (request, user) => {
    try {
        let validateRequest = joi.attempt(request, updateGolfStyleSchema);

        let currentUser = await UserModel.findOne({
            _id: new ObjectId(user._id),
            isDeleted: false,
        }).exec();

        if (!currentUser) throw new ApiError('errors.user.not_found', 404);

        if (!currentUser.golfStyle)
            throw new ApiError('errors.style.golf_style_does_not_exists', 400);

        return updateGolfStyleGeneral(validateRequest, currentUser.golfStyle);
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const updateGolfStyleGeneral = async (validateRequest, styleId) => {
    try {
        let update = {};

        validateRequest.golfStyleSkillLevel
            ? (update.skillLevel = validateRequest.golfStyleSkillLevel)
            : '';
        validateRequest.golfStyleExperience
            ? (update.experience = validateRequest.golfStyleExperience)
            : '';

        await GolfStyleModel.updateOne({ _id: new ObjectId(styleId) }, update);

        let style = await GolfStyleModel.findOne({
            _id: new ObjectId(styleId),
            isDeleted: false,
        });

        if (validateRequest.golfStyleType) {
            style.type = [];
            for (let i = 0; i < validateRequest.golfStyleType.length; i++) {
                style.type.push(validateRequest.golfStyleType[i]);
            }
        }
        if (validateRequest.golfStyleGameFlow) {
            style.gameFlow = [];
            for (let i = 0; i < validateRequest.golfStyleGameFlow.length; i++) {
                style.gameFlow.push(validateRequest.golfStyleGameFlow[i]);
            }
        }
        if (validateRequest.golfStyleOthers) {
            style.others = [];
            for (let i = 0; i < validateRequest.golfStyleOthers.length; i++) {
                style.others.push(validateRequest.golfStyleOthers[i]);
            }
        }
        style.save();
        return style;
    } catch (error) {
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const searchStyles = async (user,search) => {
    try {
        let userDetail = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        var blockerIds = userDetail.blockUsers.map(function (item) {
            return item['UserId'];
        });
        var optRegexp = [];
        optRegexp.push(  new RegExp(search, "i") );
        let schedules = await GolfStyleModel.find(
            {
                $and: [
                    { isDeleted: false },
                    {
                        $or: [{ skillLevel:  {$regex: new RegExp(search, 'i')} },
                         { experience:  {$regex: new RegExp(search, 'i')} },
                         { gameFlow : { $exists: true, $in: optRegexp}},
                         { type : { $exists: true, $in: optRegexp}},
                         { others : { $exists: true, $in: optRegexp}}],
                    },
                    {
                        userId: {
                            $nin: blockerIds
                        }
                    },
                ],
            },
            {
                isDeleted: 0,
                createdAt: 0,
                updatedAt: 0,
                __v: 0,
            }
         );
        return schedules;

    } catch (error) {
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};

const getGolfStyleById = async (styleId) => {
    try {
        let golfStyle = await GolfStyleModel.findOne({ _id: styleId }, { isDeleted: false });
        if (!golfStyle) throw new ApiError('errors.golf_style_not_exists.not_found', 404);

        return golfStyle;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

module.exports = {
    addGolfStyle,
    getGolfStyleByUserId,
    getAllGolfStyles,
    deleteGolfStyle,
    updateGolfStyle,
    updateGolfStyleGeneral,
    addGolfStyleGeneral,
    searchStyles,
    getGolfStyleById,
};
