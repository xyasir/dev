'use strict';

const { ApiError } = require('../errors');
const UserModel = require('../models/user/user');

const getBuddies = async (user, request) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        let buddiesId = [];
        buddiesId = profile.buddies;

        var search = '';
        if (request.query) search = request.query;

        const buddies = await UserModel.aggregate([
            {
                $addFields: {
                    fullName: {
                        $concat: ['$firstName', ' ', '$lastName'],
                    },
                },
            },
            {
                $match: {
                    $and: [
                        { _id: { $in: buddiesId } },
                        {
                            $or: [
                                {
                                    firstName: {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    lastName: {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    fullName: {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.name': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.longitude': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.latitude': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                                {
                                    'location.address': {
                                        $regex: new RegExp(search, 'i'),
                                    },
                                },
                            ],
                        },
                    ],
                },
            },
            {
                $project: {
                    salt: 0,
                    hash: 0,
                    isDeleted: 0,
                    changePasswordToken: 0,
                    createdAt: 0,
                    updatedAt: 0,
                    __v: 0,
                },
            },
        ]);

        for (let i = 0; i < buddies.length; i++) {
            if (buddies[i]._id.toString() !== user._id.toString()) {
                let userData = await UserModel.findOne({
                    _id: buddies[i]._id,
                    isDeleted: false,
                });
                let mutualFriends = 0;
                for (let j = 0; j < userData.buddies.length; j++) {
                    if (buddiesId.includes(userData.buddies[j].toString()))
                        mutualFriends++;
                }
                buddies[i].mutualFriends = mutualFriends;
            }
        }
        return buddies;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        else if (error.status) throw new ApiError(error.message, error.status);
        else throw new ApiError(error.message, 500);
    }
};

const getUserProfileById = async (id) => {
    return await UserModel.findOne(
        { _id: id, isDeleted: false },
        { firstName: 1, lastName: 1, image: 1, email: 1 }
    );
};
module.exports = {
    getBuddies,
    getUserProfileById,
};
