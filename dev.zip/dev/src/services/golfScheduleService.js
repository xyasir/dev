/* eslint-disable prettier/prettier */
'use strict';

const joi = require('joi');
const { UserModel, ScheduleModel } = require('../models');
const {
    addGolfScheduleSchema,
    inviteToGolfScheduleSchema,
    respondToGolfScheduleInviteSchema,
    updateGolfScheduleSchema,
} = require('../models/schedule/requestSchema');
const { ApiError } = require('../errors');
const GolfCourseService = require('../services/golfCourseService');
const GolfStyleService = require('../services/golfStyleService');
const InvitationService = require('../services/invitationService');
const ObjectId = require('mongodb').ObjectId;
const { getTimeSlot, sendAndroid } = require('../utility');
const moment = require('moment');
const CommonService = require('./commonService');

const addSchedule = async (user, request) => {
    try {
        let validateRequest = joi.attempt(request, addGolfScheduleSchema);
        ///call golf style
        let golfStyle = await GolfStyleService.addGolfStyleGeneral(
            validateRequest,
            user
        );

        let letters = /^[A-Za-z ]+$/;
        let obj = {};
        let timeString = null;
        if (validateRequest.time.match(letters)) {
            obj = await getTimeSlot(validateRequest.time);
            if (obj == 'Invalid Time Slot')
                throw new ApiError('errors.schedule.invalid_time_slot', 400);
            timeString = validateRequest.time;
        } else {
            if (!moment(validateRequest.time, 'HH:mm:ss', true).isValid())
                throw new ApiError('errors.schedule.invalid_start_time', 400);
            obj[0] = validateRequest.time;
            obj[1] = '';
        }
        let CurrentDate = new Date();
        CurrentDate.setDate(CurrentDate.getDate()-1)
        let GivenDate = new Date(validateRequest.date);

        if (GivenDate < CurrentDate)
            throw new ApiError('errors.schedule.invalid_date', 400);

        if (!validateRequest.stayingToLocal)
            validateRequest.stayingToLocal = false;
        if (!validateRequest.willingToTravel)
            validateRequest.willingToTravel = false;

        let schedule = new ScheduleModel({
            userId: user._id,
            title: validateRequest.title,
            date: new Date(validateRequest.date),
            participants: [],
            courseLocation: validateRequest.courseLocation,
            teeTime: validateRequest.teeTime,
            description: validateRequest.description,
            remainingGolfers: validateRequest.remainingGolfers,
            allowBuddiesToInvite: validateRequest.allowBuddiesToInvite,
            comment: validateRequest.comment,
            golfStyle: new ObjectId(golfStyle._id),
            isDeleted: false,
            startTime: obj[0],
            endTime: obj[1],
            availableToGolf: validateRequest.availableToGolf,
            stayingToLocal: validateRequest.stayingToLocal,
            willingToTravel: validateRequest.willingToTravel,
            timeString,
        });

        schedule.participants.push({
            userId: user._id.toString(),
        });
        schedule = await schedule.save();
        if(validateRequest.participants && validateRequest.participants.length) {
            let invitation= {};
        invitation.scheduleId = schedule._id.toString();
        for(let participant of validateRequest.participants)
        {
            invitation.receiver = participant;
            inviteToGolfSchedule(user, invitation);
        }
        }
        schedule = await ScheduleModel.findOne({_id: schedule._id}, {});

        let buddies = await CommonService.getBuddies(user, request);
        for (let i = 0; i < buddies.length; i++) {
            if (buddies[i].fcmToken) {
                await sendAndroid(
                    buddies[i].fcmToken,
                    'Golf Schedule Created',
                    user.firstName +
                        ' ' +
                        user.lastName +
                        ' created a golf schedule.'
                );
            }
        }

        let scheduleDetail = {
            schedule: '',
            golfCourseLocation: '',
        };
        let temp = {};
        temp.placeId = schedule.courseLocation;
        let golfLocation = await GolfCourseService.getPlaceDetailsGeneral(temp);
        scheduleDetail.schedule = schedule;
        scheduleDetail.golfCourseLocation = golfLocation;

        return scheduleDetail;
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getGolfScheduleByUserId = async (user, req) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        let invitations =
        await InvitationService.getInvitationByReceiverId(
            user._id
        );

        let invitationSchedules = [];

        for ( let j = 0; j < invitations.length ; j++) {
            if (invitations[j].type === 'golf:schedule') {
                let schedule = await ScheduleModel.findOne({
                    _id: invitations[j].linkId,
                }).populate({
                    path: 'golfStyle',
                    select: { isDeleted: 0, createdAt: 0, updatedAt: 0, __v: 0 },
                })
                if (schedule) {
                    schedule = schedule.toObject()
                    schedule.status = invitations[j].status;
                    schedule.type = invitations[j].type;
                    if (req.query.date && (new Date(schedule.date).getTime() === new Date(req.query.date).getTime())) {
                        invitationSchedules.push(schedule);
                    } else if (!req.query.date)  {
                        invitationSchedules.push(schedule);
                    }
                }   
            }
        }

        let query = {
            userId: user._id.toString(),
            isDeleted: false,
        };
        
        if (req.query && req.query.endDate && req.query.date) {
            if (!moment(req.query.date, 'YYYY/MM/DD', true).isValid())
                throw new ApiError('errors.user.invalid_date_format', 404);
            if (!moment(req.query.endDate, 'YYYY/MM/DD', true).isValid())
                throw new ApiError('errors.user.invalid_date_format', 404);
            
            const start = new Date(req.query.date);
            start.setHours(0, 0, 0, 0);
            const end =  new  Date(req.query.endDate)
            end.setHours(23, 59, 59, 999);
            query.date = {
                $gte: start,
                $lt: end,
            }
        } else if (req.query && req.query.date) {
            if (!moment(req.query.date, 'YYYY/MM/DD', true).isValid())
                throw new ApiError('errors.user.invalid_date_format', 404);

            const start = new Date(req.query.date);
            start.setHours(0, 0, 0, 0);
            const end = new Date(req.query.date);
            end.setHours(23, 59, 59, 999);

            query.date = {
                $gte: start,
                $lt: end,
            };
        }
        let finalSchedules = [];
        let schedules = await ScheduleModel.find(query, {
            isDeleted: 0,
            createdAt: 0,
            updatedAt: 0,
            __v: 0,
        })
            .populate({
                path: 'golfStyle',
                select: { isDeleted: 0, createdAt: 0, updatedAt: 0, __v: 0 },
            })
            .exec();
        
        schedules = [...invitationSchedules, ...schedules];

        for (let i = 0; i < schedules.length; i++) {
            let Obj = {
                schedule: {},
                invite: '',
                golfCourseLocation: '',
            };
            let invitations =
                await InvitationService.getAllInvitationsByScheduleId(
                    schedules[i]._id
                );
            let temp = {};
            temp.placeId = schedules[i].courseLocation;
            let golfLocation = await GolfCourseService.getPlaceDetailsGeneral(
                temp
            );

            schedules[i] = schedules[i].status ?  schedules[i] :  schedules[i]?.toObject(); 
            schedules[i].user = await CommonService.getUserProfileById(schedules[i].userId);
            Obj.invite = invitations;
            Obj.golfCourseLocation = golfLocation;
            Obj['schedule'] = schedules[i];
            finalSchedules.push(Obj);
        }

        return finalSchedules;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getBuddiesGolfSchedule = async (user, req) => {
    try {
        let profile = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!profile) throw new ApiError('errors.user.not_found', 404);

        let buddiesId = [];
        buddiesId = profile.buddies;

        let start = '';
        let end = '';
        let query = {
            userId: {
                $in: buddiesId,
            },
            isDeleted: false,
        };

        if (req.query && req.query.endDate && req.query.date) {
            if (!moment(req.query.date, 'YYYY/MM/DD', true).isValid())
                throw new ApiError('errors.user.invalid_date_format', 404);
            if (!moment(req.query.endDate, 'YYYY/MM/DD', true).isValid())
                throw new ApiError('errors.user.invalid_date_format', 404);
            
            start = new Date(req.query.date);
            start.setHours(0, 0, 0, 0);
            end =  new  Date(req.query.endDate)
            end.setHours(23, 59, 59, 999);
            query.date = {
                $gte: start,
                $lt: end,
            }
        } else if (req.query && req.query.date) {
            if (!moment(req.query.date, 'YYYY/MM/DD', true).isValid())
                throw new ApiError('errors.user.invalid_date_format', 404);

            start = new Date(req.query.date);
            start.setHours(0, 0, 0, 0);
            end = new Date(req.query.date);
            end.setHours(23, 59, 59, 999);

            query.date = {
                $gte: start,
                $lt: end,
            };

        } else if (req.query && req.query.currentWeek) {
            start = new Date();
            start.setHours(0, 0, 0, 0);
            end =  new  Date()
            end = new Date(end.setDate(start.getDate() + 7));
            end.setHours(23, 59, 59, 999);
            query.date = {
                $gte: start,
                $lt: end,
            }
        }

        let finalSchedules = [];
        let schedules = await ScheduleModel.find(query, {
            isDeleted: 0,
            createdAt: 0,
            updatedAt: 0,
            __v: 0,
        })
            .populate({
                path: 'golfStyle',
                select: { isDeleted: 0, createdAt: 0, updatedAt: 0, __v: 0 },
            })
            .exec();
        
        for (let i = 0; i < schedules.length; i++) {
            let Obj = {};

            let invitations =
                await InvitationService.getAllInvitationsByScheduleId(
                    schedules[i]._id
                );

            let golfLocation = await GolfCourseService.getPlaceDetailsGeneral(
                {
                    placeId: schedules[i].courseLocation
                }
            );
            let scheduleOwner = await UserModel.findOne({
                _id: new ObjectId(schedules[i].userId),
                isDeleted: false,
            },{buddies:1});
            let scheduleOwnerbuddiesArray = scheduleOwner.buddies.map((x) => x.toString());
            let mutualFriends = 0;
            for (let j = 0; j < buddiesId.length; j++) {
                if (scheduleOwnerbuddiesArray.includes(buddiesId[j].toString()))
                    mutualFriends++;
            }

            const user = await UserModel.findOne({ _id: schedules[i].userId, isDeleted: false, }, { salt: 0, hash: 0, isDeleted: 0 })

            Obj.invite = invitations;
            Obj.mutualFriends = mutualFriends;
            Obj.golfCourseLocation = golfLocation;
            Obj.schedule = schedules[i].toObject();
            Obj.schedule.user = user;
            finalSchedules.push(Obj);
        }

        return finalSchedules;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const getGolfSchedulesByUserId = async (user) => {
    let invitations =
    await InvitationService.getInvitationBySenderOrReceiver(
        user._id
    );

    let invitationSchedules = [];

    for ( let j = 0; j < invitations.length ; j++) {
        if (invitations[j].type === 'golf:schedule') {
            let schedule = await ScheduleModel.findOne({
                _id: invitations[j].linkId,
            }).populate({
                path: 'golfStyle',
                select: { isDeleted: 0, createdAt: 0, updatedAt: 0, __v: 0 },
            })
            if (schedule) {
                schedule = schedule.toObject()
                schedule.status == invitations[j].status;
                invitationSchedules.push(schedule);
            }   
        }
    }
    let mySchedules = getUserGolfSchedule(user._id);

    return [...invitationSchedules, ...mySchedules];
}

const getUserGolfSchedule = async (userId) => {
    let schedules = await ScheduleModel.find({
        userId: userId,
        isDeleted: false,
    }, {
        isDeleted: 0,
        createdAt: 0,
        updatedAt: 0,
        __v: 0,
    })
    .populate({
        path: 'golfStyle',
        select: { isDeleted: 0, createdAt: 0, updatedAt: 0, __v: 0 },
    })
    .exec();

    let mySchedules = [];

    for (let i = 0; i < schedules.length; i++) {
        let Obj = {};
        let golfLocation = await GolfCourseService.getPlaceDetailsGeneral(
            {
                placeId: schedules[i].courseLocation
            }
        );

        Obj.golfCourseLocation = golfLocation;
        Obj.schedule = schedules[i].toObject();
        mySchedules.push(Obj);
    }
    return mySchedules;
}

const deleteGolfSchedule = async (params) => {
    try {
        const filter = {
            _id: new ObjectId(params.scheduleId),
        };
        const update = {
            isDeleted: true,
        };
        await ScheduleModel.findOneAndUpdate(filter, update);
        return await ScheduleModel.findOne(filter);
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const inviteToGolfSchedule = async (user, request) => {
    try {
        let validateRequest = joi.attempt(request, inviteToGolfScheduleSchema);

        let schedule = await ScheduleModel.findOne({
            _id: new ObjectId(validateRequest.scheduleId),
            isDeleted: false,
        }).exec();

        if (!schedule) throw new ApiError('errors.schedule.not_found', 404);

        if (schedule.participants.length >= schedule.remainingGolfers)
            throw new ApiError('errors.schedule.participants_confirmed', 404);

        let receiver = await UserModel.findOne({
            _id: new ObjectId(validateRequest.receiver),
            isDeleted: false,
        });

        let sender = await UserModel.findOne({
            _id: new ObjectId(user._id),
            isDeleted: false,
        });

        if (!receiver)
            throw new ApiError('errors.schedule.user_not_found', 404);

        if (user._id.toString() == receiver._id.toString())
            throw new ApiError('errors.schedule.user_not_invite_himself', 404);

        let prevInvite =
            await InvitationService.getInvitationsByScheduleIdAndUserId(
                new ObjectId(validateRequest.scheduleId),
                validateRequest.receiver
            );
        if (prevInvite)
            throw new ApiError('errors.schedule.user_not_invite_again', 404);

        let invite = await InvitationService.addInvitation(
            validateRequest.receiver,
            'pending',
            user,
            'golf:schedule',
            new ObjectId(validateRequest.scheduleId)
        );

        if (receiver.fcmToken) {
            await sendAndroid(
                receiver.fcmToken,
                'Golf Schedule Respond',
                `The user ${sender.firstName} ${sender.lastName} sends you an invite of the Golf Schedule Dated: ${moment(schedule.date).format('DD/MM/YYYY')}`
            );
        }

        return invite;
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const respondToGolfScheduleInvite = async (user, request) => {
    try {
        let validateRequest = joi.attempt(
            request,
            respondToGolfScheduleInviteSchema
        );

        let schedule = await ScheduleModel.findOne({
            _id: new ObjectId(validateRequest.scheduleId),
            isDeleted: false,
        }).exec();

        if (!schedule) throw new ApiError('errors.schedule.not_found', 404);

        if (schedule.participants.length >= schedule.remainingGolfers)
            throw new ApiError('errors.schedule.participants_confirmed', 404);

        let sender = await UserModel.findOne({
            _id: new ObjectId(schedule.userId),
            isDeleted: false,
        });

        if (!sender) throw new ApiError('errors.schedule.user_not_found', 404);

        let prevInviteResponse =
            await InvitationService.getInvitationsByScheduleIdAndUserId(
                new ObjectId(validateRequest.scheduleId),
                user._id.toString()
            );
        if (prevInviteResponse.status === 'accepted' || prevInviteResponse.status === 'rejected')
            throw new ApiError('errors.schedule.user_not_response_again', 404);
        if (validateRequest.status === 'accepted') {
            if (
                schedule.participants.find(
                    (x) => x.userId === user._id.toString()
                ) && prevInviteResponse.status !== 'Requested'
            )
                throw new ApiError(
                    'errors.schedule.added_to_golf_schedule',
                    404
                );
            if (prevInviteResponse.status !== 'Requested')
            schedule.participants.push({
                userId: user._id.toString(),
            });
            else
            schedule.participants.push({
                userId: prevInviteResponse.sender,
            });
            schedule.remainingGolfers = schedule.remainingGolfers-1
            schedule.save();
        }

        let invite = await InvitationService.respondInvitation(
            new ObjectId(validateRequest.scheduleId),
            user._id.toString(),
            validateRequest.status
        );
        if (sender.fcmToken) {
            await sendAndroid(
                sender.fcmToken,
                'Golf Schedule Respond',
                `The user ${sender.firstName} ${sender.lastName} ${
                    validateRequest.status
                } the Golf Schedule Dated: ${moment(schedule.date).format(
                    'DD/MM/YYYY'
                )}`
            );
        }

        return invite;
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const requestToJoinGolfSchedule = async (user, request) => {
    try {
        let schedule = await ScheduleModel.findOne({
            _id: new ObjectId(request.scheduleId),
            isDeleted: false,
        }).exec();

        if (!schedule) throw new ApiError('errors.schedule.not_found', 404);

        let receiver = await UserModel.findOne({
            _id: new ObjectId(schedule.userId),
            isDeleted: false,
        });

        let sender = await UserModel.findOne({
            _id: new ObjectId(user._id),
            isDeleted: false,
        });
        if (schedule.participants.length >= schedule.remainingGolfers)
            throw new ApiError('errors.schedule.participants_confirmed', 404);

        if (
            schedule.participants.find(
                (x) => x.userId === sender._id.toString()
            )
        )
            throw new ApiError('errors.schedule.joined_to_golf_schedule', 404);

        if (!receiver)
            throw new ApiError('errors.schedule.user_not_found', 404);

        let prevRequestToJoin =
            await InvitationService.getInvitationsByScheduleIdAndSenderId(
                new ObjectId(request.scheduleId),
                user._id.toString(),
                'Requested'
            );

        if (prevRequestToJoin)
            throw new ApiError('errors.schedule.user_not_request_again', 404);

        let invite = await InvitationService.addInvitation(
            new ObjectId(receiver._id),
            'Requested',
            user,
            'golf:schedule',
            new ObjectId(request.scheduleId)
        );

        if (receiver.fcmToken) {
            await sendAndroid(
                receiver.fcmToken,
                'Golf Schedule Join Request',
                `The user ${sender.firstName} ${
                    sender.lastName
                } sends you a request to join the Golf Schedule Dated: ${moment(
                    schedule.date
                ).format('DD/MM/YYYY')}`
            );
        }

        return invite;
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const updateGolfSchedule = async (request, user) => {
    try {
        let validateRequest = joi.attempt(request, updateGolfScheduleSchema);

        let currentUser = await UserModel.findOne({
            _id: new ObjectId(user._id),
            isDeleted: false,
        }).exec();

        if (!currentUser) throw new ApiError('errors.user.not_found', 404);

        let schedule = await ScheduleModel.findOne({
            _id: new ObjectId(validateRequest.scheduleId),
            userId: user._id,
            isDeleted: false,
        });

        if (!schedule) throw new ApiError('errors.schedule.not_found', 404);

        let update = {};

        update.timeString = null;

        validateRequest.title ? (update.title = validateRequest.title) : '';
        validateRequest.courseLocation
            ? (update.courseLocation = validateRequest.courseLocation)
            : '';
        validateRequest.teeTime
            ? (update.teeTime = validateRequest.teeTime)
            : '';
        validateRequest.description
            ? (update.description = validateRequest.description)
            : '';
        validateRequest.allowBuddiesToInvite
            ? (update.allowBuddiesToInvite =
                  validateRequest.allowBuddiesToInvite)
            : '';
        validateRequest.comment
            ? (update.comment = validateRequest.comment)
            : '';

        if (validateRequest.date) {
            let CurrentDate = new Date();
            let GivenDate = new Date(validateRequest.date);

            if (GivenDate <= CurrentDate)
                throw new ApiError('errors.schedule.invalid_date', 400);

            update.date = new Date(validateRequest.date);
        }

        let letters = /^[A-Za-z ]+$/;
        let obj = {};
        if (validateRequest.time) {
            if (validateRequest.time.match(letters)) {
                obj = await getTimeSlot(validateRequest.time);
                if (obj == 'Invalid Time Slot')
                    throw new ApiError(
                        'errors.schedule.invalid_time_slot',
                        404
                    );
                update.startTime = obj[0];
                update.endTime = obj[1];
                update.timeString = validateRequest.time;
            } else {
                if (!moment(validateRequest.time, 'HH:mm:ss', true).isValid())
                    throw new ApiError(
                        'errors.schedule.invalid_start_time',
                        404
                    );
                update.startTime = validateRequest.time;
                update.endTime = '';
            }
        }
        update.stayingToLocal = validateRequest.stayingToLocal;
        update.willingToTravel = validateRequest.willingToTravel;
        if(validateRequest.remainingGolfers && schedule.participants.length < validateRequest.remainingGolfers)
            update.remainingGolfers = validateRequest.remainingGolfers

        await ScheduleModel.updateOne(
            { _id: new ObjectId(validateRequest.scheduleId) },
            update
        );

        await GolfStyleService.updateGolfStyleGeneral(
            validateRequest,
            schedule.golfStyle
        );

        let updatedSchedule = await ScheduleModel.findOne({
            _id: new ObjectId(validateRequest.scheduleId),
        })
            .populate('golfStyle')
            .exec();

        let scheduleDetail = {
            schedule: '',
            golfCourseLocation: '',
        };
        let temp = {};
        temp.placeId = updatedSchedule.courseLocation;
        let golfLocation = await GolfCourseService.getPlaceDetailsGeneral(temp);
        scheduleDetail.schedule = updatedSchedule;
        scheduleDetail.golfCourseLocation = golfLocation;

        return scheduleDetail;
    } catch (error) {
        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
};

const searchSchedules = async (user, search) => {
    try {
        let userDetail = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        let blockerIds = userDetail.blockUsers.map(function (item) {
            return item['UserId'];
        });
        let schedules = await ScheduleModel.find(
            {
                $and: [
                    { isDeleted: false },
                    {
                        $or: [
                            { title: { $regex: new RegExp(search, 'i') } },
                            {
                                description: {
                                    $regex: new RegExp(search, 'i'),
                                },
                            },
                        ],
                    },
                    {
                        userId: {
                            $nin: blockerIds,
                        },
                    },
                ],
            },
            {
                isDeleted: 0,
                createdAt: 0,
                updatedAt: 0,
                __v: 0,
            }
        );
        return schedules;
    } catch (error) {
        if (error.status) throw new ApiError(error.message, error.status);

        throw new ApiError(error.message, 500);
    }
};
const getCalendarSchedule = async (user, req) => {
    try {
        const mySchedules = await getGolfScheduleByUserId(user, req);
        // console.log(mySchedules);
        const buddiesSchedule = await getBuddiesGolfSchedule(user, req);
        return [...mySchedules, ...buddiesSchedule];
    } catch (error) {
        
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }
        throw new ApiError(error.message, 500);
    }
}


module.exports = {
    addSchedule,
    getGolfScheduleByUserId,
    getBuddiesGolfSchedule,
    deleteGolfSchedule,
    inviteToGolfSchedule,
    respondToGolfScheduleInvite,
    requestToJoinGolfSchedule,
    updateGolfSchedule,
    searchSchedules,
    getGolfSchedulesByUserId,
    getCalendarSchedule,
    getUserGolfSchedule,
};
