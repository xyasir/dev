'use strict';

const { PostCommentModel } = require('../models');
const { ApiError } = require('../errors');
const ObjectId = require('mongodb').ObjectId;
const { addPostCommentSchema } = require('../models/postComment/requestSchema');
const joi = require('joi');

const addPostComment = async (body, user) => {
    try {
        let validateRequest = joi.attempt(body, addPostCommentSchema);

        let comment = new PostCommentModel({
            userId: new ObjectId(user._id),
            text: validateRequest.text,
            postId: validateRequest.postId,
            likes: [],
            isDeleted: false,
        });

        await comment.save();

        return comment;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

const getAllCommentsByPostId = async (postId) => {
    return await PostCommentModel.find(
        {
            postId: postId,
            isDeleted: false,
        },
        { createdAt: 0, updatedAt: 0, __v: 0 }
    ).populate({
        path: 'user',
        select: 'firstName lastName email phone image experience dob buddies',
    });
};

const likePostComment = async (request, user) => {
    try {
        if (!request.commentId)
            throw new ApiError('errors.post.comment_id', 400);

        const filter = { _id: new ObjectId(request.commentId) };

        let comment = await PostCommentModel.findOne(filter);

        if (!comment || comment.isDeleted)
            throw new ApiError('errors.post.comment_not_exist', 400);

        if (comment.likes.includes(user._id.toString())) {
            const index = comment.likes.indexOf(user._id.toString());
            if (index > -1) {
                comment.likes.splice(index, 1); // 2nd parameter means remove one item only
            }
        } else comment.likes.push(user._id.toString());

        await comment.save();
        return comment;
    } catch (error) {
        if (error.isJoi) throw new ApiError(error.details[0].message, 400);
        if (error.status) throw new ApiError(error.message, error.status);
        throw new ApiError(error.message, 500);
    }
};

module.exports = {
    addPostComment,
    getAllCommentsByPostId,
    likePostComment,
};
