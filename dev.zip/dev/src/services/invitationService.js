'use strict';

const { InvitationModel } = require('../models');
const { ApiError } = require('../errors');
const ObjectId = require('mongodb').ObjectId;
const CommonService = require('./commonService');

const addInvitation = async (receiver, status, user, type, id) => {
    try {
        let invite = new InvitationModel({
            type,
            status,
            sender: user._id.toString(),
            receiver,
            linkId: id,
        });
        await invite.save();
        return invite;
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }
        throw new ApiError(error.message, 404);
    }
};

const respondInvitation = async (id, user, status) => {
    try {
        const filter = {
            linkId: id,
            receiver: user,
        };
        const update = {
            status,
        };

        await InvitationModel.findOneAndUpdate(filter, update);
        return await InvitationModel.findOne(filter);
    } catch (error) {
        throw new ApiError(error.message, 400);
    }
};

const getAllInvitationsByScheduleId = async (scheduleId) => {
    let invitations = await InvitationModel.find(
        {
            linkId: scheduleId,
            isDeleted: false,
        },
        { createdAt: 0, updatedAt: 0, __v: 0 }
    );
    let invitationsDetail = [];
    for (let invite of invitations) {
        let sender = await CommonService.getUserProfileById(
            new ObjectId(invite.sender)
        );
        let receiver = await CommonService.getUserProfileById(
            new ObjectId(invite.receiver)
        );
        let inviteDetail = {};
        inviteDetail.invite = invite;
        inviteDetail.sender = sender;
        inviteDetail.receiver = receiver;
        invitationsDetail.push(inviteDetail);
    }

    return invitationsDetail;
};

const getInvitationsByScheduleIdAndUserId = async (scheduleId, userId) => {
    return await InvitationModel.findOne(
        {
            linkId: scheduleId,
            receiver: userId,
            isDeleted: false,
        },
        { createdAt: 0, updatedAt: 0, __v: 0 }
    );
};

const getInvitationsByScheduleIdAndSenderId = async (
    scheduleId,
    userId,
    status
) => {
    return await InvitationModel.findOne(
        {
            linkId: scheduleId,
            sender: userId,
            status: status,
            isDeleted: false,
        },
        { createdAt: 0, updatedAt: 0, __v: 0 }
    );
};

const getInvitationBySenderOrReceiver = async (userId) => {
    return await InvitationModel.find({
        $or: [{ sender: userId }, { receiver: userId }],
    });
};

const getInvitationByReceiverId = async (userId) => {
    return await InvitationModel.find({ receiver: userId });
};

module.exports = {
    addInvitation: addInvitation,
    respondInvitation,
    getAllInvitationsByScheduleId,
    getInvitationsByScheduleIdAndUserId,
    getInvitationsByScheduleIdAndSenderId,
    getInvitationBySenderOrReceiver,
    getInvitationByReceiverId,
};
