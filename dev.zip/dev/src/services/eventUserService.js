const { ClaimCourseModel } = require('../models');
const eventUserModel = require('../models/user/requestSchema/eventUser');
const UserModel = require('../models/user/user');

const addEventUserAction = async (req, res) => {
    try {
        const eventId = req.params.id;
        const userId = req.params.userId;
        const action = req.params.action;
        const currentEvent = await eventUserModel.findById(eventId);
        const goingCount = currentEvent.goingCount;
        const interestedCount = currentEvent.interestedCount;
        let updateFields = {};
        let message = '';
        if (action === 'interested') {
            updateFields = {
                $addToSet: { interested: userId },
                $inc: { interestedCount: +1, goingCount : goingCount <= 0 ? 0 : -1 },
                $pull: { going: userId } // Remove user from the going array
            };
            message =
                'User added to interested list and interested counter incremented';
        } else if (action === 'going') {
            updateFields = {
                $addToSet: { going: userId },
                $inc: { goingCount: +1 , interestedCount: interestedCount <= 0 ? 0 : -1 },
                $pull: { interested: userId } // Remove user from the interested array
            };
            message = 'User added to going list and going counter incremented';
        } else {
            throw new Error('Invalid action');
        }
        await eventUserModel.updateOne({ _id: eventId }, updateFields);
        const event = await eventUserModel.findById(eventId);
        const count =
            action === 'interested' ? event.interestedCount : event.goingCount;
        res.send({ message,data: { count, event} });
    } catch (err) {
        res.status(400).send(err.message);
    }
};













// const addEventUserAction = async (req, res) => {
//     try {
//         const eventId = req.params.id;
//         const userId = req.params.userId;
//         const action = req.params.action;
//         let updateFields = {};
//         let message = '';

//         if (action === 'interested') {
//             updateFields = {
//                 $addToSet: { interested: userId },
//                 $inc: { interestedCount: 1 },
//             };
//             message =
//                 'User added to interested list and interested counter incremented';
//         } else if (action === 'going') {
//             updateFields = {
//                 $addToSet: { going: userId },
//                 $inc: { goingCount: 1 },
//             };
//             message = 'User added to going list and going counter incremented';
//         } else {
//             throw new Error('Invalid action');
//         }

//         await eventUserModel.updateOne({ _id: eventId }, updateFields);
//         const event = await eventUserModel.findById(eventId);
//         const count =
//             action === 'interested' ? event.interestedCount : event.goingCount;
//         // res.send({ message, count });
//         res.send({ data: { count }, message });
//     } catch (err) {
//         res.status(400).send(err.message);
//     }
// };
const saveImageEvent = async (req, res) => {
    try {
        const { id } = req.params;
        let extension = req.file.filename.split('.')[1];
        if (
            !(extension == 'jpg' || extension == 'jpeg' || extension == 'png')
        ) {
            throw new ApiError('errors.user.invalid-image-type', 404);
        }
        const filter = { _id: id };
        const update = {
            image: `${process.env.HOST_PROTOCOL}://${req.host}/${req.file.path}`,
            placeId: req.body.placeId,
            userId: req.body.userId,
            eventUserId: req.body.eventUserId,
        };

        if (process.env.NODE_ENV === 'development') {
            update.image = `http://${req.host}:${process.env.PORT}/${req.file.path}`;
        }

        await eventUserModel.findOneAndUpdate(filter, update);
        return await eventUserModel.findOne(
            { _id: id },
            { createdAt: 0, updatedAt: 0 }
        );
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }

        throw new ApiError(error.message, 500);
    }
};
// getAllEventUser
// const getAllEventUser = async (req, res) => {
//     try {
//         const { latitude, longitude } = req.query;
    
//         // Validate latitude and longitude inputs if needed
    
//         const eventUsers = await eventUserModel.find({
//           'location.latitude': latitude,
//           'location.longitude': longitude,
//         }).populate('userId');
    
//         res.json(eventUsers);
//       } catch (error) {
//         res.status(500).json({ error: 'Internal Server Error' });
//       }
//     }
    
const getAllEventUser = async (req, res) => {
    try {
        const { location } = req.params;
        const events = await eventUserModel.find({ location });
        
        res.status(200).json({ message: 'success', data: events });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
const addEventUser = async (req, res) => {
    try {
        const { userId } = req.params;
        console.log('userId', userId);
        const user = await UserModel.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        let image = `${process.env.HOST_PROTOCOL}://${req.host}/uploads/profile.png`;
        let host = `${process.env.HOST_PROTOCOL}://${req.host}/`;

        if (process.env.NODE_ENV === 'development') {
            image = `http://${req.host}:${process.env.PORT}/uploads/profile.png`;
            host = `http://${req.host}:${process.env.PORT}/`;
        }
        const eventUser = new eventUserModel({
            //  image :`${process.env.HOST_PROTOCOL}://${req.hostname}/${req.file.path}`,
            image,
            location:req.body.location,
            courseName:req.body.courseName,
            title: req.body.title,
            date: req.body.date,
            startTime: req.body.startTime,
            eventFormat: req.body.eventFormat,
            eventType: req.body.eventType,
            openTo: req.body.openTo,
            style: req.body.style,
            description: req.body.description,
            website: req.body.website,
            placeId: req.body.placeId,
            event:req.body.event,
            userId: userId,
            interested: [],
            going: [],
            interestedCount: 0,
            goingCount: 0,
        });
        const savedEventUser = await eventUser.save();
        console.log('savedEventUser',savedEventUser);
        await ClaimCourseModel.updateOne(
            {courseId:savedEventUser.placeId},
            {
                $push: {
                    events: [savedEventUser._id],
                },
            }
        );
        res.status(201).json({ message: 'success', data: savedEventUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
const addEventUserImage = async (req, res) => {
    try {
        const { userId } = req.params;
        console.log('userId', userId);
        const user = await UserModel.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        const eventUser = new eventUserModel({
            image: `${process.env.HOST_PROTOCOL}://${req.hostname}/${req.file.path}`,
            userId: userId,
        });
        const savedEventUser = await eventUser.save();
        await UserModel.updateOne(
            { _id: userId },
            {
                $push: {
                    eventUsers: [savedEventUser._id],
                },
            }
        );
        res.status(201).json({ message: 'success', data: savedEventUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
const getEventUserById = async (Id) => {
    try {
        const Userevents = await eventUserModel
            .find({ placeId: Id })
            .populate('eventImage');
        return { data: Userevents };
    } catch (error) {
        console.log('err');
    }
};
const updateEventUser = async (req, res) => {
    try {
   
        const {
            placeId,
            courseName,
            location,
            title,
            date,
            startTime,
            interested,
            going,
            eventFormat,
            eventType,
            openTo,
            style,
            description,
            website,
            UserId,
            image,
        } = req.body;

        const updatedEventUser = await eventUserModel.findByIdAndUpdate(
            req.params.id,
            {
                placeId,
                courseName,
                location,
                image,
                // image: `${process.env.HOST_PROTOCOL}://${req.hostname}/${req.body.image}`,
                // image:req.body.image,
                title,
                date,
                startTime,
                interested,
                going,
                eventFormat,
                eventType,
                openTo,
                style,
                description,
                website,
                UserId,
            },
            { new: true }
        );

        res.json(updatedEventUser);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
const deleteEventUser = async (req, res) => {
    try {
        const { id } = req.params;
        const deletedUserEvent = await eventUserModel.findByIdAndDelete(id, {
            new: true,
        });
        if (!deletedUserEvent) {
            return res.status(404).json({ error: 'User event not found' });
        }
        // if deletion is successful, return a success message
        res.json({ message: 'User event deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
};

module.exports = {
    addEventUserAction,
    saveImageEvent,
    addEventUserImage,
    addEventUser,
    getEventUserById,
    updateEventUser,
    deleteEventUser,
    getAllEventUser
};
