'use strict';
const {LocationModel, UserModel } = require('../models')
const joi = require('joi');
const {
    addCustomLocationSchema,
} = require('../models/location/requestSchema');
const { ApiError } = require('../errors');

const addLocation = async (req,res) => {
    try{
        const { userId } = req.params;
        const user = await UserModel.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
          }
        const newLocation = new LocationModel({
            name: req.body.name,
            address: req.body.address,
            longitude: req.body.longitude,
            latitude: req.body.latitude,
        });
        console.log('newLocation is ', newLocation);
        const savedLocation = await newLocation.save();
        await UserModel.updateOne({_id:userId},
            {
                $push:{
                    customLocations:[
                        savedLocation._id
                    ]
                }
            } 
            )
      
        console.log('savedLocation',savedLocation);
        res.status(201).json({message:'success',data:savedLocation});
    }catch(error){
        console.log('ERROR: ', error);
        res.status(500).json({ error: error.message });
    }
    } 

module.exports = {
    addLocation,
}
