const eventUserModel = require('../models/user/requestSchema/eventUser');
const ImageEventModel = require('../models/user/requestSchema/eventUserImage');
const UserModel = require('../models/user/user');
const multer = require('multer');

const imageEvent = async (req, res) => {
    try {
        console.log('req', req);
        const { eventUserId } = req.params;
        // const { userId } = req.params;

        console.log('eventUserId', eventUserId);
        const user = await eventUserModel.findById(eventUserId);
        if (!user) {
            return res.status(404).json({ error: 'eventUserId not found' });
        }
        const eventUser = new ImageEventModel({
            image: `${process.env.HOST_PROTOCOL}://${req.hostname}/${req.file.path}`,
            // image: req.body.image,
            placeId: req.body.placeId,
            eventUserId: eventUserId,
            userId: req.body.userId,
        });
        const savedEventUser = await eventUser.save();
        await eventUserModel.updateOne(
            { _id: eventUserId },
            {
                $push: {
                    eventImage: savedEventUser._id,
                },
            }
        );
        res.status(201).json({ message: 'success', data: savedEventUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const updateImageEvent = async (req) => {
    try {
        const { id } = req.params;

        let extension = req.file.filename.split('.')[1];

        if (
            !(extension == 'jpg' || extension == 'jpeg' || extension == 'png')
        ) {
            throw new ApiError('errors.user.invalid-image-type', 404);
        }

        const filter = { _id: id };
        const update = {
            image: `${process.env.HOST_PROTOCOL}://${req.host}/${req.file.path}`,
            placeId: req.body.placeId,
            userId: req.body.userId,
            eventUserId: req.body.eventUserId,
        };

        if (process.env.NODE_ENV === 'development') {
            update.image = `http://${req.host}:${process.env.PORT}/${req.file.path}`;
        }

        await ImageEventModel.findOneAndUpdate(filter, update);

        return await ImageEventModel.findOne(
            { _id: id },
            { createdAt: 0, updatedAt: 0 } // Exclude any specific fields you don't want in the response
        );
    } catch (error) {
        if (error.isJoi) {
            throw new ApiError(error.details[0].message, 400);
        }

        if (error.status) {
            throw new ApiError(error.message, error.status);
        }

        throw new ApiError(error.message, 500);
    }
};

module.exports = {
    imageEvent,
    updateImageEvent,
};
