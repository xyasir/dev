'use strict';

const joi = require('joi');

const envVarsSchema = joi
    .object({
        SENDER_EMAIL: joi.string().email().required(),
        SENDER_PASSWORD: joi.string().required(),
        EMAIL_SERVICE: joi.string().optional().default('gmail'),
    })
    .unknown()
    .required();

const { error, value: envVars } = envVarsSchema.validate(process.env);

if (error) {
    throw new Error(`Config validation error: ${error.message}`);
}

const config = {
    mail: {
        from: 'xyaxir@gmail.com',
        password: 'xbmikpfvswwfhtk',
        emailService: 'gmail'
    },
};

module.exports = config;
