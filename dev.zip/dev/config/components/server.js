'use strict';

const joi = require('joi');

const envVarsSchema = joi
    .object({
        PORT: joi.number().default(8080),
        NODE_ENV: joi.string().allow('development', 'production').required(),
    })
    .unknown()
    .required();

const { error, value: envVars } = envVarsSchema.validate(process.env);

if (error) {
    throw new Error(`Config validation error: ${error.message}`);
}

const config = {
    server: {
        port: envVars.PORT,
        env: envVars.NODE_ENV,
    },
};

module.exports = config;
