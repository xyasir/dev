'use strict';

const joi = require('joi');

const envVarsSchema = joi
    .object({
        MONGO_HOST: joi.string().required(),
        MONGO_PORT: joi.number().default(20717),
        MONGO_USERNAME: joi.string().required(),
        MONGO_PASSWORD: joi.string().required(),
        MONGO_DBNAME: joi.string().default('metabeta'),
    })
    .unknown()
    .required();

const { error, value: envVars } = envVarsSchema.validate(process.env);
if (error) {
    throw new Error(`Config validation error: ${error.message}`);
}

const config = {
    mongodb: {
        host: envVars.MONGO_HOST,
        port: envVars.MONGO_PORT,
        username: envVars.MONGO_USERNAME,
        password: envVars.MONGO_PASSWORD,
        dbname: envVars.MONGO_DBNAME,
    },
};

module.exports = config;
