'use strict';

if (process.env.NODE_ENV !== 'production') {
    let dotEnvConfig = {
        silent: true,
    };

    if (process.env.NODE_ENV === 'testing') {
        const path = require('path');
        dotEnvConfig.path = path.resolve(process.cwd(), 'env.testing');
    }

    require('dotenv').config(dotEnvConfig);
}

const server = require('./components/server');
const mongodb = require('./components/mongodb');
const mail = require('./components/mail');

module.exports = Object.assign({}, server, mongodb, mail);
